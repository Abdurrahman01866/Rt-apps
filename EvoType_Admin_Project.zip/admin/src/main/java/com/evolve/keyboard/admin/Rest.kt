package com.evolve.keyboard.admin

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Minimal Firebase client over HTTPS: email/password sign-in (Firebase Auth REST) and Realtime Database REST. No SDK, no secrets embedded. */
object Rest {
    const val DB = "https://firewallis-app-default-rtdb.firebaseio.com"
    private const val API_KEY = "AIzaSyC_7uxG6RrThHFEckc_nPgjGdvNzuy2IG4"     // public client key (not a secret); writes are protected by the database rules

    class Session(val idToken: String, val uid: String, val email: String, val at: Long) {
        val expired get() = System.currentTimeMillis() - at > 50 * 60 * 1000L
    }

    private fun open(url: String): HttpURLConnection = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 10000 }

    fun signIn(email: String, password: String): Session? = try {
        val c = open("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$API_KEY")
        c.requestMethod = "POST"; c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(JSONObject().put("email", email).put("password", password).put("returnSecureToken", true).toString().toByteArray()) }
        if (c.responseCode == 200) {
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            Session(o.getString("idToken"), o.getString("localId"), email, System.currentTimeMillis())
        } else null
    } catch (e: Exception) { null }

    /** Public read (the database rules allow anyone to read /evotype/public). Returns the JSON text or null. */
    fun get(path: String): String? = try {
        val c = open("$DB/$path.json")
        if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() }.takeIf { it.trim() != "null" } else null
    } catch (e: Exception) { null }

    /** method = PUT (replace) or PATCH (merge). Sent as POST + override header because HttpURLConnection has no PATCH. */
    fun write(method: String, path: String, json: String, token: String): Boolean = try {
        val c = open("$DB/$path.json?auth=$token")
        c.requestMethod = "POST"; c.setRequestProperty("X-HTTP-Method-Override", method); c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(json.toByteArray()) }
        c.responseCode in 200..299
    } catch (e: Exception) { false }
}
