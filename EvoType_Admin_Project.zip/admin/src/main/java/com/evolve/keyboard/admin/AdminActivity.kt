package com.evolve.keyboard.admin

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/** Admin panel: sign in, then edit the settings the keyboard app reads (ads, popup, updates, features, voice corrections). */
class AdminActivity : Activity() {
    private lateinit var root: FrameLayout
    private var session: Rest.Session? = null
    private val ui = Handler(Looper.getMainLooper())
    private val stack = ArrayList<() -> View>()
    private var current: (() -> View)? = null

    private val BG = Color.parseColor("#F5F7FF"); private val NAVY = Color.parseColor("#0B1030"); private val SUB = Color.parseColor("#5B6490"); private val BLUE = Color.parseColor("#1F6BFF")
    private fun d(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)   // no screenshots / recents preview
        root = FrameLayout(this); setContentView(root)
        window.statusBarColor = BG; window.navigationBarColor = BG; window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        show { loginScreen() }
    }

    override fun onBackPressed() { if (stack.isNotEmpty()) show(stack.removeAt(stack.lastIndex)) else super.onBackPressed() }
    private fun show(b: () -> View) { current = b; root.removeAllViews(); root.addView(b(), FrameLayout.LayoutParams(-1, -1)) }
    private fun push(b: () -> View) { if (session?.expired == true) { toast("Session expired, sign in again"); session = null; stack.clear(); show { loginScreen() }; return }; current?.let { stack.add(it) }; show(b) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---- small UI kit
    private fun tv(s: String, sp: Float = 15f, bold: Boolean = false, color: Int = NAVY) = TextView(this).apply { text = s; textSize = sp; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD) }
    private fun lp(t: Int = 0, b: Int = 0, h: Int = LinearLayout.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(-1, h).apply { setMargins(0, d(t), 0, d(b)) }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(14), d(16), d(14)); background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = d(18).toFloat() }; elevation = d(2).toFloat() }
    private fun btn(label: String, primary: Boolean = true, onClick: () -> Unit) = tv(label, 16f, true, if (primary) Color.WHITE else BLUE).apply {
        gravity = Gravity.CENTER; minHeight = d(50); background = GradientDrawable().apply { setColor(if (primary) BLUE else Color.parseColor("#E6EEFF")); cornerRadius = d(25).toFloat() }; setOnClickListener { onClick() } }
    private fun input(hint: String, secret: Boolean = false, multi: Boolean = false) = EditText(this).apply {
        this.hint = hint; setTextColor(NAVY); setHintTextColor(SUB); textSize = 15f
        inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else if (multi) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE else InputType.TYPE_CLASS_TEXT
        if (multi) { minLines = 4; gravity = Gravity.TOP } }
    private fun scaffold(title: String, fill: (LinearLayout) -> Unit): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(d(18), d(14), d(18), 0) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        if (stack.isNotEmpty()) bar.addView(tv("←", 24f, true).apply { setPadding(0, 0, d(14), 0); setOnClickListener { onBackPressed() } })
        bar.addView(tv(title, 22f, true)); page.addView(bar, lp(b = 12))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, d(28)) }
        fill(col)
        page.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }, LinearLayout.LayoutParams(-1, 0, 1f))
        return page
    }

    // ---- screens
    private fun loginScreen(): View = scaffold("Evolve Admin") { col ->
        col.addView(tv("Sign in with the admin account created in Firebase Authentication. Nothing is saved on this phone.", 14f, color = SUB), lp(b = 12))
        val email = input("Email"); val pass = input("Password", secret = true)
        val c = card(); c.addView(email); c.addView(pass); col.addView(c, lp(b = 14))
        col.addView(btn("Sign in") {
            val e = email.text.toString().trim(); val p = pass.text.toString()
            if (e.isEmpty() || p.length < 6) { toast("Enter email and password"); return@btn }
            Thread { val s = Rest.signIn(e, p); ui.post { if (s == null) toast("Sign-in failed") else { session = s; pass.setText(""); stack.clear(); show { dashboard() } } } }.start()
        }, lp())
    }

    private fun dashboard(): View = scaffold("Dashboard") { col ->
        fun item(title: String, sub: String, open: () -> View) { val c = card(); c.addView(tv(title, 17f, true)); c.addView(tv(sub, 13f, color = SUB)); c.setOnClickListener { push(open) }; col.addView(c, lp(b = 10)) }
        item("Ads & networks", "Turn ads and ad types on or off") { adsScreen() }
        item("Startup message", "Pop-up shown when the app opens") { form("Startup message", "popup", listOf(F("enabled", "Show the message", BOOL), F("id", "Message id (change it to show again)", TEXT), F("title", "Title", TEXT), F("message", "Message", LONG), F("buttonText", "Button text", TEXT), F("url", "Button link (https only)", TEXT), F("dismissable", "User can close it", BOOL))) }
        item("App update", "Tell users a new version is on Google Play") { form("App update", "update", listOf(F("latestVersionCode", "Latest version code (number)", NUM), F("versionName", "Version name", TEXT), F("playUrl", "Google Play link (https)", TEXT), F("force", "Force update (cannot close)", BOOL), F("message", "Message", LONG))) }
        item("Feature switches", "Switch app features on or off") { form("Feature switches", "features", listOf(F("translate", "Translate", BOOL), F("stickers", "Stickers", BOOL), F("fonts", "Fonts & styles", BOOL), F("voice", "Voice typing", BOOL))) }
        item("Voice corrections", "Fix words the speech service gets wrong") { voiceScreen() }
        item("Write default settings", "Creates every setting with safe defaults") { seedScreen() }
        item("Instructions", "Formats, steps and security notes") { helpScreen() }
        col.addView(btn("Sign out", false) { session = null; stack.clear(); show { loginScreen() } }, lp(t = 6))
    }

    private fun adsScreen(): View = scaffold("Ads & networks") { col ->
        col.addView(tv("Ads are only switched on here. Each network needs its SDK added to the app before it can show anything; until then these settings are stored and ignored.", 13.5f, color = SUB), lp(b = 12))
        fun item(t: String, open: () -> View) { val c = card(); c.addView(tv(t, 17f, true)); c.setOnClickListener { push(open) }; col.addView(c, lp(b = 10)) }
        item("General (master switch, ad types)") { form("General", "ads", listOf(F("enabled", "Ads enabled", BOOL), F("mix", "Mix all enabled networks", BOOL))) }
        item("Ad types") { form("Ad types", "ads/placements", listOf(F("banner", "Banner", BOOL), F("interstitial", "Interstitial", BOOL), F("rewarded", "Rewarded", BOOL), F("native", "Native", BOOL))) }
        val net = listOf(F("enabled", "Network on", BOOL), F("appKey", "App ID / key", TEXT), F("banner", "Banner unit", TEXT), F("interstitial", "Interstitial unit", TEXT), F("rewarded", "Rewarded unit", TEXT), F("native", "Native unit", TEXT))
        item("AdMob") { form("AdMob", "ads/networks/admob", net) }
        item("InMobi") { form("InMobi", "ads/networks/inmobi", net) }
        item("Unity LevelPlay (ironSource)") { form("Unity LevelPlay", "ads/networks/unity", net) }
    }

    private class F(val key: String, val label: String, val type: Int)
    private val BOOL = 0; private val TEXT = 1; private val NUM = 2; private val LONG = 3

    private fun form(title: String, path: String, fields: List<F>): View = scaffold(title) { col ->
        val views = HashMap<String, View>()
        fields.forEach { f ->
            val c = card()
            c.addView(tv(f.label, 13f, color = SUB))
            val v: View = when (f.type) {
                BOOL -> Switch(this).apply { text = "" }
                NUM -> input("0").apply { inputType = InputType.TYPE_CLASS_NUMBER }
                LONG -> input("", multi = true)
                else -> input("")
            }
            views[f.key] = v; c.addView(v); col.addView(c, lp(b = 10))
        }
        Thread {
            val o = try { Rest.get("evotype/public/config/$path")?.let { JSONObject(it) } } catch (e: Exception) { null }
            ui.post { if (o != null) fields.forEach { f ->
                val v = views[f.key]; val x = o.opt(f.key)
                if (v is Switch) v.isChecked = o.optBoolean(f.key, false) else if (v is EditText && x != null) v.setText(x.toString()) } }
        }.start()
        col.addView(btn("Save") {
            val s = session ?: return@btn
            val out = JSONObject()
            fields.forEach { f ->
                val v = views[f.key]
                when {
                    v is Switch -> out.put(f.key, v.isChecked)
                    v is EditText && f.type == NUM -> out.put(f.key, v.text.toString().toLongOrNull() ?: 0L)
                    v is EditText -> out.put(f.key, v.text.toString().trim().take(600))
                }
            }
            if (out.optString("url").let { it.isNotEmpty() && !it.startsWith("https://") } || out.optString("playUrl").let { it.isNotEmpty() && !it.startsWith("https://") }) { toast("Links must start with https://"); return@btn }
            Thread { val ok = Rest.write("PATCH", "evotype/public/config/$path", out.toString(), s.idToken); ui.post { toast(if (ok) "Saved" else "Not saved (check sign-in / rules)") } }.start()
        }, lp(t = 4))
    }

    private fun voiceScreen(): View = scaffold("Voice corrections") { col ->
        col.addView(tv("One correction per line:  wrong=right\nExample:  নাম্বার খাবার=নাম্বার কভার\nThe keyboard applies these to voice results (Bangla and Banglish).", 13.5f, color = SUB), lp(b = 10))
        val box = input("wrong=right", multi = true).apply { minLines = 10 }
        val c = card(); c.addView(box); col.addView(c, lp(b = 12))
        Thread {
            val o = try { Rest.get("evotype/public/config/voiceFixes")?.let { JSONObject(it) } } catch (e: Exception) { null }
            ui.post { if (o != null) box.setText(o.keys().asSequence().joinToString("\n") { "$it=${o.optString(it)}" }) }
        }.start()
        col.addView(btn("Save") {
            val s = session ?: return@btn
            val m = JSONObject()
            box.text.toString().lines().forEach { line ->
                val i = line.indexOf('='); if (i <= 0) return@forEach
                val k = line.substring(0, i).trim().replace(Regex("[.$#\\[\\]/]"), " ").take(80); val v = line.substring(i + 1).trim().take(80)
                if (k.isNotEmpty() && v.isNotEmpty()) m.put(k, v)
            }
            Thread { val ok = Rest.write("PUT", "evotype/public/config/voiceFixes", m.toString(), s.idToken); ui.post { toast(if (ok) "Saved ${m.length()} corrections" else "Not saved") } }.start()
        })
    }

    private fun seedScreen(): View = scaffold("Default settings") { col ->
        col.addView(tv("This writes the whole settings tree with safe defaults (ads OFF). It replaces what is in /evotype/public/config, so use it once when setting up.", 14f, color = SUB), lp(b = 12))
        col.addView(btn("Write defaults now") {
            val s = session ?: return@btn
            fun net(on: Boolean, key: String, banner: String, inter: String, rew: String, nat: String) = JSONObject().put("enabled", on).put("appKey", key).put("banner", banner).put("interstitial", inter).put("rewarded", rew).put("native", nat)
            val cfg = JSONObject()
                .put("ads", JSONObject().put("enabled", false).put("mix", true)
                    .put("placements", JSONObject().put("banner", true).put("interstitial", true).put("rewarded", true).put("native", true))
                    .put("networks", JSONObject().put("admob", net(false, "", "", "", "", ""))
                        .put("inmobi", net(false, "10000256543", "10000884502", "10000884500", "10000884503", "10000884505"))
                        .put("unity", net(true, "29a3be2a5", "zvhnp37yy35nta04", "k1swbeity8x8mu4a", "8kr0n2ms6zxqwr44", "tmguj4869hlwfjal"))))
                .put("popup", JSONObject().put("enabled", false).put("id", "1").put("title", "").put("message", "").put("buttonText", "OK").put("url", "").put("dismissable", true))
                .put("update", JSONObject().put("latestVersionCode", 0).put("versionName", "").put("playUrl", "").put("force", false).put("message", ""))
                .put("features", JSONObject().put("translate", true).put("stickers", true).put("fonts", true).put("voice", true))
                .put("voiceFixes", JSONObject().put("নাম্বার খাবার", "নাম্বার কভার"))
            Thread { val ok = Rest.write("PUT", "evotype/public/config", cfg.toString(), s.idToken); ui.post { toast(if (ok) "Defaults written" else "Not saved (check sign-in / rules)") } }.start()
        })
    }

    private fun helpScreen(): View = scaffold("Instructions") { col ->
        fun block(t: String, body: String) { val c = card(); c.addView(tv(t, 17f, true)); c.addView(tv(body, 14f, color = SUB).apply { setPadding(0, d(4), 0, 0) }); col.addView(c, lp(b = 10)) }
        block("First-time setup", "1. Firebase console > Authentication > turn on Email/Password and add your admin user.\n2. Copy that user's UID.\n3. Realtime Database > Rules: merge the rules from firebase/database.rules.json (put your UID in), keep your other apps' rules.\n4. Sign in here and tap Write default settings.")
        block("Startup message", "Turn it on, write a title and message. Change the id to show the message again to everyone. Links must be https.")
        block("App update", "After you publish a new version on Google Play, set the latest version code (the number in Gradle), the Play link and a message. Users on an older version see an update prompt. Force blocks closing it.")
        block("Ads", "Switch the master switch, ad types and each network here. If more than one network is on, the app mixes them. Ad SDK adapters must be added to the app first.")
        block("Voice corrections", "Add wrong=right lines. Longer phrases are matched first.")
        block("Themes, stickers, languages", "Not editable from here yet: they need file hosting (Realtime Database is not meant for images, videos or zip files). Planned: store small JSON definitions here and link to https files.")
        block("Security", "Only the admin UID can write. The keyboard app can only read /evotype/public. Never put a Firebase service-account key in any app.")
    }
}
