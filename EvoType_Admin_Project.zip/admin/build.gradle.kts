plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.evolve.keyboard.admin"
    compileSdk = 34
    defaultConfig {
        applicationId = "evotypekeyboard.admin.com"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
// No Firebase SDK and no service-account key: the admin signs in with email + password and talks to the Realtime Database over HTTPS.
