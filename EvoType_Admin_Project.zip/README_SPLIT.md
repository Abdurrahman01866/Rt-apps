# EvoType_Admin_Project

Split package from the uploaded Android Studio project.
Included module: `admin`

## Build
Open this folder in Android Studio and sync Gradle. Android SDK 34 and Java 17 are required.
Build the APK from Android Studio.

Application ID: `evotypekeyboard.admin.com`

## Status
This package is only a project split/package, not the requested UI/features upgrade.
It has not been compiled or tested yet.
