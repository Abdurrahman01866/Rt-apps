# Evolve Keyboard (work in progress, first pass)

Native Android keyboard (Kotlin, `InputMethodService`). **Status: source written but NOT yet compiled or run** —
the authoring environment had no Android SDK/Gradle/network. Expect to fix compile errors on first build.

## Build
1. Open the folder in Android Studio (Koala or newer, JDK 17). Let it sync (it will fetch Gradle 8.7 and generate the wrapper scripts; `gradlew` / `gradle-wrapper.jar` are not included).
2. Run `app` on a device/emulator, or `gradle testDebugUnitTest` for the engine + clipboard unit tests.
3. Open the app → "Open keyboard settings" → enable Evolve Keyboard → "Choose keyboard".

Versions: AGP 8.5.2, Kotlin 1.9.24, Gradle 8.7, compile/target SDK 34, min SDK 24. No third-party runtime dependencies.

## Implemented (unverified on device)
- App: animated splash, 5-step onboarding (enable, select, optional microphone), home dashboard, Languages (enable/reorder), Themes (live previews), Settings (vibration, double-space, height, long-press delay), Clipboard, Banglish converter playground, About/Privacy.
- Keyboard: English QWERTY with corner hint characters, Bangla 3-page layout (hold arrow = full panel), long-press variants, 5 themes applied live, emoji panel with recents, text-editing panel, clipboard (recent 1h / pinned persistent), voice typing (SpeechRecognizer), icon toolbar.
- Space bar: swipe slides language labels with arrows; right = previous language, left = next.
- Banglish mode = type Bangla, text appears in Roman letters (আমি -> Ami) with spelling alternatives; "ফোনেটিক" mode (Roman -> Bangla) kept as an optional extra language.

## Not implemented yet
Emoji search; editing pinned text; key sounds; multi-touch typing; Room/DataStore (SharedPreferences used); accessibility and multi-screen testing; custom colours/background themes; downloadable language packs (all data is built in).

## Known limitations
- Long-press default is 500 ms (adjustable 300-1500 ms in Settings).
- Clipboard capture works only while the keyboard is the focused IME (Android 10+ restriction); no background monitoring.
- Banglish rules are phonetic + a small built-in dictionary; spelling is not standardised, so alternatives are offered.
- Bangla long-press variants are common orthographic pairs and should be reviewed by a native speaker.
