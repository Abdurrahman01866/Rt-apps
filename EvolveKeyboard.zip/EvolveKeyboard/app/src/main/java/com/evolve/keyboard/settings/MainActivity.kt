package com.evolve.keyboard.settings

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import com.evolve.keyboard.R
import com.evolve.keyboard.banglish.BanglishEngine
import com.evolve.keyboard.clipboard.ClipboardRepository
import com.evolve.keyboard.clipboard.PrefsKeyValueStore
import com.evolve.keyboard.keyboard.KeyboardTheme
import com.evolve.keyboard.ui.Icon
import com.evolve.keyboard.ui.IconView
import com.evolve.keyboard.settings.Ui.MATCH
import com.evolve.keyboard.settings.Ui.WRAP

object Setup {
    fun isEnabled(c: Context) = (c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        .enabledInputMethodList.any { it.packageName == c.packageName }
    fun isSelected(c: Context) = Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        ?.startsWith(c.packageName + "/") == true
    fun micGranted(c: Context) = c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
}

/** One activity, many screens: splash -> onboarding (first run) -> home -> sub-screens. */
class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private var current: (() -> View)? = null
    private val stack = ArrayList<() -> View>()
    private var onboardStep = 0
    private var onboarding = false
    private var micOnly = false
    private val engine = BanglishEngine()
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this); setContentView(root)
        micOnly = intent.getBooleanExtra("mic", false)
        if (micOnly) { onboarding = true; show(Ui.BG, true) { micStep() } } else showSplash()
    }

    override fun onResume() { super.onResume(); if (onboarding) current?.let { show(Ui.BG, true, it) } }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus && onboarding && current != null) show(Ui.BG, true, current!!) }

    override fun onBackPressed() {
        when {
            stack.isNotEmpty() -> { val b = stack.removeAt(stack.lastIndex); show(Ui.BG, true, b) }
            onboarding && onboardStep > 0 && !micOnly -> { onboardStep--; show(Ui.BG, true) { onboardingStep() } }
            else -> super.onBackPressed()
        }
    }

    private fun show(bar: Int, lightBars: Boolean, builder: () -> View) {
        current = builder
        window.statusBarColor = bar; window.navigationBarColor = bar
        window.decorView.systemUiVisibility = if (lightBars) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
        root.removeAllViews(); root.addView(builder(), FrameLayout.LayoutParams(MATCH, MATCH))
    }
    private fun push(builder: () -> View) { current?.let { stack.add(it) }; show(Ui.BG, true, builder) }
    private fun d(v: Int) = Ui.dp(this, v)

    // ------------------------------------------------------------------ splash

    private fun showSplash() {
        show(Ui.BRAND[1], false) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, Ui.BRAND)
            }
            val logo = ImageView(this).apply { setImageResource(R.drawable.evolve_icon); alpha = 0f; scaleX = 0.8f; scaleY = 0.8f }
            col.addView(logo, LinearLayout.LayoutParams(d(124), d(124)))
            val name = Ui.text(this, "Evolve Keyboard", 28f, Color.WHITE, true).apply { alpha = 0f }
            col.addView(name, Ui.lp(this, WRAP, WRAP, t = 24))
            val tag = Ui.text(this, "বাংলা  •  Banglish  •  English", 15f, Color.argb(210, 255, 255, 255)).apply { alpha = 0f }
            col.addView(tag, Ui.lp(this, WRAP, WRAP, t = 6))
            logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(600).start()
            name.animate().alpha(1f).setStartDelay(250).setDuration(500).start()
            tag.animate().alpha(1f).setStartDelay(450).setDuration(500).start()
            ui.postDelayed({ if (!isFinishing) route() }, 1500)
            col
        }
    }

    private fun route() { if (Prefs.onboarded(this)) { onboarding = false; showHome() } else { onboarding = true; onboardStep = 0; show(Ui.BG, true) { onboardingStep() } } }
    private fun showHome() { onboarding = false; stack.clear(); show(Ui.BG, true) { home() } }

    // ------------------------------------------------------------------ onboarding

    private fun onboardingStep(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(24), d(20), d(24), d(24)); setBackgroundColor(Ui.BG) }
        val dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        for (i in 0 until 5) dots.addView(View(this).apply {
            background = Ui.rounded(this@MainActivity, if (i <= onboardStep) Ui.BLUE else Color.parseColor("#CBD3EC"), 4)
        }, Ui.lp(this, d(if (i == onboardStep) 26 else 8), d(8), l = 4, r = 4))
        page.addView(dots, Ui.lp(this, MATCH, WRAP, b = 12))

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val foot = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun title(s: String) = body.addView(Ui.text(this, s, 26f, Ui.NAVY, true).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 24))
        fun para(s: String) = body.addView(Ui.text(this, s, 16f, Ui.SUB).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 10))
        fun hero(icon: Icon) = body.addView(Ui.badge(this, icon, 104), LinearLayout.LayoutParams(d(104), d(104)))
        fun status(ok: Boolean, yes: String, no: String) = body.addView(Ui.chip(this, if (ok) "✓  $yes" else no, if (ok) Ui.GREEN else Ui.ORANGE), Ui.lp(this, WRAP, WRAP, t = 18))

        when (onboardStep) {
            0 -> {
                body.addView(ImageView(this).apply { setImageResource(R.drawable.evolve_wordmark); adjustViewBounds = true; contentDescription = "Evolve Keyboard" }, Ui.lp(this, MATCH, WRAP))
                title("Type your way, beautifully")
                para("Bangla, Banglish and English in one fast, private keyboard.")
                val feats = Ui.card(this)
                listOf(Icon.GLOBE to "Switch languages with a swipe on the space bar", Icon.EDIT to "Bangla ⇄ Banglish conversion, fully offline",
                    Icon.SHIELD to "No ads and no internet permission").forEachIndexed { i, (ic, s) ->
                    val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                    row.addView(Ui.badge(this, ic, 36), LinearLayout.LayoutParams(d(36), d(36)))
                    row.addView(Ui.text(this, s, 15f), Ui.lp(this, MATCH, WRAP, l = 12))
                    feats.addView(row, Ui.lp(this, t = if (i == 0) 0 else 14))
                }
                body.addView(feats, Ui.lp(this, t = 24))
                foot.addView(Ui.primaryButton(this, "Get started") { onboardStep = 1; show(Ui.BG, true) { onboardingStep() } })
            }
            1 -> {
                val on = Setup.isEnabled(this)
                hero(Icon.KEYBOARD); title("Turn on Evolve Keyboard")
                para("Switch Evolve on once in Android's keyboard list. Android shows the same generic warning for every keyboard — Evolve has no internet permission, so it cannot send what you type anywhere.")
                status(on, "Enabled", "Not enabled yet")
                foot.addView(Ui.primaryButton(this, if (on) "Next" else "Open keyboard settings") {
                    if (on) { onboardStep = 2; show(Ui.BG, true) { onboardingStep() } } else startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
                })
            }
            2 -> {
                val sel = Setup.isSelected(this)
                hero(Icon.GLOBE); title("Make it your keyboard")
                para("Pick Evolve Keyboard in the chooser so it opens whenever you type.")
                status(sel, "Selected", "Not selected yet")
                foot.addView(Ui.primaryButton(this, if (sel) "Next" else "Choose keyboard") {
                    if (sel) { onboardStep = 3; show(Ui.BG, true) { onboardingStep() } }
                    else (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                })
            }
            3 -> return micStep()
            else -> {
                hero(Icon.CHECK); title("You're all set")
                para("Open any text box. Swipe the space bar to change language, and tap the icons above the keys for clipboard, emoji, themes and voice.")
                foot.addView(Ui.primaryButton(this, "Open Evolve") { Prefs.setOnboarded(this, true); showHome() })
            }
        }
        page.addView(ScrollView(this).apply { isFillViewport = true; addView(body) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        page.addView(foot, Ui.lp(this, t = 16))
        return page
    }

    private fun micStep(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(24), d(20), d(24), d(24)); setBackgroundColor(Ui.BG) }
        val ok = Setup.micGranted(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        body.addView(Ui.badge(this, Icon.MIC, 104), LinearLayout.LayoutParams(d(104), d(104)))
        body.addView(Ui.text(this, "Voice typing (optional)", 26f, Ui.NAVY, true).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 24))
        body.addView(Ui.text(this, "Allow the microphone only if you want to dictate. It is used only after you tap the mic key. Speech is handled by your phone's speech service, which may use the internet. Evolve asks for no other permission.", 16f, Ui.SUB).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 10))
        body.addView(Ui.chip(this, if (ok) "✓  Microphone allowed" else "Not allowed", if (ok) Ui.GREEN else Ui.ORANGE), Ui.lp(this, WRAP, WRAP, t = 18))
        page.addView(ScrollView(this).apply { isFillViewport = true; addView(body) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val next = { if (micOnly) finish() else { onboardStep = 4; show(Ui.BG, true) { onboardingStep() } } }
        page.addView(Ui.primaryButton(this, if (ok) (if (micOnly) "Done" else "Next") else "Allow microphone") {
            if (ok) next() else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }, Ui.lp(this, t = 16))
        if (!ok) page.addView(Ui.textButton(this, if (micOnly) "Not now" else "Skip for now") { next() }, Ui.lp(this, t = 4))
        return page
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        current?.let { show(Ui.BG, true, it) }
    }

    // ------------------------------------------------------------------ home

    private fun home(): View {
        val sv = ScrollView(this).apply { setBackgroundColor(Ui.BG) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(20), d(20), d(28)) }
        sv.addView(col)

        val ready = Setup.isEnabled(this) && Setup.isSelected(this)
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(d(18), d(18), d(18), d(18))
            background = Ui.gradient(this@MainActivity, 28); elevation = d(4).toFloat()
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(ImageView(this).apply { setImageResource(R.drawable.evolve_icon) }, LinearLayout.LayoutParams(d(44), d(44)))
        top.addView(Ui.text(this, "Evolve Keyboard", 20f, Color.WHITE, true), Ui.lp(this, 0, WRAP, l = 12, weight = 1f))
        top.addView(Ui.chip(this, if (ready) "● Active" else "● Set up", Color.WHITE).apply {
            background = Ui.rounded(this@MainActivity, Color.argb(60, 255, 255, 255), 16)
            setOnClickListener { if (!ready) { onboarding = true; onboardStep = if (Setup.isEnabled(this@MainActivity)) 2 else 1; show(Ui.BG, true) { onboardingStep() } } }
        })
        hero.addView(top)
        val info = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; elevation = 0f }
        fun infoCol(label: String, value: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(Ui.text(this@MainActivity, label, 12f, Ui.SUB)); addView(Ui.text(this@MainActivity, value, 15f, Ui.NAVY, true))
        }
        info.addView(infoCol("Theme", Prefs.theme(this).name), Ui.lp(this, 0, WRAP, weight = 1f))
        info.addView(infoCol("Languages", Prefs.langs(this).joinToString(" · ") { langName(it) }), Ui.lp(this, 0, WRAP, weight = 1.4f))
        hero.addView(info, Ui.lp(this, t = 16))
        col.addView(hero)

        data class Tile(val icon: Icon, val title: String, val sub: String, val target: () -> View)
        val tiles = listOf(
            Tile(Icon.GLOBE, "Languages", "Order & modes") { languagesScreen() },
            Tile(Icon.THEME, "Themes", "Colours & look") { themesScreen() },
            Tile(Icon.SETTINGS, "Settings", "Feel & behaviour") { settingsScreen() },
            Tile(Icon.CLIPBOARD, "Clipboard", "History & privacy") { clipboardScreen() },
            Tile(Icon.EDIT, "Banglish", "Try the converter") { banglishScreen() },
            Tile(Icon.SHIELD, "About", "Privacy & permissions") { aboutScreen() }
        )
        tiles.chunked(2).forEach { pair ->
            val row = LinearLayout(this)
            pair.forEachIndexed { i, t ->
                val card = Ui.card(this).apply { setOnClickListener { push(t.target) } }
                card.addView(Ui.badge(this, t.icon, 44), LinearLayout.LayoutParams(d(44), d(44)))
                card.addView(Ui.text(this, t.title, 17f, Ui.NAVY, true), Ui.lp(this, t = 12))
                card.addView(Ui.text(this, t.sub, 13f, Ui.SUB), Ui.lp(this, t = 2))
                row.addView(card, Ui.lp(this, 0, WRAP, l = if (i == 1) 6 else 0, r = if (i == 0) 6 else 0, weight = 1f))
            }
            col.addView(row, Ui.lp(this, t = 12))
        }
        val tryCard = Ui.card(this)
        tryCard.addView(Ui.text(this, "Try it here", 17f, Ui.NAVY, true))
        tryCard.addView(EditText(this).apply { hint = "Tap and start typing…"; minLines = 3; gravity = Gravity.TOP; setTextColor(Ui.NAVY) }, Ui.lp(this, t = 8))
        col.addView(tryCard, Ui.lp(this, t = 16))
        return sv
    }

    private fun langName(n: String) = when (n) { "BN" -> "বাংলা"; "EN" -> "English"; "BANGLISH" -> "Banglish"; else -> "ফোনেটিক" }

    // ------------------------------------------------------------------ sub-screens

    private fun scaffold(title: String, fill: (LinearLayout) -> Unit): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(d(12), d(8), d(20), d(8)) }
        bar.addView(IconView(this, Icon.BACK, Ui.NAVY).apply {
            setPadding(d(12), d(12), d(12), d(12)); contentDescription = "Back"; setOnClickListener { onBackPressed() }
        }, LinearLayout.LayoutParams(d(48), d(48)))
        bar.addView(Ui.text(this, title, 22f, Ui.NAVY, true), Ui.lp(this, l = 4))
        page.addView(bar)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(4), d(20), d(28)) }
        fill(col)
        page.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return page
    }

    private fun refresh() { current?.let { show(Ui.BG, true, it) } }

    private fun languagesScreen(): View = scaffold("Languages") { col ->
        val enabled = Prefs.langs(this)
        val info = mapOf(
            "BN" to ("বাংলা" to "Bangla keyboard with three character pages"),
            "EN" to ("English" to "QWERTY with numbers and symbols on long-press"),
            "BANGLISH" to ("Banglish" to "Type Bangla, get Roman letters: আমি → Ami"),
            "PHONETIC" to ("ফোনেটিক" to "Type Roman letters, get Bangla: ami → আমি")
        )
        col.addView(Ui.text(this, "Swipe the space bar left or right to move through these, in this order.", 14f, Ui.SUB), Ui.lp(this, b = 12))
        Prefs.allLangsOrdered(this).forEach { n ->
            val on = n in enabled
            val card = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            t.addView(Ui.text(this, info[n]!!.first, 17f, Ui.NAVY, true)); t.addView(Ui.text(this, info[n]!!.second, 13f, Ui.SUB), Ui.lp(this, t = 2))
            card.addView(t, Ui.lp(this, 0, WRAP, weight = 1f))
            if (on && enabled.size > 1) {
                val i = enabled.indexOf(n)
                fun mv(label: String, delta: Int, ok: Boolean) = Ui.textButton(this, label) {
                    if (ok) { val l = enabled.toMutableList(); l.removeAt(i); l.add(i + delta, n); Prefs.setLangs(this, l); refresh() }
                }.apply { alpha = if (ok) 1f else 0.3f; minWidth = d(40) }
                card.addView(mv("▲", -1, i > 0)); card.addView(mv("▼", 1, i < enabled.lastIndex))
            }
            card.addView(Switch(this).apply {
                isChecked = on; contentDescription = info[n]!!.first
                setOnCheckedChangeListener { _, v ->
                    val l = enabled.toMutableList()
                    if (v && n !in l) l.add(n) else if (!v) l.remove(n)
                    if (l.isEmpty()) { isChecked = true } else { Prefs.setLangs(this@MainActivity, l); refresh() }
                }
            })
            col.addView(card, Ui.lp(this, b = 10))
        }
        val note = Ui.card(this)
        note.addView(Ui.text(this, "Language data", 16f, Ui.NAVY, true))
        note.addView(Ui.text(this, "Everything is built into the app and works offline — there is nothing to download. Spelling suggestions improve as the dictionary grows in future updates.", 14f, Ui.SUB), Ui.lp(this, t = 4))
        col.addView(note, Ui.lp(this, t = 6))
    }

    private fun themesScreen(): View = scaffold("Themes") { col ->
        val cur = Prefs.theme(this).id
        KeyboardTheme.ALL.chunked(2).forEach { pair ->
            val row = LinearLayout(this)
            pair.forEachIndexed { i, t ->
                val card = Ui.card(this).apply { setOnClickListener { Prefs.setTheme(this@MainActivity, t.id); refresh() } }
                card.addView(ThemePreview(this, t), LinearLayout.LayoutParams(MATCH, d(96)))
                val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                line.addView(Ui.text(this, t.name, 15f, Ui.NAVY, true), Ui.lp(this, 0, WRAP, weight = 1f))
                if (t.id == cur) line.addView(IconView(this, Icon.CHECK, Ui.GREEN), LinearLayout.LayoutParams(d(22), d(22)))
                card.addView(line, Ui.lp(this, t = 10))
                if (t.id == cur) card.background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = d(20).toFloat(); setStroke(d(2), Ui.BLUE) }
                row.addView(card, Ui.lp(this, 0, WRAP, l = if (i == 1) 6 else 0, r = if (i == 0) 6 else 0, weight = 1f))
            }
            if (pair.size == 1) row.addView(View(this), Ui.lp(this, 0, 1, l = 6, weight = 1f))
            col.addView(row, Ui.lp(this, b = 12))
        }
        col.addView(Ui.text(this, "The keyboard switches theme the next time it opens. You can also change it from the palette icon above the keys.", 13f, Ui.SUB))
    }

    private fun settingsScreen(): View = scaffold("Settings") { col ->
        fun switchRow(title: String, sub: String, v: Boolean, set: (Boolean) -> Unit) {
            val card = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            t.addView(Ui.text(this, title, 16f, Ui.NAVY, true)); t.addView(Ui.text(this, sub, 13f, Ui.SUB), Ui.lp(this, t = 2))
            card.addView(t, Ui.lp(this, 0, WRAP, weight = 1f))
            card.addView(Switch(this).apply { isChecked = v; contentDescription = title; setOnCheckedChangeListener { _, c -> set(c) } })
            col.addView(card, Ui.lp(this, b = 10))
        }
        fun sliderRow(title: String, max: Int, progress: Int, label: (Int) -> String, save: (Int) -> Unit) {
            val card = Ui.card(this)
            val head = LinearLayout(this)
            head.addView(Ui.text(this, title, 16f, Ui.NAVY, true), Ui.lp(this, 0, WRAP, weight = 1f))
            val value = Ui.text(this, label(progress), 14f, Ui.BLUE, true); head.addView(value)
            card.addView(head)
            card.addView(SeekBar(this).apply {
                this.max = max; this.progress = progress; contentDescription = title
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { value.text = label(p); if (fromUser) save(p) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }, Ui.lp(this, t = 8))
            col.addView(card, Ui.lp(this, b = 10))
        }
        switchRow("Vibration", "Small buzz on each key press", Prefs.haptic(this)) { Prefs.setHaptic(this, it) }
        switchRow("Double-space period", "Two quick spaces insert “. ” (or “।” in Bangla)", Prefs.doubleSpace(this)) { Prefs.setDoubleSpace(this, it) }
        sliderRow("Keyboard height", 50, Prefs.heightPercent(this) - 80, { "${80 + it}%" }) { Prefs.setHeightPercent(this, 80 + it) }
        sliderRow("Long-press delay", 12, (Prefs.longPressMs(this) - 300) / 100, { "${300 + it * 100} ms" }) { Prefs.setLongPressMs(this, 300 + it * 100) }
    }

    private fun clipboardScreen(): View = scaffold("Clipboard") { col ->
        val repo = ClipboardRepository(PrefsKeyValueStore(this))
        val c = Ui.card(this)
        c.addView(Ui.text(this, "How it works", 17f, Ui.NAVY, true))
        c.addView(Ui.text(this, "Open the clipboard icon above the keys. Recent items disappear after one hour. Pin the ones you need — pinned items stay until you remove them.", 14f, Ui.SUB), Ui.lp(this, t = 4))
        c.addView(Ui.text(this, "${repo.recent().size} recent  ·  ${repo.pinned().size} pinned", 15f, Ui.BLUE, true), Ui.lp(this, t = 12))
        col.addView(c, Ui.lp(this, b = 10))
        val p = Ui.card(this)
        p.addView(Ui.text(this, "Privacy", 17f, Ui.NAVY, true))
        p.addView(Ui.text(this, "Only text copied while Evolve is on screen is saved, only on this device, and never from password fields. Android blocks background clipboard reading, so copies made while another keyboard is active are not captured.", 14f, Ui.SUB), Ui.lp(this, t = 4))
        col.addView(p, Ui.lp(this, b = 16))
        col.addView(Ui.primaryButton(this, "Clear all clipboard data") {
            AlertDialog.Builder(this).setTitle("Clear clipboard data?").setMessage("This removes recent and pinned items.")
                .setPositiveButton("Clear") { _, _ -> repo.clearAll(); refresh() }.setNegativeButton("Cancel", null).show()
        })
    }

    private fun banglishScreen(): View = scaffold("Banglish converter") { col ->
        fun converter(title: String, hint: String, convert: (String) -> String) {
            val card = Ui.card(this)
            card.addView(Ui.text(this, title, 17f, Ui.NAVY, true))
            val out = Ui.text(this, "", 20f, Ui.BLUE, true)
            card.addView(EditText(this).apply {
                this.hint = hint; setTextColor(Ui.NAVY)
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) { out.text = convert(s?.toString().orEmpty()) }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
            }, Ui.lp(this, t = 6))
            card.addView(out, Ui.lp(this, t = 8))
            col.addView(card, Ui.lp(this, b = 12))
        }
        converter("Bangla → Banglish", "Type Bangla, e.g. আমার নাম") { engine.toBanglishText(it) }
        converter("Banglish → বাংলা", "Type Roman letters, e.g. tumi kemon acho") { engine.toBanglaText(it) }
        col.addView(Ui.text(this, "On the keyboard: add Banglish in Languages, then type with the Bangla keys — your words appear in Roman letters. Roman spelling isn't standardised, so tap a suggestion above the keys to pick another spelling.", 14f, Ui.SUB))
    }

    private fun aboutScreen(): View = scaffold("About & privacy") { col ->
        col.addView(ImageView(this).apply { setImageResource(R.drawable.evolve_wordmark); adjustViewBounds = true }, Ui.lp(this, b = 8))
        col.addView(Ui.text(this, "Version 0.1.0", 13f, Ui.SUB).apply { gravity = Gravity.CENTER }, Ui.lp(this, b = 16))
        fun block(title: String, body: String) {
            val c = Ui.card(this); c.addView(Ui.text(this, title, 17f, Ui.NAVY, true)); c.addView(Ui.text(this, body, 14f, Ui.SUB), Ui.lp(this, t = 4))
            col.addView(c, Ui.lp(this, b = 10))
        }
        block("Your typing stays on your phone", "Evolve has no internet permission, no analytics, and does not log keystrokes. Conversion and clipboard history run locally. Password fields get no suggestions and no clipboard capture.")
        block("Permissions", "Microphone — optional, only for voice typing. Nothing else is requested.")
        block("Voice typing", "Uses Android's speech recognition. Depending on your phone, audio may be processed online by that service.")
        block("Assets", "Icons are drawn in code; the logo and wordmark were supplied by the project owner.")
    }
}
