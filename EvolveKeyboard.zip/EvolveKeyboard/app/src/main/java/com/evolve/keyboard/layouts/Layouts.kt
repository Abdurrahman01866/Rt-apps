package com.evolve.keyboard.layouts

import com.evolve.keyboard.keyboard.Key
import com.evolve.keyboard.keyboard.KeyAction
import com.evolve.keyboard.keyboard.KeyStyle
import com.evolve.keyboard.keyboard.KeyboardTheme
import com.evolve.keyboard.ui.Icon

object Layouts {
    private const val DA = "\u09DC"      // ড়
    private const val DHA = "\u09DD"     // ঢ়
    private const val YA = "\u09DF"      // য়
    private const val DOTTED = "\u25CC"
    const val ROWS = 5                    // every panel is padded to this many rows so the keyboard height stays stable

    private val EN_VARIANTS = mapOf(
        'a' to listOf("à", "á", "â", "ä", "ã", "å"), 'e' to listOf("è", "é", "ê", "ë"),
        'i' to listOf("ì", "í", "î", "ï"), 'o' to listOf("ò", "ó", "ô", "ö", "õ"),
        'u' to listOf("ù", "ú", "û", "ü"), 'c' to listOf("ç"), 'n' to listOf("ñ"), 's' to listOf("ß")
    )
    private val TOP_ROW_SYMBOLS = "qwertyuiop".mapIndexed { i, c -> c to ((i + 1) % 10).toString() }.toMap()
    private val SECOND_ROW_SYMBOLS = mapOf('a' to "@", 's' to "#", 'd' to "&", 'f' to "*", 'g' to "-", 'h' to "!", 'j' to "?", 'k' to "(", 'l' to ")")
    private val THIRD_ROW_SYMBOLS = mapOf('z' to "\"", 'x' to "'", 'c' to ":", 'v' to ";", 'b' to "/", 'n' to "+", 'm' to "%")

    /** Long-press alternatives: well-known aspirated/retroflex/nasal/sibilant pairs and nukta forms. Review with a native speaker. */
    private val BN_VARIANTS = mapOf(
        "ড" to listOf(DA, "ঢ"), "ঢ" to listOf(DHA), "য" to listOf(YA), "প" to listOf("ফ"),
        "ক" to listOf("খ", "ক্ষ"), "গ" to listOf("ঘ"), "চ" to listOf("ছ"), "জ" to listOf("ঝ", "জ্ঞ"),
        "ট" to listOf("ঠ"), "দ" to listOf("ধ"), "ত" to listOf("ৎ", "থ"), "ন" to listOf("ণ", "ঞ", "ঙ"),
        "ব" to listOf("ভ"), "স" to listOf("শ", "ষ"), "র" to listOf(DA), "হ" to listOf("ঃ"),
        "ই" to listOf("ঈ"), "উ" to listOf("ঊ"), "ও" to listOf("ঔ"), "এ" to listOf("ঐ"), "অ" to listOf("আ")
    )
    private val BN_ALL_CHARS = ("অ আ ই ঈ উ ঊ ঋ এ ঐ ও ঔ ক খ গ ঘ ঙ চ ছ জ ঝ ঞ ট ঠ ড ঢ ণ ত থ দ ধ ন প ফ ব ভ ম য র ল শ ষ স হ " +
        "$DA $DHA $YA ৎ ং ঃ ঁ ্ া ি ী ু ূ ৃ ে ৈ ো ৌ ০ ১ ২ ৩ ৪ ৫ ৬ ৭ ৮ ৯ । ৳").split(" ")
    private val KARS = "া ি ী ু ূ ৃ ে ৈ ো ৌ".split(" ")

    val EMOJI_TABS = listOf(
        "😀" to "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😎 🤩 🥳 😏 😢 😭 😡 🤔",
        "👍" to "👍 👎 👌 ✌ 🤞 🙏 👏 🙌 💪 👋 🤝 ✋ 👊 🤙 👆 👇 👀 🧠 🫶 🫡 🤷 💃 🕺 🙈",
        "❤" to "❤ 🧡 💛 💚 💙 💜 🖤 🤍 💔 💕 💖 💗 💘 💝 💯 ✨ 🔥 ⭐ 🌟 🎉 🎊 🎁 🏆 ✅",
        "🐶" to "🐶 🐱 🐭 🐰 🦊 🐻 🐼 🐯 🌹 🌸 🌻 🌴 🍀 🌙 ☀ 🌈 🍎 🍌 🍉 🍕 🍔 🍟 ☕ 🎂",
        "🚗" to "🚗 ✈ 🚀 🏠 📱 💻 📷 🎧 📚 ✏ 📌 🔑 💡 💰 🎮 ⚽ 🇧🇩 ⏰ 🔔 📍 🧳 🛒 💬 ✉"
    )

    private fun ch(s: String, w: Float = 1f, variants: List<String> = emptyList()) = Key(s, KeyAction.CHAR, s, w, variants)
    private fun fn(label: String, a: KeyAction, w: Float = 1.3f, longAction: KeyAction? = null, active: Boolean = false, desc: String = label, icon: Icon? = null) =
        Key(label, a, "", w, emptyList(), if (active) KeyStyle.ACTIVE else KeyStyle.FUNCTION, longAction, 0, desc, icon)
    private fun spacer(w: Float) = Key("", KeyAction.NONE, "", w, style = KeyStyle.SPACER)
    private fun space(cur: String, prev: String, next: String, w: Float) =
        Key(cur, KeyAction.SPACE, " ", w, description = "Space", prev = prev, next = next)
    private fun enterKey() = Key("", KeyAction.ENTER, "", 1.3f, style = KeyStyle.ACCENT, description = "Enter", icon = Icon.ENTER)
    private fun backspace(w: Float = 1.5f) = fn("", KeyAction.DEL, w, desc = "Backspace", icon = Icon.BACKSPACE)
    private fun emojiKey() = fn("", KeyAction.TOOL_EMOJI, 1f, desc = "Emoji", icon = Icon.EMOJI)

    fun pad(rows: List<List<Key>>, n: Int = ROWS): List<List<Key>> {
        val out = rows.toMutableList()
        while (out.size < n) out.add(listOf(spacer(1f)))
        return out
    }

    fun toolbar(hasLangs: Boolean): List<Key> {
        fun t(a: KeyAction, i: Icon, d: String) = Key("", a, "", 1f, style = KeyStyle.TOOL, icon = i, description = d)
        return listOf(
            t(KeyAction.TOOL_CLIP, Icon.CLIPBOARD, "Clipboard"), t(KeyAction.TOOL_EDIT, Icon.EDIT, "Text editing"),
            t(KeyAction.NEXT_LANG, Icon.GLOBE, "Switch language"), t(KeyAction.TOOL_THEME, Icon.THEME, "Themes"),
            t(KeyAction.TOOL_SETTINGS, Icon.SETTINGS, "Settings"), t(KeyAction.TOOL_VOICE, Icon.MIC, "Voice typing")
        )
    }

    private fun bottom(cur: String, prev: String, next: String, left: Key, period: String) = listOf(
        left, emojiKey(), ch(","), space(cur, prev, next, 4f), ch(period), enterKey()
    )

    fun english(shift: Int, cur: String, prev: String, next: String): List<List<Key>> {
        fun letter(c: Char, hint: String?): Key {
            val up = shift != 0
            val t = if (up) c.uppercaseChar().toString() else c.toString()
            val v = (EN_VARIANTS[c] ?: emptyList()).let { if (up) it.map { s -> s.uppercase() } else it }
            return Key(t, KeyAction.CHAR, t, 1f, if (hint != null) listOf(hint) + v else v)
        }
        return listOf(
            "qwertyuiop".map { letter(it, TOP_ROW_SYMBOLS[it]) },
            listOf(spacer(0.5f)) + "asdfghjkl".map { letter(it, SECOND_ROW_SYMBOLS[it]) } + spacer(0.5f),
            listOf(fn("", KeyAction.SHIFT, 1.5f, active = shift != 0, desc = "Shift", icon = Icon.SHIFT)) +
                "zxcvbnm".map { letter(it, THIRD_ROW_SYMBOLS[it]) } + backspace(),
            bottom(cur, prev, next, fn("?123", KeyAction.SYMBOLS1), ".")
        )
    }

    fun symbols1(cur: String, prev: String, next: String) = listOf(
        "1234567890".map { ch(it.toString()) },
        "@#$%&-+()/".map { ch(it.toString()) },
        listOf(fn("=\\<", KeyAction.SYMBOLS2, 1.5f)) + "*\"':;!?".map { ch(it.toString()) } + backspace(),
        bottom(cur, prev, next, fn("ABC", KeyAction.LETTERS), ".")
    )

    fun symbols2(cur: String, prev: String, next: String) = listOf(
        "~`|•√π÷×¶∆".map { ch(it.toString()) },
        "£¢€¥^°{}[]".map { ch(it.toString()) },
        listOf(fn("?123", KeyAction.SYMBOLS1, 1.5f)) + "=\\<>_©®™".map { ch(it.toString()) } + backspace(),
        bottom(cur, prev, next, fn("ABC", KeyAction.LETTERS), ".")
    )

    private fun bnRow(chars: String) = chars.split(" ").map { ch(it, 1f, BN_VARIANTS[it] ?: emptyList()) }
    private fun bnKarRow() = KARS.map { Key(DOTTED + it, KeyAction.CHAR, it) }

    /** Page 1: main consonants. Page 2: vowels, vowel signs, extra letters. Page 3: numerals, conjunct helpers, punctuation. */
    fun bangla(page: Int, cur: String, prev: String, next: String): List<List<Key>> {
        val rows = when (page) {
            0 -> listOf(bnRow("ক খ গ ঘ ঙ চ ছ জ ঝ ঞ"), bnRow("ট ঠ ড ঢ ণ ত থ দ ধ ন"), bnRow("প ফ ব ভ ম য র ল শ স"))
            1 -> listOf(bnRow("অ আ ই ঈ উ ঊ ঋ এ ঐ ও"), bnKarRow(), bnRow("ষ হ $DA $DHA $YA ৎ ং ঃ ঁ ্"))
            else -> listOf(
                bnRow("০ ১ ২ ৩ ৪ ৫ ৬ ৭ ৮ ৯"),
                listOf(ch("্র"), ch("্য"), ch("র্"), ch("র\u09CD\u200D\u09AF"), ch("্ব"), ch("ক্ষ"), ch("জ্ঞ"), ch("ঙ্গ"), ch("ন্ত"), ch("ঞ্চ")),
                bnRow("। , ? ! ৳ ঽ ় - ( )")
            )
        }
        return rows + listOf(listOf(
            fn("${page + 1}/3 ▸", KeyAction.BN_PAGE, 1.3f, longAction = KeyAction.BN_ALL, desc = "Next Bangla page; hold for all characters"),
            fn("?123", KeyAction.SYMBOLS1, 1.2f), emojiKey(),
            space(cur, prev, next, 3.2f), backspace(1.3f), enterKey()
        ))
    }

    fun banglaAll(): List<List<Key>> {
        val grid = BN_ALL_CHARS.chunked(12).map { r -> r.map { s -> if (s in KARS) Key(DOTTED + s, KeyAction.CHAR, s) else ch(s) } }
        return grid + listOf(listOf(fn("ABC", KeyAction.BACK, 1.5f), Key("", KeyAction.SPACE, " ", 4f, description = "Space"), backspace()))
    }

    fun edit(selecting: Boolean, hasUndoRedo: Boolean): List<List<Key>> {
        fun e(label: String, cmd: String, w: Float = 1f, active: Boolean = false) =
            Key(label, KeyAction.EDIT, cmd, w, style = if (active) KeyStyle.ACTIVE else KeyStyle.NORMAL)
        return pad(listOf(
            listOf(fn("", KeyAction.BACK, 1f, desc = "Back to keyboard", icon = Icon.KEYBOARD), Key("Text editing", KeyAction.NONE, "", 5f, style = KeyStyle.LABEL)),
            listOf(e("Select all", "selectAll", 1.4f), e("Select", "select", 1.2f, selecting), e("Copy", "copy"), e("Cut", "cut"), e("Paste", "paste")),
            if (hasUndoRedo) listOf(e("Undo", "undo"), e("↑", "up"), e("Redo", "redo"), e("Del", "delete")) else listOf(e("↑", "up", 3f), e("Del", "delete")),
            listOf(e("←", "left"), e("↓", "down"), e("→", "right"), e("⌫", "backspace"))
        ))
    }

    fun emoji(tab: Int, recent: List<String>): List<List<Key>> {
        val tabs = (if (recent.isNotEmpty()) listOf("🕘" to recent.joinToString(" ")) else emptyList()) + EMOJI_TABS
        val sel = tab.coerceIn(0, tabs.size - 1)
        val items = tabs[sel].second.split(" ").take(24)
        val tabRow = listOf(fn("ABC", KeyAction.BACK, 1.3f)) + tabs.mapIndexed { i, t ->
            Key(t.first, KeyAction.EMOJI_TAB, "", 1f, style = if (i == sel) KeyStyle.ACTIVE else KeyStyle.FUNCTION, arg = i.toLong())
        }
        val grid = items.chunked(8).map { r -> r.map { Key(it, KeyAction.CHAR, it, 1f, style = KeyStyle.FUNCTION) } }
        return pad(listOf(tabRow) + grid + listOf(listOf(fn("ABC", KeyAction.BACK, 1.5f), Key("", KeyAction.SPACE, " ", 4f, description = "Space"), backspace())).let { it })
    }

    fun themes(currentId: String): List<List<Key>> {
        val keys = KeyboardTheme.ALL.mapIndexed { i, t ->
            Key(t.name, KeyAction.THEME_PICK, "", 1f, style = if (t.id == currentId) KeyStyle.ACTIVE else KeyStyle.NORMAL, arg = i.toLong())
        }
        return pad(listOf(
            listOf(fn("", KeyAction.BACK, 1f, desc = "Back to keyboard", icon = Icon.KEYBOARD), Key("Choose a theme", KeyAction.NONE, "", 5f, style = KeyStyle.LABEL)),
            keys.take(3), keys.drop(3)
        ))
    }

    fun voice(status: String, listening: Boolean): List<List<Key>> = pad(listOf(
        listOf(fn("", KeyAction.BACK, 1f, desc = "Back to keyboard", icon = Icon.KEYBOARD), Key("Voice typing", KeyAction.NONE, "", 5f, style = KeyStyle.LABEL)),
        listOf(Key(status, KeyAction.NONE, "", 1f, style = if (listening) KeyStyle.ACTIVE else KeyStyle.FUNCTION)),
        listOf(Key(if (listening) "Stop" else "Try again", if (listening) KeyAction.VOICE_STOP else KeyAction.VOICE_RETRY, "", 1f, style = KeyStyle.ACCENT, icon = if (listening) null else Icon.MIC))
    ))
}
