package com.evolve.keyboard.service

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import com.evolve.keyboard.banglish.BanglishEngine
import com.evolve.keyboard.clipboard.ClipboardRepository
import com.evolve.keyboard.clipboard.PrefsKeyValueStore
import com.evolve.keyboard.keyboard.Key
import com.evolve.keyboard.keyboard.KeyAction
import com.evolve.keyboard.keyboard.KeyStyle
import com.evolve.keyboard.keyboard.KeyboardTheme
import com.evolve.keyboard.keyboard.KeyboardView
import com.evolve.keyboard.layouts.Layouts
import com.evolve.keyboard.settings.MainActivity
import com.evolve.keyboard.settings.Prefs

class EvolveImeService : InputMethodService(), KeyboardView.Listener {
    /** BN = Bangla typing. BANGLISH = type Bangla, text appears as Roman Banglish. PHONETIC = type Roman letters, text appears as Bangla. */
    private enum class Lang(val label: String) { BN("বাংলা"), EN("English"), BANGLISH("Banglish"), PHONETIC("ফোনেটিক") }
    private enum class Panel { KEYS, SYMBOLS1, SYMBOLS2, BN_ALL, CLIP, EDIT, EMOJI, THEME, VOICE }

    private lateinit var view: KeyboardView
    private lateinit var clipRepo: ClipboardRepository
    private val engine = BanglishEngine()

    private var langs: List<Lang> = listOf(Lang.BN, Lang.EN, Lang.BANGLISH)
    private var lang = Lang.EN
    private var panel = Panel.KEYS
    private var shift = 0
    private var lastShiftTap = 0L
    private var bnPage = 0
    private var selecting = false
    private var clipPinnedTab = false
    private var emojiTab = 0
    private var sensitiveField = false      // password etc.: no suggestions, no clipboard capture
    private var doubleSpace = true

    private val latin = StringBuilder()     // PHONETIC composing buffer (Roman letters)
    private val bnWord = StringBuilder()    // BANGLISH composing buffer (Bangla letters)
    private var capWord = false
    private var candidates: List<String> = emptyList()
    private var lastSpaceAt = 0L
    private val doubleSpaceMs = 400L

    private var recognizer: SpeechRecognizer? = null
    private var voiceStatus = ""
    private var voiceListening = false

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        // Only recorded while this keyboard is showing; Android restricts background clipboard access.
        if (sensitiveField || !isInputViewShown) return@OnPrimaryClipChangedListener
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!t.isNullOrBlank()) clipRepo.addRecent(t)
        if (panel == Panel.CLIP) render()
    }

    override fun onCreate() {
        super.onCreate()
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(clipListener)
        stopVoice()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        view = KeyboardView(this).also { it.listener = this }
        loadSettings()
        render()
        return view
    }

    /** Re-read settings each time the keyboard opens so changes made in the app apply immediately. */
    private fun loadSettings() {
        clipRepo = ClipboardRepository(PrefsKeyValueStore(this))
        langs = Prefs.langs(this).mapNotNull { n -> Lang.values().firstOrNull { it.name == n } }.ifEmpty { listOf(Lang.EN) }
        val saved = Prefs.lang(this)?.let { n -> Lang.values().firstOrNull { it.name == n } }
        lang = if (saved != null && saved in langs) saved else langs.first()
        doubleSpace = Prefs.doubleSpace(this)
        if (::view.isInitialized) {
            view.theme = Prefs.theme(this)
            view.heightScale = Prefs.heightPercent(this) / 100f
            view.longPressMs = Prefs.longPressMs(this).toLong()
            view.haptic = Prefs.haptic(this)
        }
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        loadSettings()
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        sensitiveField = (cls == InputType.TYPE_CLASS_TEXT && variation in listOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        if (sensitiveField && (lang == Lang.BANGLISH || lang == Lang.PHONETIC)) lang = if (Lang.EN in langs) Lang.EN else lang
        resetComposing(); panel = Panel.KEYS; selecting = false; bnPage = 0
        shift = if (info.inputType and InputType.TYPE_TEXT_FLAG_CAP_SENTENCES != 0 && lang == Lang.EN) 1 else 0
        if (::view.isInitialized) render()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        currentInputConnection?.finishComposingText()
        resetComposing(); stopVoice()
        super.onFinishInputView(finishingInput)
    }

    private fun resetComposing() { latin.setLength(0); bnWord.setLength(0); candidates = emptyList() }

    // ---------------- rendering ----------------

    private fun neighbour(delta: Int): String {
        val i = langs.indexOf(lang).coerceAtLeast(0)
        return langs[(i + delta + langs.size) % langs.size].label
    }

    private fun render() {
        val cur = lang.label; val prev = neighbour(-1); val next = neighbour(1)
        var compact = false
        val body: List<List<Key>> = when (panel) {
            Panel.KEYS -> if (lang == Lang.BN || lang == Lang.BANGLISH) Layouts.bangla(bnPage, cur, prev, next) else Layouts.english(shift, cur, prev, next)
            Panel.SYMBOLS1 -> Layouts.symbols1(cur, prev, next)
            Panel.SYMBOLS2 -> Layouts.symbols2(cur, prev, next)
            Panel.BN_ALL -> { compact = true; Layouts.banglaAll() }
            Panel.EDIT -> Layouts.edit(selecting, Build.VERSION.SDK_INT >= 26)
            Panel.CLIP -> clipRows()
            Panel.EMOJI -> Layouts.emoji(emojiTab, Prefs.recentEmoji(this))
            Panel.THEME -> Layouts.themes(Prefs.theme(this).id)
            Panel.VOICE -> Layouts.voice(voiceStatus, voiceListening)
        }
        val showTop = panel == Panel.KEYS || panel == Panel.SYMBOLS1 || panel == Panel.SYMBOLS2
        view.setRows(if (showTop) listOf(topRow()) + body else body, compact)
    }

    private fun topRow(): List<Key> {
        if (candidates.isNotEmpty() && !sensitiveField) {
            return candidates.take(4).mapIndexed { i, c ->
                Key(c, KeyAction.CANDIDATE, c, 1f, style = if (i == 0) KeyStyle.ACCENT else KeyStyle.NORMAL)
            }
        }
        return Layouts.toolbar(langs.size > 1)
    }

    private fun clipRows(): List<List<Key>> {
        val rows = ArrayList<List<Key>>()
        rows.add(listOf(
            Key("", KeyAction.BACK, "", 0.8f, style = KeyStyle.FUNCTION, description = "Back to keyboard", icon = com.evolve.keyboard.ui.Icon.KEYBOARD),
            Key("Recent (1h)", KeyAction.CLIP_TAB_RECENT, "", 1.6f, style = if (!clipPinnedTab) KeyStyle.ACTIVE else KeyStyle.NORMAL),
            Key("Pinned", KeyAction.CLIP_TAB_PINNED, "", 1.6f, style = if (clipPinnedTab) KeyStyle.ACTIVE else KeyStyle.NORMAL)
        ))
        val items = if (clipPinnedTab) clipRepo.pinned() else clipRepo.recent()
        if (items.isEmpty()) {
            rows.add(listOf(Key(if (clipPinnedTab) "No pinned items yet. Pin from Recent." else "Nothing copied in the last hour.",
                KeyAction.NONE, "", 1f, style = KeyStyle.LABEL)))
        }
        for (e in items.take(4)) {
            val one = e.text.replace('\n', ' ')
            rows.add(if (clipPinnedTab) listOf(
                Key(one, KeyAction.CLIP_PASTE, e.text, 5f, arg = e.id),
                Key("▲", KeyAction.CLIP_UP, "", 0.7f, style = KeyStyle.FUNCTION, arg = e.id),
                Key("▼", KeyAction.CLIP_DOWN, "", 0.7f, style = KeyStyle.FUNCTION, arg = e.id),
                Key("Unpin", KeyAction.CLIP_PIN, e.text, 1.2f, style = KeyStyle.FUNCTION, arg = e.id)
            ) else listOf(
                Key(one, KeyAction.CLIP_PASTE, e.text, 5f, arg = e.id),
                Key("Pin", KeyAction.CLIP_PIN, e.text, 1f, style = KeyStyle.FUNCTION, arg = e.id),
                Key("✕", KeyAction.CLIP_DELETE, "", 0.8f, style = KeyStyle.FUNCTION, arg = e.id, description = "Delete")
            ))
        }
        return Layouts.pad(rows)
    }

    // ---------------- key handling ----------------

    override fun onKey(key: Key, variant: String?) {
        val ic = currentInputConnection
        when (key.action) {
            KeyAction.CHAR -> if (ic != null) typeText(ic, variant ?: key.text, fromEmoji = panel == Panel.EMOJI)
            KeyAction.SPACE -> if (ic != null) space(ic)
            KeyAction.DEL -> if (ic != null) backspace(ic)
            KeyAction.ENTER -> if (ic != null) enter(ic)
            KeyAction.SHIFT -> {
                val now = System.currentTimeMillis()
                shift = if (shift == 2) 0 else if (now - lastShiftTap < 350) 2 else if (shift == 1) 0 else 1
                lastShiftTap = now; render()
            }
            KeyAction.SYMBOLS1 -> { panel = Panel.SYMBOLS1; render() }
            KeyAction.SYMBOLS2 -> { panel = Panel.SYMBOLS2; render() }
            KeyAction.LETTERS, KeyAction.BACK -> { stopVoice(); panel = Panel.KEYS; selecting = false; render() }
            KeyAction.BN_PAGE -> { bnPage = (bnPage + 1) % 3; render() }
            KeyAction.BN_ALL -> { panel = Panel.BN_ALL; render() }
            KeyAction.NEXT_LANG -> cycleLanguage(1)
            KeyAction.CANDIDATE -> if (ic != null) acceptCandidate(ic, key.text)
            KeyAction.TOOL_CLIP -> { panel = Panel.CLIP; render() }
            KeyAction.TOOL_EDIT -> { commitPending(ic); panel = Panel.EDIT; render() }
            KeyAction.TOOL_EMOJI -> { commitPending(ic); panel = Panel.EMOJI; emojiTab = 0; render() }
            KeyAction.TOOL_THEME -> { panel = Panel.THEME; render() }
            KeyAction.TOOL_SETTINGS -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            KeyAction.TOOL_VOICE, KeyAction.VOICE_RETRY -> { commitPending(ic); startVoice() }
            KeyAction.VOICE_STOP -> { recognizer?.stopListening(); voiceStatus = "Processing…"; render() }
            KeyAction.EDIT -> if (ic != null) editCommand(ic, key.text)
            KeyAction.EMOJI_TAB -> { emojiTab = key.arg.toInt(); render() }
            KeyAction.THEME_PICK -> {
                val t = KeyboardTheme.ALL[key.arg.toInt()]
                Prefs.setTheme(this, t.id); view.theme = t; render()
            }
            KeyAction.CLIP_TAB_RECENT -> { clipPinnedTab = false; render() }
            KeyAction.CLIP_TAB_PINNED -> { clipPinnedTab = true; render() }
            KeyAction.CLIP_PASTE -> ic?.commitText(key.text, 1)
            KeyAction.CLIP_PIN -> { if (clipPinnedTab) clipRepo.unpin(key.arg) else clipRepo.pin(key.text); render() }
            KeyAction.CLIP_DELETE -> { clipRepo.deleteRecent(key.arg); render() }
            KeyAction.CLIP_UP -> { clipRepo.movePinned(key.arg, -1); render() }
            KeyAction.CLIP_DOWN -> { clipRepo.movePinned(key.arg, 1); render() }
            KeyAction.NONE -> {}
        }
    }

    override fun onSpaceSwipe(direction: Int) = cycleLanguage(direction)

    private fun cycleLanguage(dir: Int) {
        commitPending(currentInputConnection)
        val avail = if (sensitiveField) langs.filter { it == Lang.EN || it == Lang.BN } .ifEmpty { langs } else langs
        lang = avail[(avail.indexOf(lang).coerceAtLeast(0) + dir + avail.size) % avail.size]
        Prefs.setLang(this, lang.name)
        panel = Panel.KEYS; resetComposing(); shift = 0; render()
    }

    private fun isBanglaLetter(c: Char) = c in '\u0980'..'\u09FF' && c != '\u0964' && c !in '\u09E6'..'\u09EF'

    private fun typeText(ic: InputConnection, t: String, fromEmoji: Boolean) {
        if (fromEmoji) {
            ic.commitText(t, 1)
            Prefs.setRecentEmoji(this, (listOf(t) + Prefs.recentEmoji(this).filter { it != t }).take(24)); return
        }
        when {
            lang == Lang.PHONETIC && !sensitiveField && t.length == 1 && t[0].code < 128 && t[0].isLetter() -> {
                latin.append(t.lowercase()); recomposePhonetic(ic)
            }
            lang == Lang.BANGLISH && !sensitiveField && t.all { isBanglaLetter(it) } -> {
                if (bnWord.isEmpty()) capWord = atSentenceStart(ic)
                bnWord.append(t); recomposeBanglish(ic)
            }
            else -> {
                commitPending(ic)
                // In Banglish mode punctuation/digits are written in Roman form too (। -> .)
                ic.commitText(if (lang == Lang.BANGLISH && !sensitiveField) engine.toBanglishCandidates(t).firstOrNull() ?: t else t, 1)
            }
        }
        if (shift == 1) { shift = 0; render() }
    }

    private fun atSentenceStart(ic: InputConnection): Boolean {
        val before = ic.getTextBeforeCursor(3, 0)?.toString().orEmpty()
        return before.isBlank() || before.trimEnd().let { it.endsWith(".") || it.endsWith("?") || it.endsWith("!") } && before.endsWith(" ") || before.endsWith("\n")
    }

    private fun fmt(s: String) = if (capWord) s.replaceFirstChar { it.uppercase() } else s

    private fun recomposePhonetic(ic: InputConnection) {
        if (latin.isEmpty()) { ic.setComposingText("", 1); ic.finishComposingText(); candidates = emptyList(); render(); return }
        candidates = engine.toBanglaCandidates(latin.toString())
        ic.setComposingText(candidates.first(), 1); render()
    }

    private fun recomposeBanglish(ic: InputConnection) {
        if (bnWord.isEmpty()) { ic.setComposingText("", 1); ic.finishComposingText(); candidates = emptyList(); render(); return }
        candidates = engine.toBanglishCandidates(bnWord.toString()).map(::fmt)
        ic.setComposingText(candidates.first(), 1); render()
    }

    private fun commitPending(ic: InputConnection?) {
        if (latin.isNotEmpty()) ic?.commitText(candidates.firstOrNull() ?: engine.toBanglaText(latin.toString()), 1)
        else if (bnWord.isNotEmpty()) ic?.commitText(candidates.firstOrNull() ?: fmt(engine.toBanglishText(bnWord.toString()).lowercase()), 1)
        resetComposing()
    }

    private fun acceptCandidate(ic: InputConnection, text: String) {
        ic.commitText(text, 1); resetComposing(); render()
    }

    private fun space(ic: InputConnection) {
        val hadPending = latin.isNotEmpty() || bnWord.isNotEmpty()
        commitPending(ic)
        val now = System.currentTimeMillis()
        val before = ic.getTextBeforeCursor(2, 0)?.toString().orEmpty()
        val plainText = (currentInputEditorInfo?.inputType ?: 0) and InputType.TYPE_MASK_CLASS == InputType.TYPE_CLASS_TEXT
        if (!hadPending && doubleSpace && plainText && !sensitiveField && now - lastSpaceAt < doubleSpaceMs &&
            before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
            ic.deleteSurroundingText(1, 0)
            ic.commitText(if (lang == Lang.BN) "\u0964 " else ". ", 1); lastSpaceAt = 0
        } else { ic.commitText(" ", 1); lastSpaceAt = now }
        candidates = emptyList(); render()
    }

    private fun backspace(ic: InputConnection) {
        if (latin.isNotEmpty()) { latin.deleteCharAt(latin.length - 1); recomposePhonetic(ic); return }
        if (bnWord.isNotEmpty()) {
            // delete one Bangla character; Android-side grapheme handling is not needed because the buffer holds code points we typed
            bnWord.deleteCharAt(bnWord.length - 1); recomposeBanglish(ic); return
        }
        if (ic.getSelectedText(0).isNullOrEmpty()) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL))
        } else ic.commitText("", 1)
    }

    private fun enter(ic: InputConnection) {
        commitPending(ic)
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = (info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) ic.performEditorAction(action)
        else { ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)); ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER)) }
        candidates = emptyList(); render()
    }

    private fun dpad(ic: InputConnection, code: Int) {
        val meta = if (selecting) KeyEvent.META_SHIFT_ON else 0
        val t = System.currentTimeMillis()
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta))
    }

    private fun editCommand(ic: InputConnection, cmd: String) {
        when (cmd) {
            "select" -> { selecting = !selecting; render() }
            "selectAll" -> ic.performContextMenuAction(android.R.id.selectAll)
            "copy" -> ic.performContextMenuAction(android.R.id.copy)
            "cut" -> ic.performContextMenuAction(android.R.id.cut)
            "paste" -> ic.performContextMenuAction(android.R.id.paste)
            "undo" -> if (Build.VERSION.SDK_INT >= 26) ic.performContextMenuAction(android.R.id.undo)
            "redo" -> if (Build.VERSION.SDK_INT >= 26) ic.performContextMenuAction(android.R.id.redo)
            "left" -> dpad(ic, KeyEvent.KEYCODE_DPAD_LEFT)
            "right" -> dpad(ic, KeyEvent.KEYCODE_DPAD_RIGHT)
            "up" -> dpad(ic, KeyEvent.KEYCODE_DPAD_UP)
            "down" -> dpad(ic, KeyEvent.KEYCODE_DPAD_DOWN)
            "delete" -> { ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_FORWARD_DEL)); ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_FORWARD_DEL)) }
            "backspace" -> backspace(ic)
        }
    }

    // ---------------- voice typing (Android SpeechRecognizer; the recognition provider may need internet) ----------------

    private fun startVoice() {
        stopVoice()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("mic", true)); return
        }
        panel = Panel.VOICE
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            voiceListening = false; voiceStatus = "Speech recognition isn't available on this device"; render(); return
        }
        voiceListening = true; voiceStatus = "Listening… speak now"; render()
        val tag = if (lang == Lang.BN || lang == Lang.BANGLISH) "bn-BD" else "en-US"
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { voiceStatus = "Processing…"; render() }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(code: Int) {
                    voiceListening = false
                    voiceStatus = when (code) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Didn't catch that"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "This speech service needs an internet connection"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is off"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service is busy, try again"
                        else -> "Voice typing failed (code $code)"
                    }
                    render()
                }
                override fun onResults(res: Bundle?) {
                    val text = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    voiceListening = false
                    if (!text.isNullOrBlank()) {
                        currentInputConnection?.commitText(if (lang == Lang.BANGLISH) engine.toBanglishText(text) else text, 1)
                        panel = Panel.KEYS
                    } else voiceStatus = "Didn't catch that"
                    render()
                }
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag))
        }
    }

    private fun stopVoice() { recognizer?.destroy(); recognizer = null; voiceListening = false }
}
