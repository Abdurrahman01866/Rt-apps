package com.evolve.keyboard.settings

import android.content.Context
import com.evolve.keyboard.keyboard.KeyboardTheme

/** All user settings live here (SharedPreferences). The keyboard service re-reads them every time it opens. */
object Prefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("evolve_prefs", Context.MODE_PRIVATE)

    fun theme(c: Context) = KeyboardTheme.byId(sp(c).getString("theme", "evolve"))
    fun setTheme(c: Context, id: String) = sp(c).edit().putString("theme", id).apply()

    /** Enabled languages in switching order. Names: BN, EN, BANGLISH, PHONETIC. */
    fun langs(c: Context): List<String> =
        (sp(c).getString("langs", "BN,EN,BANGLISH") ?: "BN,EN,BANGLISH").split(",").filter { it.isNotBlank() }.ifEmpty { listOf("EN") }
    fun setLangs(c: Context, l: List<String>) = sp(c).edit().putString("langs", l.joinToString(",")).apply()
    fun allLangsOrdered(c: Context): List<String> { val on = langs(c); return on + listOf("BN", "EN", "BANGLISH", "PHONETIC").filter { it !in on } }

    fun lang(c: Context) = sp(c).getString("lang", null)
    fun setLang(c: Context, l: String) = sp(c).edit().putString("lang", l).apply()

    fun haptic(c: Context) = sp(c).getBoolean("haptic", true)
    fun setHaptic(c: Context, v: Boolean) = sp(c).edit().putBoolean("haptic", v).apply()
    fun doubleSpace(c: Context) = sp(c).getBoolean("double_space", true)
    fun setDoubleSpace(c: Context, v: Boolean) = sp(c).edit().putBoolean("double_space", v).apply()
    fun heightPercent(c: Context) = sp(c).getInt("height", 100)
    fun setHeightPercent(c: Context, v: Int) = sp(c).edit().putInt("height", v).apply()
    fun longPressMs(c: Context) = sp(c).getInt("long_press", 500)
    fun setLongPressMs(c: Context, v: Int) = sp(c).edit().putInt("long_press", v).apply()
    fun onboarded(c: Context) = sp(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context, v: Boolean) = sp(c).edit().putBoolean("onboarded", v).apply()
    fun recentEmoji(c: Context): List<String> = (sp(c).getString("emoji_recent", "") ?: "").split(" ").filter { it.isNotBlank() }
    fun setRecentEmoji(c: Context, l: List<String>) = sp(c).edit().putString("emoji_recent", l.joinToString(" ")).apply()
}
