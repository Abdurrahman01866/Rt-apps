package com.evolve.keyboard.keyboard

import com.evolve.keyboard.ui.Icon

enum class KeyAction {
    NONE, CHAR, SHIFT, DEL, ENTER, SPACE, SYMBOLS1, SYMBOLS2, LETTERS, NEXT_LANG, BN_PAGE, BN_ALL, BACK,
    CANDIDATE, TOOL_CLIP, TOOL_EDIT, TOOL_EMOJI, TOOL_THEME, TOOL_VOICE, TOOL_SETTINGS,
    EDIT, CLIP_PASTE, CLIP_PIN, CLIP_DELETE, CLIP_UP, CLIP_DOWN, CLIP_TAB_RECENT, CLIP_TAB_PINNED,
    EMOJI_TAB, THEME_PICK, VOICE_STOP, VOICE_RETRY
}

enum class KeyStyle { NORMAL, FUNCTION, ACCENT, ACTIVE, LABEL, SPACER, TOOL }

data class Key(
    val label: String,
    val action: KeyAction = KeyAction.CHAR,
    val text: String = label,
    val weight: Float = 1f,
    val variants: List<String> = emptyList(),
    val style: KeyStyle = KeyStyle.NORMAL,
    val longAction: KeyAction? = null,
    val arg: Long = 0L,
    val description: String = label,
    val icon: Icon? = null,
    val prev: String = "",       // space bar only: label of the language on the left
    val next: String = ""        // space bar only: label of the language on the right
)
