package com.evolve.keyboard.settings

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.evolve.keyboard.keyboard.KeyboardTheme
import com.evolve.keyboard.ui.Icon
import com.evolve.keyboard.ui.IconView

/** Small design system for the settings app: colours, radii, type scale, and reusable components. */
object Ui {
    val BG = Color.parseColor("#F3F5FF")
    val NAVY = Color.parseColor("#0B1030")
    val SUB = Color.parseColor("#5B6490")
    val BLUE = Color.parseColor("#1F6BFF")
    val VIOLET = Color.parseColor("#7B2FF7")
    val CYAN = Color.parseColor("#00B8F0")
    val GREEN = Color.parseColor("#14B87A")
    val ORANGE = Color.parseColor("#F59E0B")
    val BRAND = intArrayOf(Color.parseColor("#00A4FD"), Color.parseColor("#1230F0"), Color.parseColor("#8A1BF5"))
    const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun lp(c: Context, w: Int = MATCH, h: Int = WRAP, t: Int = 0, b: Int = 0, l: Int = 0, r: Int = 0, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b)) }

    fun rounded(c: Context, color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(c, radius).toFloat() }
    fun gradient(c: Context, radius: Int, colors: IntArray = BRAND) =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(c, radius).toFloat() }

    fun text(c: Context, s: String, sp: Float = 15f, color: Int = NAVY, bold: Boolean = false) = TextView(c).apply {
        text = s; setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.15f)
    }

    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; background = rounded(c, Color.WHITE, 20)
        setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16)); elevation = dp(c, 2).toFloat()
    }

    fun primaryButton(c: Context, label: String, enabled: Boolean = true, onClick: () -> Unit) = TextView(c).apply {
        text = label; setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f); setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER; minHeight = dp(c, 54)
        background = if (enabled) gradient(c, 27, intArrayOf(BLUE, VIOLET)) else rounded(c, Color.parseColor("#B8C0E0"), 27)
        isEnabled = enabled; setOnClickListener { onClick() }
    }

    fun textButton(c: Context, label: String, onClick: () -> Unit) = TextView(c).apply {
        text = label; setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); setTextColor(SUB); gravity = Gravity.CENTER
        minHeight = dp(c, 48); setOnClickListener { onClick() }
    }

    fun chip(c: Context, label: String, color: Int) = TextView(c).apply {
        text = label; setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f); setTextColor(color); setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 6))
        background = rounded(c, Color.argb(30, Color.red(color), Color.green(color), Color.blue(color)), 16)
    }

    fun badge(c: Context, icon: Icon, sizeDp: Int, colors: IntArray = BRAND): FrameLayout = FrameLayout(c).apply {
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { shape = GradientDrawable.OVAL }
        addView(IconView(c, icon, Color.WHITE), FrameLayout.LayoutParams(dp(c, sizeDp * 56 / 100), dp(c, sizeDp * 56 / 100)).apply { gravity = Gravity.CENTER })
        minimumWidth = dp(c, sizeDp); minimumHeight = dp(c, sizeDp)
    }
}

/** Mini keyboard drawn in a theme's real colours, so the preview matches what the keyboard will look like. */
class ThemePreview(context: Context, private val t: KeyboardTheme) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        p.color = t.background; c.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 14 * d, 14 * d, p)
        val rows = 3; val cols = 7; val gap = 4 * d
        val kw = (width - gap * (cols + 1)) / cols; val kh = (height - gap * (rows + 2)) / (rows + 1)
        for (r in 0 until rows) for (i in 0 until cols) {
            p.color = t.key; val x = gap + i * (kw + gap); val y = gap + r * (kh + gap)
            c.drawRoundRect(RectF(x, y, x + kw, y + kh), 4 * d, 4 * d, p)
        }
        val y = gap + rows * (kh + gap)
        p.color = t.function; c.drawRoundRect(RectF(gap, y, gap + kw * 1.6f, y + kh), 4 * d, 4 * d, p)
        p.color = t.key; c.drawRoundRect(RectF(gap * 2 + kw * 1.6f, y, width - gap * 2 - kw * 1.6f, y + kh), 4 * d, 4 * d, p)
        p.color = t.accent; c.drawRoundRect(RectF(width - gap - kw * 1.6f, y, width - gap, y + kh), 4 * d, 4 * d, p)
    }
}
