package com.evolve.keyboard.keyboard

import android.graphics.Color

data class KeyboardTheme(
    val id: String, val name: String,
    val background: Int, val key: Int, val keyText: Int, val function: Int,
    val accent: Int, val accentText: Int, val popup: Int, val label: Int
) {
    companion object {
        private fun c(s: String) = Color.parseColor(s)
        val ALL = listOf(
            KeyboardTheme("evolve", "Evolve Night", c("#0B1030"), c("#1E2759"), Color.WHITE, c("#141B40"), c("#1F6BFF"), Color.WHITE, c("#2B3670"), c("#9AA6D8")),
            KeyboardTheme("snow", "Snow", c("#E8ECF8"), Color.WHITE, c("#0B1030"), c("#CBD3EC"), c("#1F6BFF"), Color.WHITE, Color.WHITE, c("#55608F")),
            KeyboardTheme("violet", "Violet", c("#1A0B3B"), c("#2C1A5C"), Color.WHITE, c("#21124A"), c("#7B2FF7"), Color.WHITE, c("#3B2477"), c("#B8A6E8")),
            KeyboardTheme("forest", "Forest", c("#0E2A22"), c("#1B4034"), Color.WHITE, c("#14352A"), c("#14B87A"), Color.WHITE, c("#25594A"), c("#9CD6C2")),
            KeyboardTheme("minimal", "Minimal", Color.WHITE, c("#F1F2F4"), c("#111111"), c("#E2E4E8"), c("#111111"), Color.WHITE, c("#F1F2F4"), c("#777777"))
        )
        fun byId(id: String?) = ALL.firstOrNull { it.id == id } ?: ALL[0]
    }
}
