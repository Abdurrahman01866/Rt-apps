# Assets
- Launcher icon and wordmark: supplied by the project owner (resized only). Note: the supplied wordmark reads "EvoType Keyboard".
- Toolbar/keys currently use Unicode glyphs; no third-party icon packs are bundled yet.
