# Privacy
- The app declares no INTERNET permission; nothing typed can be sent off-device by this app.
- No analytics, no keystroke logging. Banglish conversion runs locally.
- Clipboard history stores only text copied while Evolve is the active keyboard; recent items are deleted after 1 hour, pinned items stay until removed or app data is cleared.
- Password fields: no suggestions, no clipboard capture.
- Voice typing is not implemented yet; when added it will use Android's SpeechRecognizer, which may send audio to the device's recognition provider.
