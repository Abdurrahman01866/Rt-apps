# Evolve Keyboard (work in progress, v0.2)

Native Android keyboard (Kotlin, `InputMethodService`). **Status: source written but NOT yet compiled or run** — the authoring
environment had no Android SDK/Gradle/network. Expect compile errors on first build; send them back and they will be fixed.

## Build (Android Studio)
1. Install Android Studio (Koala 2024.1 or newer). It bundles JDK 17+; in Settings > Build Tools > Gradle, "Gradle JDK" should be the bundled JDK.
2. File > Open > select the `EvolveKeyboard` folder. Android Studio creates `local.properties` (SDK path) itself, downloads Gradle 8.7 from
   `gradle/wrapper/gradle-wrapper.properties`, and offers to install Android SDK Platform 34 if missing - accept.
3. Wait for "Gradle sync" to finish, then Run `app`. Unit tests: right-click `app/src/test` > Run Tests.
4. `gradlew` / `gradlew.bat` are launchers; `gradle/wrapper/gradle-wrapper.jar` is a binary that could not be produced offline. Android Studio does not need it.
   For command-line builds run once: `gradle wrapper --gradle-version 8.7` (needs Gradle installed), or let `./gradlew` do that for you.
5. First run: open the app, follow onboarding (enable keyboard, choose keyboard, optional microphone).

## What is in v0.2
- **Layouts**: Jatiya (national, QWERTY positions, shift layer, long-press extras), Avro (phonetic, case-sensitive, with a number row = one row taller),
  Evolve classic (3 pages), English, Banglish (type Bangla on Jatiya keys -> Roman text). Order/enable in the app; space-bar swipe slides the language names.
- **Suggestions**: bundled English (~600) and Bangla (~480) word lists + words you type often (local, capped at 1,500, one-offs expire after 30 days,
  never from password/email/URL fields, can be switched off or cleared). One emoji suggestion when a word matches.
- **Emoji**: ~1,900 entries in 10 categories incl. 258 flags, Recent, Suggestions, search with typo tolerance (English + some Bangla keywords).
- **Voice**: animated mic (off/slash, listening rings and bars follow your voice level, processing spinner, error shake).
- **Themes**: 35 (30 animated: aurora, stars, snow, rain, bubbles, waves, fireflies, shimmer, neon, flowing gradients). Animations can be turned off.
- **Tools**: text shortcuts, clipboard (recent 1h / pinned), converter playground, typing insights, one-handed mode, key sound, sliders.

## Not done / limits
- **GIFs/stickers**: not included. Needs a GIF provider (Tenor/GIPHY), an API key and the INTERNET permission, which changes the privacy promise.
- Word lists are small (hundreds, not hundreds of thousands); the format (one word per line, frequency order in `res/raw`) lets them be replaced.
- Avro follows well-known Avro conventions but is an independent implementation; some edge cases will differ from Omicron's Avro.
- Jatiya key positions are based on the Ridmik screenshot supplied; verify against your preferred standard.
- No next-word prediction or autocorrect. No multi-touch typing. Emoji search covers English and a limited set of Bangla keywords.
- SharedPreferences used instead of Room/DataStore. Voice typing uses Android's recogniser and may need internet.
- Not tested on devices, screen sizes, or with accessibility services.
