# Assets
- Launcher icon and wordmark: supplied by the project owner (resized only). Note: the supplied wordmark reads "EvoType Keyboard".
- Toolbar/keys currently use Unicode glyphs; no third-party icon packs are bundled yet.
- Emoji list: Unicode emoji properties (Perl/Unicode 15) and Unicode character names; flag names from Unicode CLDR via Babel (BSD). Word lists were written for this project.
