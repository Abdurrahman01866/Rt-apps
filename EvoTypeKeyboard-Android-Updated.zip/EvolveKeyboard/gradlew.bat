@echo off
setlocal
set APP_HOME=%~dp0
set JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%JAR%" (
  where gradle >nul 2>nul
  if errorlevel 1 (
    echo gradle-wrapper.jar is missing. Open this project in Android Studio, or install Gradle and run: gradle wrapper --gradle-version 8.7
    exit /b 1
  )
  echo Generating gradle-wrapper.jar with the installed gradle...
  pushd "%APP_HOME%" & gradle wrapper --gradle-version 8.7 & popd
)
if defined JAVA_HOME (set JAVACMD=%JAVA_HOME%\bin\java.exe) else (set JAVACMD=java.exe)
"%JAVACMD%" -Xmx64m -Xms64m -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
endlocal
