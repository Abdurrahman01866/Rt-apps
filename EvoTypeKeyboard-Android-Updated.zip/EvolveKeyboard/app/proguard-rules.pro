# Evolve Keyboard: nothing to keep beyond the Android defaults (no reflection, no serialization libraries).
