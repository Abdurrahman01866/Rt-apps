package com.evolve.keyboard.keyboard

import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.LinearLayout
import com.evolve.keyboard.keyboard.PanelParts.dp
import com.evolve.keyboard.settings.ThemePreview

/** Scrollable theme gallery with live mini-keyboard previews. */
class ThemePanel(context: Context) : LinearLayout(context) {
    interface Listener { fun onBack(); fun onTheme(t: KeyboardTheme) }
    var listener: Listener? = null
    private var theme = KeyboardTheme.ALL[0]
    private var currentId = ""
    private val grid = GridView(context)
    private val adapter = object : BaseAdapter() {
        override fun getCount() = KeyboardTheme.ALL.size
        override fun getItem(p: Int) = KeyboardTheme.ALL[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
            val t = KeyboardTheme.ALL[p]
            val cell = LinearLayout(context).apply {
                orientation = VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(context, 5), dp(context, 5), dp(context, 5), dp(context, 5))
                background = if (t.id == currentId) PanelParts.rounded(0x00000000, dp(context, 14).toFloat(), dp(context, 2), theme.accent) else null
                layoutParams = android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 84))
            }
            cell.addView(ThemePreview(context, t), LayoutParams(LayoutParams.MATCH_PARENT, dp(context, 56)))
            cell.addView(PanelParts.text(context, t.name, 11.5f, theme.keyText).apply { maxLines = 1; gravity = Gravity.CENTER }, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 3) })
            return cell
        }
    }

    init { orientation = VERTICAL }

    fun bind(theme: KeyboardTheme) {
        this.theme = theme; currentId = theme.id; removeAllViews(); setBackgroundColor(theme.background)
        addView(PanelParts.header(context, theme, "Themes") { listener?.onBack() }, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        grid.apply { numColumns = 3; horizontalSpacing = dp(context, 6); verticalSpacing = dp(context, 4); stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setPadding(dp(context, 10), 0, dp(context, 10), dp(context, 6)); clipToPadding = false; adapter = this@ThemePanel.adapter
            selector = android.graphics.drawable.ColorDrawable(0); setOnItemClickListener { _, _, p, _ -> val t = KeyboardTheme.ALL[p]; listener?.onTheme(t); this@ThemePanel.theme = t; currentId = t.id; this@ThemePanel.adapter.notifyDataSetChanged() } }
        (grid.parent as? ViewGroup)?.removeView(grid)
        addView(grid, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        adapter.notifyDataSetChanged()
    }
}
