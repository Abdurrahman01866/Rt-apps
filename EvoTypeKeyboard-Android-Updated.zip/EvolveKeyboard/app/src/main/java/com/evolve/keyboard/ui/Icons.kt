package com.evolve.keyboard.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/** Original line icons drawn in code (one consistent stroke weight, no external assets or licences). */
enum class Icon { CLIPBOARD, EDIT, MIC, EMOJI, THEME, GLOBE, SETTINGS, KEYBOARD, SHIFT, BACKSPACE, ENTER, CHECK, INFO, CLOSE, BACK, HOME, SHIELD, BOLT, CHART, PHONE, SPEAKER, SLIDERS, TRASH, PLUS, CHEVRON, SPARKLE, GRID }

object IconPainter {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val path = Path()
    private val r = RectF()

    /** Draws [icon] centred at (cx, cy) inside a square of side [size]. */
    fun draw(c: Canvas, icon: Icon, cx: Float, cy: Float, size: Float, color: Int, filled: Boolean = false) {
        val s = size / 2f
        c.save(); c.translate(cx, cy)
        p.color = color; p.strokeWidth = size * 0.085f; p.style = Paint.Style.STROKE
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(x1 * s, y1 * s, x2 * s, y2 * s, p)
        fun rr(l: Float, t: Float, rt: Float, b: Float, rad: Float) { r.set(l * s, t * s, rt * s, b * s); c.drawRoundRect(r, rad * s, rad * s, p) }
        fun dot(x: Float, y: Float, rad: Float) { p.style = Paint.Style.FILL; c.drawCircle(x * s, y * s, rad * s, p); p.style = Paint.Style.STROKE }
        fun poly(vararg pts: Float, close: Boolean = false) {
            path.reset(); path.moveTo(pts[0] * s, pts[1] * s)
            var i = 2; while (i < pts.size) { path.lineTo(pts[i] * s, pts[i + 1] * s); i += 2 }
            if (close) path.close(); c.drawPath(path, p)
        }
        when (icon) {
            Icon.CLIPBOARD -> { rr(-0.6f, -0.6f, 0.6f, 0.8f, 0.2f); rr(-0.28f, -0.82f, 0.28f, -0.4f, 0.15f); line(-0.3f, 0.05f, 0.3f, 0.05f); line(-0.3f, 0.4f, 0.15f, 0.4f) }
            Icon.EDIT -> { poly(-0.65f, 0.65f, -0.55f, 0.2f, 0.3f, -0.65f, 0.65f, -0.3f, -0.2f, 0.55f, close = true); line(0.05f, -0.4f, 0.4f, -0.05f) }
            Icon.MIC -> { rr(-0.25f, -0.8f, 0.25f, 0.15f, 0.25f); r.set(-0.55f * s, -0.4f * s, 0.55f * s, 0.55f * s); c.drawArc(r, 0f, 180f, false, p); line(0f, 0.55f, 0f, 0.85f); line(-0.28f, 0.85f, 0.28f, 0.85f) }
            Icon.EMOJI -> { c.drawCircle(0f, 0f, 0.82f * s, p); dot(-0.3f, -0.22f, 0.07f); dot(0.3f, -0.22f, 0.07f); r.set(-0.46f * s, -0.4f * s, 0.46f * s, 0.46f * s); c.drawArc(r, 25f, 130f, false, p) }
            Icon.THEME -> { c.drawCircle(0f, 0f, 0.82f * s, p); dot(-0.3f, -0.25f, 0.1f); dot(0.15f, -0.4f, 0.1f); dot(0.42f, 0.0f, 0.1f); dot(-0.4f, 0.2f, 0.1f) }
            Icon.GLOBE -> { c.drawCircle(0f, 0f, 0.82f * s, p); r.set(-0.38f * s, -0.82f * s, 0.38f * s, 0.82f * s); c.drawOval(r, p); line(-0.82f, 0f, 0.82f, 0f) }
            Icon.SETTINGS -> { c.drawCircle(0f, 0f, 0.28f * s, p); c.drawCircle(0f, 0f, 0.58f * s, p)
                for (i in 0 until 8) { c.save(); c.rotate(i * 45f); c.drawLine(0f, -0.58f * s, 0f, -0.85f * s, p); c.restore() } }
            Icon.KEYBOARD -> { rr(-0.88f, -0.55f, 0.88f, 0.55f, 0.18f)
                for (i in 0 until 4) { dot(-0.55f + i * 0.37f, -0.22f, 0.06f); dot(-0.55f + i * 0.37f, 0.02f, 0.06f) }; line(-0.4f, 0.32f, 0.4f, 0.32f) }
            Icon.SHIFT -> { if (filled) p.style = Paint.Style.FILL_AND_STROKE; poly(0f, -0.72f, 0.66f, 0f, 0.3f, 0f, 0.3f, 0.68f, -0.3f, 0.68f, -0.3f, 0f, -0.66f, 0f, close = true) }
            Icon.BACKSPACE -> { poly(-0.88f, 0f, -0.4f, -0.62f, 0.88f, -0.62f, 0.88f, 0.62f, -0.4f, 0.62f, close = true); line(-0.05f, -0.25f, 0.5f, 0.25f); line(0.5f, -0.25f, -0.05f, 0.25f) }
            Icon.ENTER -> { poly(0.7f, -0.55f, 0.7f, 0.12f, -0.65f, 0.12f); poly(-0.3f, -0.25f, -0.65f, 0.12f, -0.3f, 0.5f) }
            Icon.CHECK -> poly(-0.65f, 0.05f, -0.2f, 0.5f, 0.65f, -0.45f)
            Icon.INFO -> { c.drawCircle(0f, 0f, 0.82f * s, p); dot(0f, -0.38f, 0.08f); line(0f, -0.08f, 0f, 0.42f) }
            Icon.CLOSE -> { line(-0.55f, -0.55f, 0.55f, 0.55f); line(0.55f, -0.55f, -0.55f, 0.55f) }
            Icon.BACK -> poly(0.3f, -0.65f, -0.35f, 0f, 0.3f, 0.65f)
            Icon.HOME -> { poly(-0.8f, 0.05f, 0f, -0.75f, 0.8f, 0.05f); poly(-0.55f, -0.15f, -0.55f, 0.75f, 0.55f, 0.75f, 0.55f, -0.15f) }
            Icon.BOLT -> poly(0.15f, -0.85f, -0.5f, 0.1f, -0.05f, 0.1f, -0.15f, 0.85f, 0.5f, -0.1f, 0.05f, -0.1f, close = true)
            Icon.CHART -> { line(-0.75f, 0.72f, 0.75f, 0.72f); line(-0.45f, 0.72f, -0.45f, 0.1f); line(-0.05f, 0.72f, -0.05f, -0.3f); line(0.35f, 0.72f, 0.35f, -0.7f) }
            Icon.PHONE -> { rr(-0.42f, -0.85f, 0.42f, 0.85f, 0.2f); line(-0.14f, 0.6f, 0.14f, 0.6f) }
            Icon.SPEAKER -> { poly(-0.75f, -0.25f, -0.35f, -0.25f, 0.1f, -0.68f, 0.1f, 0.68f, -0.35f, 0.25f, -0.75f, 0.25f, close = true); r.set(-0.2f * s, -0.42f * s, 0.8f * s, 0.42f * s); c.drawArc(r, -55f, 110f, false, p) }
            Icon.SLIDERS -> { line(-0.75f, -0.4f, 0.75f, -0.4f); line(-0.75f, 0.4f, 0.75f, 0.4f); c.drawCircle(0.25f * s, -0.4f * s, 0.2f * s, p); c.drawCircle(-0.25f * s, 0.4f * s, 0.2f * s, p) }
            Icon.TRASH -> { line(-0.7f, -0.45f, 0.7f, -0.45f); poly(-0.5f, -0.45f, -0.38f, 0.8f, 0.38f, 0.8f, 0.5f, -0.45f); line(-0.25f, -0.7f, 0.25f, -0.7f); line(-0.15f, -0.1f, -0.12f, 0.5f); line(0.15f, -0.1f, 0.12f, 0.5f) }
            Icon.PLUS -> { line(0f, -0.65f, 0f, 0.65f); line(-0.65f, 0f, 0.65f, 0f) }
            Icon.CHEVRON -> poly(-0.25f, -0.6f, 0.3f, 0f, -0.25f, 0.6f)
            Icon.SPARKLE -> { poly(0f, -0.85f, 0.18f, -0.18f, 0.85f, 0f, 0.18f, 0.18f, 0f, 0.85f, -0.18f, 0.18f, -0.85f, 0f, -0.18f, -0.18f, close = true) }
            Icon.GRID -> { rr(-0.75f, -0.75f, -0.1f, -0.1f, 0.15f); rr(0.1f, -0.75f, 0.75f, -0.1f, 0.15f); rr(-0.75f, 0.1f, -0.1f, 0.75f, 0.15f); rr(0.1f, 0.1f, 0.75f, 0.75f, 0.15f) }
            Icon.SHIELD -> { poly(0f, -0.85f, 0.7f, -0.55f, 0.65f, 0.2f, 0f, 0.85f, -0.65f, 0.2f, -0.7f, -0.55f, close = true); poly(-0.28f, 0.0f, -0.05f, 0.25f, 0.32f, -0.2f) }
        }
        c.restore()
    }
}

class IconView(context: Context, private val icon: Icon, color: Int) : View(context) {
    var color: Int = color
        set(v) { field = v; invalidate() }
    override fun onDraw(c: Canvas) { IconPainter.draw(c, icon, width / 2f, height / 2f, minOf(width, height) * 0.9f, color) }
}
