package com.evolve.keyboard.suggest

/**
 * Text styles built from Unicode "mathematical" and decorative letters (not real fonts): they work in any app that can display
 * those characters, but they only cover Latin letters/digits, and screen readers may read them oddly.
 */
class FontStyle(val id: String, val name: String, private val map: (Char) -> String) {
    fun apply(text: String): String = buildString { text.forEach { append(map(it)) } }
    fun applyChar(c: Char): String = map(c)
}

object FontStyles {
    private fun cp(v: Int) = String(Character.toChars(v))
    private fun offset(upper: Int, lower: Int, digit: Int?, special: Map<Char, String> = emptyMap()): (Char) -> String = { c ->
        special[c] ?: when {
            c in 'A'..'Z' -> cp(upper + (c - 'A'))
            c in 'a'..'z' -> cp(lower + (c - 'a'))
            c in '0'..'9' && digit != null -> cp(digit + (c - '0'))
            else -> c.toString()
        }
    }
    private const val SMALL_CAPS = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"

    val ALL: List<FontStyle> = listOf(
        FontStyle("normal", "Normal") { it.toString() },
        FontStyle("bold", "Bold", offset(0x1D400, 0x1D41A, 0x1D7CE)),
        FontStyle("italic", "Italic", offset(0x1D434, 0x1D44E, null, mapOf('h' to "\u210E"))),
        FontStyle("bolditalic", "Bold Italic", offset(0x1D468, 0x1D482, null)),
        FontStyle("script", "Script", offset(0x1D4D0, 0x1D4EA, null)),
        FontStyle("gothic", "Gothic", offset(0x1D56C, 0x1D586, null)),
        FontStyle("double", "Double-struck", offset(0x1D538, 0x1D552, 0x1D7D8,
            mapOf('C' to "\u2102", 'H' to "\u210D", 'N' to "\u2115", 'P' to "\u2119", 'Q' to "\u211A", 'R' to "\u211D", 'Z' to "\u2124"))),
        FontStyle("sansbold", "Sans Bold", offset(0x1D5D4, 0x1D5EE, 0x1D7EC)),
        FontStyle("mono", "Monospace", offset(0x1D670, 0x1D68A, 0x1D7F6)),
        FontStyle("circled", "Circled") { c ->
            when {
                c in 'A'..'Z' -> cp(0x24B6 + (c - 'A')); c in 'a'..'z' -> cp(0x24D0 + (c - 'a'))
                c in '1'..'9' -> cp(0x2460 + (c - '1')); c == '0' -> cp(0x24EA); else -> c.toString()
            }
        },
        FontStyle("fullwidth", "Fullwidth", offset(0xFF21, 0xFF41, 0xFF10)),
        FontStyle("smallcaps", "Small Caps") { c -> if (c in 'a'..'z') SMALL_CAPS[c - 'a'].toString() else c.toString() }
    )
    fun byId(id: String?) = ALL.firstOrNull { it.id == id } ?: ALL[0]
}
