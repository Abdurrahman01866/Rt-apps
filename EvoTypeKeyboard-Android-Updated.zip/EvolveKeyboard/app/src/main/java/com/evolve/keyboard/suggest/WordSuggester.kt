package com.evolve.keyboard.suggest

/** A word list in frequency order (most common first). Prefix lookup via binary search on a sorted copy. */
class WordList(words: List<String>) {
    private val sorted: Array<String>
    private val rank: IntArray
    init {
        val idx = words.indices.sortedBy { words[it].lowercase() }
        sorted = Array(idx.size) { words[idx[it]] }
        rank = IntArray(idx.size) { idx[it] }
    }

    fun withPrefix(prefix: String, limit: Int): List<String> {
        val p = prefix.lowercase()
        var lo = 0; var hi = sorted.size
        while (lo < hi) { val m = (lo + hi) ushr 1; if (sorted[m].lowercase() < p) lo = m + 1 else hi = m }
        val found = ArrayList<Int>()
        var i = lo
        while (i < sorted.size && found.size < 300 && sorted[i].lowercase().startsWith(p)) { if (sorted[i].lowercase() != p) found.add(i); i++ }
        return found.sortedBy { rank[it] }.take(limit).map { sorted[it] }
    }
}

/** Combines the built-in dictionary with the words this user types often. */
class WordSuggester(private val english: WordList, private val bangla: WordList, private val user: UserWords) {
    fun suggest(prefix: String, bangla: Boolean, limit: Int = 3): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        val learned = user.match(prefix, 6)
        learned.filter { it.second >= 2 }.take(2).forEach { out.add(it.first) }          // habits first
        (if (bangla) this.bangla else english).withPrefix(prefix, limit + 2).forEach { out.add(fixCase(prefix, it)) }
        learned.filter { it.second < 2 }.forEach { out.add(it.first) }
        val seen = HashSet<String>()
        return out.filter { seen.add(it.lowercase()) }.take(limit)
    }

    private fun fixCase(prefix: String, w: String) =
        if (prefix.length > 1 && prefix.all { it.isUpperCase() }) w.uppercase()
        else if (prefix[0].isUpperCase()) w.replaceFirstChar { it.uppercase() } else w
}
