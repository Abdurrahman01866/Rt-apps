package com.evolve.keyboard.suggest

import com.evolve.keyboard.clipboard.KeyValueStore
import java.net.URLDecoder
import java.net.URLEncoder

/**
 * Words the user types often, kept ONLY on the device. Kept small on purpose:
 * hard cap on entries, one-off words expire after 30 days, and the least-used words are dropped first.
 */
class UserWords(private val store: KeyValueStore, private val clock: () -> Long = System::currentTimeMillis) {
    private class Entry(var display: String, var count: Int, var last: Long)
    private val map = HashMap<String, Entry>()
    private var unsaved = 0

    init { load() }

    fun size() = map.size

    fun learn(word: String) {
        if (!valid(word)) return
        val e = map.getOrPut(word.lowercase()) { Entry(word, 0, 0) }
        e.count++; e.display = word; e.last = clock()
        if (map.size > MAX) prune(TARGET)
        if (++unsaved >= 20) save()
    }

    /** Learned words starting with [prefix], most-used first. */
    fun match(prefix: String, limit: Int): List<Pair<String, Int>> {
        val p = prefix.lowercase()
        return map.entries.filter { it.key.startsWith(p) && it.key != p }
            .sortedWith(compareByDescending<Map.Entry<String, Entry>> { it.value.count }.thenByDescending { it.value.last })
            .take(limit).map { it.value.display to it.value.count }
    }

    fun top(n: Int): List<Pair<String, Int>> =
        map.values.sortedByDescending { it.count }.take(n).map { it.display to it.count }

    fun forget(word: String) { map.remove(word.lowercase()); save() }
    fun clear() { map.clear(); save() }

    fun save() {
        store.put("words", map.entries.joinToString("\n") { "${URLEncoder.encode(it.value.display, "UTF-8")}|${it.value.count}|${it.value.last}" })
        unsaved = 0
    }

    private fun prune(target: Int) {
        val keep = map.entries.sortedByDescending { it.value.count * 100_000L + it.value.last / 86_400_000L }.take(target)
        val keys = keep.map { it.key }.toSet()
        map.keys.retainAll(keys)
    }

    private fun load() {
        val now = clock()
        (store.get("words") ?: "").lines().filter { it.isNotBlank() }.forEach { l ->
            val p = l.split('|'); if (p.size != 3) return@forEach
            runCatching {
                val w = URLDecoder.decode(p[0], "UTF-8"); val c = p[1].toInt(); val t = p[2].toLong()
                if (!(c <= 1 && now - t > EXPIRE_MS)) map[w.lowercase()] = Entry(w, c, t)   // drop stale one-offs
            }
        }
    }

    companion object {
        const val MAX = 1500; const val TARGET = 1200; const val EXPIRE_MS = 30L * 24 * 3600 * 1000
        fun valid(w: String): Boolean {
            if (w.length !in 2..30) return false
            return w.all { c ->
                Character.isLetter(c) || c == '\'' ||
                    Character.getType(c).let { it == Character.NON_SPACING_MARK.toInt() || it == Character.COMBINING_SPACING_MARK.toInt() } || c == '\u09CD'
            }
        }
    }
}
