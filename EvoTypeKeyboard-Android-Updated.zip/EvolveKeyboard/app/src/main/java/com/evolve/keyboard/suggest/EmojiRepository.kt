package com.evolve.keyboard.suggest

data class EmojiItem(val ch: String, val cat: String, val keys: List<String>)

/** Categorised emoji with forgiving search (prefix, contains, and 1–2 letter typos; English and Bangla keywords). */
class EmojiRepository(val items: List<EmojiItem>) {
    private val byCat = items.groupBy { it.cat }
    fun inCategory(cat: String): List<String> = byCat[cat].orEmpty().map { it.ch }

    fun search(query: String, limit: Int = 80): List<String> {
        val tokens = query.lowercase().split(' ', ',').filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return emptyList()
        val scored = ArrayList<Pair<Int, Int>>()
        items.forEachIndexed { i, it ->
            var total = 0
            for (t in tokens) total += tokenScore(t, it.keys)
            if (total > 0) scored.add(total to i)
        }
        return scored.sortedWith(compareByDescending<Pair<Int, Int>> { it.first }.thenBy { it.second }).take(limit).map { items[it.second].ch }
    }

    /** Emoji whose keyword is exactly [word] (for inline suggestions). */
    fun exact(word: String): String? {
        val w = word.lowercase(); if (w.length < 3) return null
        return items.firstOrNull { w in it.keys && it.cat != "flags" && it.cat != "symbols" }?.ch
    }

    private fun tokenScore(t: String, keys: List<String>): Int {
        var best = 0
        for (k in keys) {
            val s = when {
                k == t -> 100
                k.startsWith(t) -> 60
                t.length >= 3 && k.contains(t) -> 35
                t.length >= 4 && Math.abs(k.length - t.length) <= 2 && lev(k, t, 2) <= 1 -> 30
                t.length >= 6 && Math.abs(k.length - t.length) <= 2 && lev(k, t, 2) <= 2 -> 20
                else -> 0
            }
            if (s > best) best = s
            if (best == 100) break
        }
        return best
    }

    /** Levenshtein distance, giving up early once it must exceed [max]. */
    private fun lev(a: String, b: String, max: Int): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i; var rowMin = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
                if (cur[j] < rowMin) rowMin = cur[j]
            }
            if (rowMin > max) return max + 1
            prev = cur
        }
        return prev[b.length]
    }

    companion object {
        const val RECENT = "recent"; const val SUGGEST = "suggest"
        val CATEGORIES = listOf("smileys", "people", "animals", "food", "activities", "celebration", "travel", "objects", "symbols", "flags")
        fun parse(lines: List<String>, hasGlyph: (String) -> Boolean = { true }): EmojiRepository =
            EmojiRepository(lines.mapNotNull { l ->
                val p = l.split('\t'); if (p.size < 2 || p[0].isEmpty() || !hasGlyph(p[0])) null
                else EmojiItem(p[0], p[1], (p.getOrNull(2) ?: "").lowercase().split(' ').filter { it.isNotEmpty() }.distinct())
            })
    }
}
