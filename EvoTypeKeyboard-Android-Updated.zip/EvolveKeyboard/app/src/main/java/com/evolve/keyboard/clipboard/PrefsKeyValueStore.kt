package com.evolve.keyboard.clipboard

import android.content.Context

class PrefsKeyValueStore(context: Context, name: String = "evolve_clipboard") : KeyValueStore {
    private val p = context.applicationContext.getSharedPreferences(name, Context.MODE_PRIVATE)
    override fun get(key: String): String? = p.getString(key, null)
    override fun put(key: String, value: String) { p.edit().putString(key, value).apply() }
}
