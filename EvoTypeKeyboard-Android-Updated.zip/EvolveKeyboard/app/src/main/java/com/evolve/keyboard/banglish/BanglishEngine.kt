package com.evolve.keyboard.banglish

/**
 * Offline transliteration (NOT translation) between Latin-script Banglish and Bangla.
 * Pipeline: dictionary override -> phonetic rules -> spelling variants, deduplicated.
 * Roman spelling of Bangla is not standardised, so a preferred form plus alternatives is returned.
 */
class BanglishEngine(private val dict: BanglishDictionary = BanglishDictionary.builtIn()) {

    // ---------- Banglish -> Bangla ----------

    /** Candidates for one Latin word, best first. */
    fun toBanglaCandidates(word: String): List<String> {
        if (word.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        out.addAll(dict.banglaFor(word))
        out.add(phonetic(word.lowercase(), shAsS = false))
        out.add(phonetic(word.lowercase(), shAsS = true))
        return out.toList()
    }

    /** Converts running text; Latin words are transliterated, everything else is preserved. */
    fun toBanglaText(text: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < text.length) {
            if (isAsciiLetter(text[i])) {
                var j = i
                while (j < text.length && isAsciiLetter(text[j])) j++
                sb.append(toBanglaCandidates(text.substring(i, j)).first())
                i = j
            } else { sb.append(text[i]); i++ }
        }
        return sb.toString()
    }

    private fun isAsciiLetter(c: Char) = c in 'a'..'z' || c in 'A'..'Z'

    private fun phonetic(w: String, shAsS: Boolean): String {
        val sb = StringBuilder()
        var prevConsonant = false
        var i = 0
        while (i < w.length) {
            // "ng": anusvara unless a vowel follows (then it is the velar nasal consonant)
            if (w.startsWith("ng", i)) {
                val next = w.getOrNull(i + 2)
                if (next != null && next in "aeiou") {
                    if (prevConsonant) sb.append(HASANTA)
                    sb.append('ঙ'); prevConsonant = true
                } else { sb.append('ং'); prevConsonant = false }
                i += 2; continue
            }
            val v = matchLongest(w, i, VOWELS)
            if (v != null) {
                sb.append(if (prevConsonant) v.second.second else v.second.first)
                prevConsonant = false; i += v.first.length; continue
            }
            val c = matchLongest(w, i, CONSONANTS)
            if (c != null) {
                if (prevConsonant) sb.append(HASANTA)
                sb.append(if (shAsS && c.first == "sh") "স" else c.second)
                prevConsonant = true; i += c.first.length; continue
            }
            sb.append(w[i]); prevConsonant = false; i++
        }
        return sb.toString()
    }

    private fun <T> matchLongest(w: String, i: Int, table: List<Pair<String, T>>): Pair<String, T>? {
        for ((k, v) in table) if (w.startsWith(k, i)) return k to v
        return null
    }

    // ---------- Bangla -> Banglish ----------

    /** Romanisations for one Bangla word, preferred first (lowercase). */
    fun toBanglishCandidates(word: String): List<String> {
        if (word.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        out.addAll(dict.romanFor(word))
        out.add(romanize(word, shAsS = false))
        out.add(romanize(word, shAsS = true))
        return out.toList()
    }

    /** Converts running text; the first letter of the result is capitalised. */
    fun toBanglishText(text: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < text.length) {
            if (isBanglaLetter(text[i])) {
                var j = i
                while (j < text.length && isBanglaLetter(text[j])) j++
                sb.append(toBanglishCandidates(text.substring(i, j)).first())
                i = j
            } else { sb.append(text[i]); i++ }
        }
        return sb.toString().replaceFirstChar { it.uppercase() }
    }

    private fun isBanglaLetter(c: Char) = c in '\u0980'..'\u09FF' && c != '\u0964'

    private fun isConsonant(c: Char) =
        c in '\u0995'..'\u09B9' || c == '\u09DC' || c == '\u09DD' || c == '\u09DF' || c == '\u09CE'

    private fun romanize(word: String, shAsS: Boolean): String {
        val w = word.replace("\u0995\u09CD\u09B7", "\u0001").replace("\u099C\u09CD\u099E", "\u0002")
        val sb = StringBuilder()
        var i = 0
        while (i < w.length) {
            val c = w[i]
            when {
                c == '\u0001' -> { sb.append("kkh"); i = afterConsonant(w, i, sb) }
                c == '\u0002' -> { sb.append("gg"); i = afterConsonant(w, i, sb) }
                isConsonant(c) -> {
                    sb.append(if (shAsS && (c == 'স' || c == 'শ')) "s" else CONS_ROMAN[c] ?: "")
                    i = afterConsonant(w, i, sb)
                }
                else -> { sb.append(INDEP_ROMAN[c] ?: KAR_ROMAN[c] ?: MISC_ROMAN[c] ?: c.toString()); i++ }
            }
        }
        return sb.toString()
    }

    /** Handles what follows a consonant: kar sign, hasanta, or the implied 'o'. Returns next index. */
    private fun afterConsonant(w: String, i: Int, sb: StringBuilder): Int {
        val n = w.getOrNull(i + 1)
        return when {
            n != null && KAR_ROMAN.containsKey(n) -> { sb.append(KAR_ROMAN[n]); i + 2 }
            n == HASANTA -> i + 2                          // conjunct: no vowel between consonants
            n == null || !isBanglaLetter(n) -> i + 1       // word-final: no implied vowel
            else -> { sb.append('o'); i + 1 }
        }
    }

    companion object {
        const val HASANTA = '\u09CD'

        // Longest-first so greedy matching is correct.
        private val VOWELS: List<Pair<String, Pair<String, String>>> = listOf(
            "oi" to ("ঐ" to "ৈ"), "ou" to ("ঔ" to "ৌ"),
            "aa" to ("আ" to "া"), "ii" to ("ঈ" to "ী"), "ee" to ("ঈ" to "ী"),
            "uu" to ("ঊ" to "ূ"), "oo" to ("ঊ" to "ূ"),
            "a" to ("আ" to "া"), "i" to ("ই" to "ি"), "u" to ("উ" to "ু"),
            "e" to ("এ" to "ে"), "o" to ("ও" to "ো")
        )
        private val CONSONANTS: List<Pair<String, String>> = listOf(
            "chh" to "ছ", "kkh" to "ক্ষ", "jny" to "জ্ঞ",
            "kh" to "খ", "gh" to "ঘ", "ch" to "চ", "jh" to "ঝ", "th" to "থ", "dh" to "ধ",
            "ph" to "ফ", "bh" to "ভ", "sh" to "শ", "rh" to "\u09DD",
            "k" to "ক", "g" to "গ", "c" to "চ", "j" to "জ", "t" to "ত", "d" to "দ", "n" to "ন",
            "p" to "প", "f" to "ফ", "b" to "ব", "m" to "ম", "y" to "য", "r" to "র", "l" to "ল",
            "s" to "স", "h" to "হ", "z" to "জ", "v" to "ভ", "w" to "ব", "q" to "ক", "x" to "ক্স"
        )
        private val CONS_ROMAN: Map<Char, String> = mapOf(
            'ক' to "k", 'খ' to "kh", 'গ' to "g", 'ঘ' to "gh", 'ঙ' to "ng", 'চ' to "ch", 'ছ' to "chh",
            'জ' to "j", 'ঝ' to "jh", 'ঞ' to "n", 'ট' to "t", 'ঠ' to "th", 'ড' to "d", 'ঢ' to "dh",
            'ণ' to "n", 'ত' to "t", 'থ' to "th", 'দ' to "d", 'ধ' to "dh", 'ন' to "n", 'প' to "p",
            'ফ' to "f", 'ব' to "b", 'ভ' to "bh", 'ম' to "m", 'য' to "j", 'র' to "r", 'ল' to "l",
            'শ' to "sh", 'ষ' to "sh", 'স' to "s", 'হ' to "h", '\u09DC' to "r", '\u09DD' to "rh",
            '\u09DF' to "y", '\u09CE' to "t"
        )
        private val INDEP_ROMAN: Map<Char, String> = mapOf(
            'অ' to "o", 'আ' to "a", 'ই' to "i", 'ঈ' to "i", 'উ' to "u", 'ঊ' to "u", 'ঋ' to "ri",
            'এ' to "e", 'ঐ' to "oi", 'ও' to "o", 'ঔ' to "ou"
        )
        private val KAR_ROMAN: Map<Char, String> = mapOf(
            'া' to "a", 'ি' to "i", 'ী' to "i", 'ু' to "u", 'ূ' to "u", 'ৃ' to "ri",
            'ে' to "e", 'ৈ' to "oi", 'ো' to "o", 'ৌ' to "ou"
        )
        private val MISC_ROMAN: Map<Char, String> = mapOf(
            'ং' to "ng", 'ঃ' to "h", 'ঁ' to "n", '\u0964' to ".",
            '০' to "0", '১' to "1", '২' to "2", '৩' to "3", '৪' to "4",
            '৫' to "5", '৬' to "6", '৭' to "7", '৮' to "8", '৯' to "9"
        )
    }
}
