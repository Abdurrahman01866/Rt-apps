package com.evolve.keyboard.banglish

/**
 * Avro-style phonetic typing (Roman letters -> Bangla). CASE MATTERS, as in Avro:
 * T/D/N = retroflex ট/ড/ণ, S = শ, Sh = ষ, R = \u09DC, O = ো/ও, I = ী/ঈ, U = ূ/ঊ. "o" is the inherent vowel (types nothing after a consonant).
 * This follows Avro's well-known conventions but is an independent implementation: edge cases can differ from Omicron's Avro.
 */
object AvroEngine {
    const val HASANTA = '\u09CD'

    private val VOWELS: List<Pair<String, Pair<String, String>>> = listOf(
        "rri" to ("ঋ" to "ৃ"), "oi" to ("ঐ" to "ৈ"), "ou" to ("ঔ" to "ৌ"), "OI" to ("ঐ" to "ৈ"), "OU" to ("ঔ" to "ৌ"),
        "a" to ("আ" to "া"), "i" to ("ই" to "ি"), "I" to ("ঈ" to "ী"), "u" to ("উ" to "ু"), "U" to ("ঊ" to "ূ"),
        "e" to ("এ" to "ে"), "O" to ("ও" to "ো")
    )
    // value, isRealConsonant (false for anusvara etc: no hasanta joining)
    private val CONS: List<Pair<String, Pair<String, Boolean>>> = listOf(
        "kkh" to ("ক্ষ" to true), "jNG" to ("জ্ঞ" to true),
        "Ng" to ("ঙ" to true), "NG" to ("ঞ" to true), "kh" to ("খ" to true), "gh" to ("ঘ" to true), "ch" to ("ছ" to true),
        "jh" to ("ঝ" to true), "Th" to ("ঠ" to true), "Dh" to ("ঢ" to true), "th" to ("থ" to true), "dh" to ("ধ" to true),
        "ph" to ("ফ" to true), "bh" to ("ভ" to true), "sh" to ("শ" to true), "Sh" to ("ষ" to true), "Rh" to ("\u09DD" to true),
        "ng" to ("ং" to false),
        "k" to ("ক" to true), "g" to ("গ" to true), "c" to ("চ" to true), "j" to ("জ" to true), "T" to ("ট" to true),
        "D" to ("ড" to true), "N" to ("ণ" to true), "t" to ("ত" to true), "d" to ("দ" to true), "n" to ("ন" to true),
        "p" to ("প" to true), "f" to ("ফ" to true), "b" to ("ব" to true), "v" to ("ভ" to true), "m" to ("ম" to true),
        "z" to ("য" to true), "r" to ("র" to true), "l" to ("ল" to true), "S" to ("শ" to true), "s" to ("স" to true),
        "h" to ("হ" to true), "R" to ("\u09DC" to true), "y" to ("\u09DF" to true), "Y" to ("\u09DF" to true), "q" to ("ক" to true), "x" to ("ক্স" to true)
    )
    private val SIMPLE = mapOf('.' to "।", '$' to "৳", '^' to "ঁ", ':' to "ঃ")
    private const val DIGITS = "০১২৩৪৫৬৭৮৯"

    fun convert(s: String): String {
        val sb = StringBuilder()
        var prevConsonant = false
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (s.startsWith("t``", i)) { sb.append('ৎ'); prevConsonant = false; i += 3; continue }
            if (c == '`') { prevConsonant = false; i++; continue }              // joiner breaker
            if (c == 'o') {
                if (!prevConsonant) sb.append(if (sb.isEmpty()) 'অ' else 'ও')
                prevConsonant = false; i++; continue
            }
            val v = VOWELS.firstOrNull { s.startsWith(it.first, i) }
            if (v != null) {
                sb.append(if (prevConsonant) v.second.second else v.second.first)
                prevConsonant = false; i += v.first.length; continue
            }
            val k = CONS.firstOrNull { s.startsWith(it.first, i) }
            if (k != null) {
                if (k.second.second && prevConsonant) sb.append(HASANTA)
                sb.append(k.second.first); prevConsonant = k.second.second; i += k.first.length; continue
            }
            prevConsonant = false
            when {
                c in '0'..'9' -> sb.append(DIGITS[c - '0'])
                SIMPLE.containsKey(c) -> sb.append(SIMPLE[c])
                else -> sb.append(c)
            }
            i++
        }
        return sb.toString()
    }
}
