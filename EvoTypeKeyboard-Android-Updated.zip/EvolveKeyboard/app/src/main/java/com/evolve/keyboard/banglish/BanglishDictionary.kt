package com.evolve.keyboard.banglish

/**
 * Word-level overrides. Rules handle the general case; the dictionary fixes words where
 * phonetic rules cannot know the standard spelling (e.g. "bhalobashi").
 * Entry order matters: earlier entries for the same key are preferred.
 */
class BanglishDictionary(entries: List<Pair<String, String>>) {
    private val toBangla = LinkedHashMap<String, MutableList<String>>()
    private val toRoman = LinkedHashMap<String, MutableList<String>>()

    init {
        for ((roman, bangla) in entries) {
            val r = roman.lowercase()
            toBangla.getOrPut(r) { mutableListOf() }.let { if (bangla !in it) it.add(bangla) }
            toRoman.getOrPut(bangla) { mutableListOf() }.let { if (r !in it) it.add(r) }
        }
    }

    fun banglaFor(roman: String): List<String> = toBangla[roman.lowercase()] ?: emptyList()
    fun romanFor(bangla: String): List<String> = toRoman[bangla] ?: emptyList()

    companion object {
        /** Lines of "roman<TAB>bangla"; '#' starts a comment. Lets the dictionary grow from a text asset. */
        fun fromLines(lines: List<String>) = BanglishDictionary(
            lines.map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") && '\t' in it }
                .map { it.substringBefore('\t') to it.substringAfter('\t') }
        )

        fun builtIn() = BanglishDictionary(BUILT_IN)

        private val BUILT_IN = listOf(
            "ami" to "আমি", "tumi" to "তুমি", "tomake" to "তোমাকে", "tomar" to "তোমার",
            "amar" to "আমার", "amake" to "আমাকে", "nam" to "নাম", "bhalobashi" to "ভালোবাসি",
            "bhalobasi" to "ভালোবাসি", "bangladesh" to "বাংলাদেশ", "bangla" to "বাংলা",
            "bhalo" to "ভালো", "valo" to "ভালো", "kemon" to "কেমন", "acho" to "আছো", "achho" to "আছো",
            "achi" to "আছি", "dhonnobad" to "ধন্যবাদ", "ke" to "কে", "ki" to "কী", "ki" to "কি",
            "keno" to "কেন", "kothay" to "কোথায়", "ekhane" to "এখানে", "shubho" to "শুভ",
            "bhai" to "ভাই", "bon" to "বোন", "ma" to "মা", "baba" to "বাবা", "dhaka" to "ঢাকা",
            "chattogram" to "চট্টগ্রাম", "bondhu" to "বন্ধু", "kaj" to "কাজ", "ghor" to "ঘর",
            "khabar" to "খাবার", "pani" to "পানি", "ekta" to "একটা", "na" to "না", "hya" to "হ্যাঁ",
            "ji" to "জি", "ar" to "আর", "ebong" to "এবং", "kintu" to "কিন্তু", "tai" to "তাই"
        )
    }
}
