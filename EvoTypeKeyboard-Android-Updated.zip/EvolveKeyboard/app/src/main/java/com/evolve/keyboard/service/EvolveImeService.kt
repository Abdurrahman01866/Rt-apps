package com.evolve.keyboard.service

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Paint
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.FrameLayout
import com.evolve.keyboard.R
import com.evolve.keyboard.banglish.AvroEngine
import com.evolve.keyboard.banglish.BanglishEngine
import com.evolve.keyboard.clipboard.ClipboardRepository
import com.evolve.keyboard.clipboard.PrefsKeyValueStore
import com.evolve.keyboard.keyboard.EmojiPanel
import com.evolve.keyboard.keyboard.Key
import com.evolve.keyboard.keyboard.KeyAction
import com.evolve.keyboard.keyboard.KeyStyle
import com.evolve.keyboard.keyboard.KeyboardTheme
import com.evolve.keyboard.keyboard.KeyboardView
import com.evolve.keyboard.keyboard.VoiceView
import com.evolve.keyboard.layouts.Layouts
import com.evolve.keyboard.settings.MainActivity
import com.evolve.keyboard.settings.Prefs
import com.evolve.keyboard.suggest.EmojiRepository
import com.evolve.keyboard.suggest.ShortcutStore
import com.evolve.keyboard.suggest.UserWords
import com.evolve.keyboard.suggest.WordList
import com.evolve.keyboard.suggest.WordSuggester

class EvolveImeService : InputMethodService(), KeyboardView.Listener {
    /** JATIYA/CLASSIC = Bangla layouts. AVRO = Roman letters -> Bangla (phonetic). BANGLISH = type Bangla, text appears in Roman letters. */
    private enum class Lang(val label: String) { JATIYA("জাতীয়"), AVRO("অভ্র"), CLASSIC("বাংলা"), EN("English"), BANGLISH("Banglish") }
    private enum class Panel { KEYS, SYMBOLS1, SYMBOLS2, BN_ALL, CLIP, EDIT, EMOJI, EMOJI_SEARCH, THEME, VOICE }

    private lateinit var root: FrameLayout
    private lateinit var view: KeyboardView
    private lateinit var emojiPanel: EmojiPanel
    private lateinit var voiceView: VoiceView
    private lateinit var clipRepo: ClipboardRepository
    private lateinit var userWords: UserWords
    private lateinit var shortcuts: ShortcutStore
    private val banglish = BanglishEngine()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var suggester: WordSuggester? = null
    @Volatile private var emojiRepo: EmojiRepository? = null

    private var langs: List<Lang> = listOf(Lang.JATIYA, Lang.AVRO, Lang.EN, Lang.BANGLISH)
    private var lang = Lang.EN
    private var panel = Panel.KEYS
    private var shift = 0
    private var lastShiftTap = 0L
    private var bnPage = 0
    private var selecting = false
    private var clipPinnedTab = false
    private var themePage = 0
    private var searchQuery = ""
    private var sensitiveField = false      // password etc.: no suggestions, no learning, no clipboard capture
    private var learnAllowed = true
    private var doubleSpace = true
    private var suggestOn = true; private var learnOn = true; private var emojiSuggestOn = true
    private var soundOn = false; private var soundVol = 0.5f; private var numberRow = false

    private val latin = StringBuilder()     // AVRO composing buffer (Roman letters)
    private val bnWord = StringBuilder()    // BANGLISH composing buffer (Bangla letters)
    private var capWord = false
    private var candidates: List<String> = emptyList()
    private var lastSpaceAt = 0L
    private val doubleSpaceMs = 400L

    private var recognizer: SpeechRecognizer? = null
    private var voiceListening = false

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        if (sensitiveField || !isInputViewShown) return@OnPrimaryClipChangedListener
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!t.isNullOrBlank()) clipRepo.addRecent(t)
        if (panel == Panel.CLIP) render()
    }

    override fun onCreate() {
        super.onCreate()
        userWords = UserWords(PrefsKeyValueStore(this, "evolve_words"))
        shortcuts = ShortcutStore(PrefsKeyValueStore(this, "evolve_shortcuts"))
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).addPrimaryClipChangedListener(clipListener)
        Thread {                                    // dictionaries load off the main thread
            fun lines(id: Int) = resources.openRawResource(id).bufferedReader().readLines().filter { it.isNotBlank() }
            suggester = WordSuggester(WordList(lines(R.raw.words_en)), WordList(lines(R.raw.words_bn)), userWords)
            val p = Paint()
            emojiRepo = EmojiRepository.parse(lines(R.raw.emoji)) { p.hasGlyph(it) }
        }.start()
    }

    override fun onDestroy() {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(clipListener)
        stopVoice(); userWords.save()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        view = KeyboardView(this).also { it.listener = this; it.onPress = { keySound() } }
        emojiPanel = EmojiPanel(this).apply {
            visibility = View.GONE
            listener = object : EmojiPanel.Listener {
                override fun onEmoji(e: String) { currentInputConnection?.commitText(e, 1); rememberEmoji(e) }
                override fun onBack() { panel = Panel.KEYS; render() }
                override fun onSearch() { panel = Panel.EMOJI_SEARCH; searchQuery = ""; render() }
                override fun onDelete() { currentInputConnection?.let { backspace(it) } }
            }
        }
        voiceView = VoiceView(this).apply {
            visibility = View.GONE
            listener = object : VoiceView.Listener {
                override fun onClose() { stopVoice(); panel = Panel.KEYS; render() }
                override fun onToggle() { if (voiceListening) { recognizer?.stopListening(); voiceView.setState(VoiceView.State.PROCESSING, "Processing…") } else startVoice() }
            }
        }
        root = FrameLayout(this)
        root.addView(view, FrameLayout.LayoutParams(-1, -2))
        root.addView(emojiPanel, FrameLayout.LayoutParams(-1, view.heightFor(Layouts.ROWS)))
        root.addView(voiceView, FrameLayout.LayoutParams(-1, view.heightFor(Layouts.ROWS)))
        loadSettings(); render()
        return root
    }

    private fun loadSettings() {
        clipRepo = ClipboardRepository(PrefsKeyValueStore(this))
        langs = Prefs.langs(this).mapNotNull { n -> Lang.values().firstOrNull { it.name == n } }.ifEmpty { listOf(Lang.EN) }
        val saved = Prefs.lang(this)?.let { n -> Lang.values().firstOrNull { it.name == n } }
        lang = if (saved != null && saved in langs) saved else langs.first()
        doubleSpace = Prefs.doubleSpace(this); suggestOn = Prefs.suggestions(this); learnOn = Prefs.learnWords(this)
        emojiSuggestOn = Prefs.emojiSuggest(this); soundOn = Prefs.sound(this); soundVol = Prefs.soundVolume(this) / 100f; numberRow = Prefs.numberRow(this)
        if (::view.isInitialized) {
            val th = Prefs.theme(this)
            view.theme = th; voiceView.theme = th
            view.heightScale = Prefs.heightPercent(this) / 100f
            view.longPressMs = Prefs.longPressMs(this).toLong()
            view.haptic = Prefs.haptic(this); view.animate = Prefs.animThemes(this); view.oneHanded = Prefs.oneHanded(this)
        }
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        loadSettings()
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        sensitiveField = (cls == InputType.TYPE_CLASS_TEXT && variation in listOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD, InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        learnAllowed = !sensitiveField && info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS == 0 &&
            variation !in listOf(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, InputType.TYPE_TEXT_VARIATION_URI, InputType.TYPE_TEXT_VARIATION_FILTER)
        if (sensitiveField && (lang == Lang.BANGLISH || lang == Lang.AVRO)) lang = if (Lang.EN in langs) Lang.EN else lang
        resetComposing(); panel = Panel.KEYS; selecting = false; bnPage = 0
        shift = if (info.inputType and InputType.TYPE_TEXT_FLAG_CAP_SENTENCES != 0 && lang == Lang.EN) 1 else 0
        if (::view.isInitialized) render()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        currentInputConnection?.finishComposingText()
        resetComposing(); stopVoice(); userWords.save()
        super.onFinishInputView(finishingInput)
    }

    private fun resetComposing() { latin.setLength(0); bnWord.setLength(0); candidates = emptyList() }
    private fun keySound() {
        if (soundOn) (getSystemService(Context.AUDIO_SERVICE) as AudioManager).playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, soundVol)
    }

    // ---------------- rendering ----------------

    private fun neighbour(delta: Int): String {
        val i = langs.indexOf(lang).coerceAtLeast(0)
        return langs[(i + delta + langs.size) % langs.size].label
    }

    private fun banglaSymbols() = lang != Lang.EN

    private fun render() {
        val cur = lang.label; val prev = neighbour(-1); val next = neighbour(1)
        var compact = false
        val body: List<List<Key>> = when (panel) {
            Panel.KEYS -> when (lang) {
                Lang.JATIYA, Lang.BANGLISH -> Layouts.jatiya(shift, cur, prev, next)
                Lang.AVRO -> Layouts.english(shift, cur, prev, next, numberRow = true, avro = true)   // Avro adds a number row: one row taller
                Lang.CLASSIC -> Layouts.classic(bnPage, cur, prev, next)
                Lang.EN -> Layouts.english(shift, cur, prev, next, numberRow = numberRow)
            }
            Panel.SYMBOLS1 -> Layouts.symbols1(cur, prev, next, banglaSymbols())
            Panel.SYMBOLS2 -> Layouts.symbols2(cur, prev, next)
            Panel.BN_ALL -> { compact = true; Layouts.banglaAll() }
            Panel.EDIT -> Layouts.edit(selecting, Build.VERSION.SDK_INT >= 26)
            Panel.CLIP -> clipRows()
            Panel.THEME -> Layouts.themePage(themePage, Prefs.theme(this).id)
            Panel.EMOJI_SEARCH -> Layouts.emojiSearch(searchQuery, emojiRepo?.search(searchQuery, 6).orEmpty(), 0)
            Panel.EMOJI, Panel.VOICE -> emptyList()
        }
        val showTop = panel == Panel.KEYS || panel == Panel.SYMBOLS1 || panel == Panel.SYMBOLS2
        view.visibility = if (panel == Panel.EMOJI || panel == Panel.VOICE) View.GONE else View.VISIBLE
        emojiPanel.visibility = if (panel == Panel.EMOJI) View.VISIBLE else View.GONE
        voiceView.visibility = if (panel == Panel.VOICE) View.VISIBLE else View.GONE
        if (panel == Panel.EMOJI || panel == Panel.VOICE) {
            val h = view.heightFor(if (lang == Lang.AVRO) Layouts.ROWS + 1 else Layouts.ROWS)
            emojiPanel.layoutParams = emojiPanel.layoutParams.also { it.height = h }; voiceView.layoutParams = voiceView.layoutParams.also { it.height = h }
            return
        }
        view.setRows(if (showTop) listOf(topRow()) + body else body, compact)
    }

    private fun topRow(): List<Key> {
        if (candidates.isNotEmpty() && !sensitiveField) {
            return candidates.take(4).mapIndexed { i, c ->
                Key(c, KeyAction.CANDIDATE, c, 1f, style = if (i == 0) KeyStyle.ACCENT else KeyStyle.NORMAL)
            }
        }
        return Layouts.toolbar()
    }

    private fun clipRows(): List<List<Key>> {
        val rows = ArrayList<List<Key>>()
        rows.add(listOf(
            Key("", KeyAction.BACK, "", 0.8f, style = KeyStyle.FUNCTION, description = "Back to keyboard", icon = com.evolve.keyboard.ui.Icon.KEYBOARD),
            Key("Recent (1h)", KeyAction.CLIP_TAB_RECENT, "", 1.6f, style = if (!clipPinnedTab) KeyStyle.ACTIVE else KeyStyle.NORMAL),
            Key("Pinned", KeyAction.CLIP_TAB_PINNED, "", 1.6f, style = if (clipPinnedTab) KeyStyle.ACTIVE else KeyStyle.NORMAL)
        ))
        val items = if (clipPinnedTab) clipRepo.pinned() else clipRepo.recent()
        if (items.isEmpty()) {
            rows.add(listOf(Key(if (clipPinnedTab) "No pinned items yet. Pin from Recent." else "Nothing copied in the last hour.", KeyAction.NONE, "", 1f, style = KeyStyle.LABEL)))
        }
        for (e in items.take(4)) {
            val one = e.text.replace('\n', ' ')
            rows.add(if (clipPinnedTab) listOf(
                Key(one, KeyAction.CLIP_PASTE, e.text, 5f, arg = e.id),
                Key("▲", KeyAction.CLIP_UP, "", 0.7f, style = KeyStyle.FUNCTION, arg = e.id),
                Key("▼", KeyAction.CLIP_DOWN, "", 0.7f, style = KeyStyle.FUNCTION, arg = e.id),
                Key("Unpin", KeyAction.CLIP_PIN, e.text, 1.2f, style = KeyStyle.FUNCTION, arg = e.id)
            ) else listOf(
                Key(one, KeyAction.CLIP_PASTE, e.text, 5f, arg = e.id),
                Key("Pin", KeyAction.CLIP_PIN, e.text, 1f, style = KeyStyle.FUNCTION, arg = e.id),
                Key("✕", KeyAction.CLIP_DELETE, "", 0.8f, style = KeyStyle.FUNCTION, arg = e.id, description = "Delete")
            ))
        }
        return Layouts.pad(rows)
    }

    // ---------------- key handling ----------------

    override fun onKey(key: Key, variant: String?) {
        val ic = currentInputConnection
        if (panel == Panel.EMOJI_SEARCH && handleSearchKey(key, variant)) return
        when (key.action) {
            KeyAction.CHAR -> if (ic != null) typeText(ic, variant ?: key.text)
            KeyAction.SPACE -> if (ic != null) space(ic)
            KeyAction.DEL -> if (ic != null) backspace(ic)
            KeyAction.ENTER -> if (ic != null) enter(ic)
            KeyAction.SHIFT -> {
                val now = System.currentTimeMillis()
                shift = if (shift == 2) 0 else if (now - lastShiftTap < 350) 2 else if (shift == 1) 0 else 1
                lastShiftTap = now; render()
            }
            KeyAction.SYMBOLS1 -> { commitPending(ic); panel = Panel.SYMBOLS1; render() }
            KeyAction.SYMBOLS2 -> { panel = Panel.SYMBOLS2; render() }
            KeyAction.LETTERS, KeyAction.BACK -> { stopVoice(); panel = Panel.KEYS; selecting = false; render() }
            KeyAction.BN_PAGE -> { bnPage = (bnPage + 1) % 3; render() }
            KeyAction.BN_ALL -> { panel = Panel.BN_ALL; render() }
            KeyAction.NEXT_LANG -> cycleLanguage(1)
            KeyAction.CANDIDATE -> if (ic != null) acceptCandidate(ic, key.text)
            KeyAction.TOOL_CLIP -> { panel = Panel.CLIP; render() }
            KeyAction.TOOL_EDIT -> { commitPending(ic); panel = Panel.EDIT; render() }
            KeyAction.TOOL_EMOJI -> { commitPending(ic); openEmoji(ic) }
            KeyAction.TOOL_THEME -> { panel = Panel.THEME; render() }
            KeyAction.TOOL_SETTINGS -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            KeyAction.TOOL_VOICE -> { commitPending(ic); startVoice() }
            KeyAction.EDIT -> if (ic != null) editCommand(ic, key.text)
            KeyAction.THEME_PICK -> {
                val t = KeyboardTheme.ALL[key.arg.toInt()]
                Prefs.setTheme(this, t.id); view.theme = t; voiceView.theme = t; render()
            }
            KeyAction.THEME_PAGE -> {
                val pages = (KeyboardTheme.ALL.size + Layouts.THEMES_PER_PAGE - 1) / Layouts.THEMES_PER_PAGE
                themePage = (themePage + key.arg.toInt() + pages) % pages; render()
            }
            KeyAction.CLIP_TAB_RECENT -> { clipPinnedTab = false; render() }
            KeyAction.CLIP_TAB_PINNED -> { clipPinnedTab = true; render() }
            KeyAction.CLIP_PASTE -> ic?.commitText(key.text, 1)
            KeyAction.CLIP_PIN -> { if (clipPinnedTab) clipRepo.unpin(key.arg) else clipRepo.pin(key.text); render() }
            KeyAction.CLIP_DELETE -> { clipRepo.deleteRecent(key.arg); render() }
            KeyAction.CLIP_UP -> { clipRepo.movePinned(key.arg, -1); render() }
            KeyAction.CLIP_DOWN -> { clipRepo.movePinned(key.arg, 1); render() }
            KeyAction.EMOJI_PICK, KeyAction.EMOJI_BACK, KeyAction.NONE -> {}
        }
    }

    override fun onSpaceSwipe(direction: Int) = cycleLanguage(direction)

    private fun cycleLanguage(dir: Int) {
        commitPending(currentInputConnection)
        val avail = if (sensitiveField) langs.filter { it != Lang.BANGLISH && it != Lang.AVRO }.ifEmpty { langs } else langs
        lang = avail[(avail.indexOf(lang).coerceAtLeast(0) + dir + avail.size) % avail.size]
        Prefs.setLang(this, lang.name)
        panel = Panel.KEYS; resetComposing(); shift = 0; render()
    }

    // ---------------- emoji ----------------

    private val popular = "😂 ❤ 😍 🙏 😊 👍 😭 🔥 🥰 😘 🎉 😁 🤔 😢 💕 ✨ 🥳 😎 💯 🙌 😅 🤣 💪 👏".split(" ")

    private fun openEmoji(ic: InputConnection?) {
        val w = if (ic != null) currentWord(ic) else ""
        val repo = emojiRepo
        val sug = if (repo != null && w.length >= 2) repo.search(w, 40) else popular
        emojiPanel.bind(view.theme, repo, Prefs.recentEmoji(this), sug)
        panel = Panel.EMOJI; render()
    }

    private fun rememberEmoji(e: String) = Prefs.setRecentEmoji(this, (listOf(e) + Prefs.recentEmoji(this).filter { it != e }).take(32))

    private fun handleSearchKey(key: Key, variant: String?): Boolean {
        when (key.action) {
            KeyAction.CHAR -> { searchQuery += (variant ?: key.text).lowercase() }
            KeyAction.SPACE -> searchQuery += " "
            KeyAction.DEL -> searchQuery = searchQuery.dropLast(1)
            KeyAction.EMOJI_PICK -> { currentInputConnection?.commitText(key.text, 1); rememberEmoji(key.text); return true }
            KeyAction.EMOJI_BACK -> { panel = Panel.EMOJI; openEmoji(currentInputConnection); return true }
            KeyAction.SHIFT -> return false
            else -> return false
        }
        render(); return true
    }

    // ---------------- typing ----------------

    private fun isBanglaLetter(c: Char) = c in '\u0980'..'\u09FF' && c != '\u0964' && c !in '\u09E6'..'\u09EF'
    private fun isWordChar(c: Char) = Character.isLetter(c) || c == '\'' || c == '\u09CD' ||
        Character.getType(c).let { it == Character.NON_SPACING_MARK.toInt() || it == Character.COMBINING_SPACING_MARK.toInt() }
    private fun currentWord(ic: InputConnection): String {
        val before = ic.getTextBeforeCursor(32, 0)?.toString().orEmpty()
        var i = before.length
        while (i > 0 && isWordChar(before[i - 1])) i--
        return before.substring(i)
    }
    private fun isSeparator(c: Char) = !isWordChar(c) && !c.isDigit()

    private fun learnWord(w: String) { if (learnOn && learnAllowed && w.isNotEmpty()) userWords.learn(w) }

    private fun typeText(ic: InputConnection, t: String) {
        val single = t.length == 1
        when {
            lang == Lang.AVRO && !sensitiveField && single && (t[0] in 'a'..'z' || t[0] in 'A'..'Z' || t[0] == '`') -> { latin.append(t); recomposeAvro(ic) }
            lang == Lang.AVRO && !sensitiveField && single && t[0].isDigit() -> { commitPending(ic); ic.commitText(AvroEngine.convert(t), 1); updateSuggestions(ic) }
            lang == Lang.BANGLISH && !sensitiveField && t.all { isBanglaLetter(it) } -> {
                if (bnWord.isEmpty()) capWord = atSentenceStart(ic)
                bnWord.append(t); recomposeBanglish(ic)
            }
            else -> {
                commitPending(ic)
                if (single && isSeparator(t[0])) learnWord(currentWord(ic))
                ic.commitText(if (lang == Lang.BANGLISH && !sensitiveField) banglish.toBanglishCandidates(t).firstOrNull() ?: t else t, 1)
                updateSuggestions(ic)
            }
        }
        if (shift == 1) { shift = 0; render() }
    }

    private fun atSentenceStart(ic: InputConnection): Boolean {
        val before = ic.getTextBeforeCursor(3, 0)?.toString().orEmpty()
        return before.isBlank() || ((before.trimEnd().endsWith(".") || before.trimEnd().endsWith("?") || before.trimEnd().endsWith("!")) && before.endsWith(" ")) || before.endsWith("\n")
    }
    private fun fmt(s: String) = if (capWord) s.replaceFirstChar { it.uppercase() } else s

    /** Avro: exact Avro result first, then the forgiving converter and dictionary completions as alternatives. */
    private fun recomposeAvro(ic: InputConnection) {
        if (latin.isEmpty()) { ic.setComposingText("", 1); ic.finishComposingText(); candidates = emptyList(); render(); return }
        val avro = AvroEngine.convert(latin.toString())
        val out = LinkedHashSet<String>(); out.add(avro)
        if (suggestOn) {
            out.addAll(banglish.toBanglaCandidates(latin.toString().lowercase()).take(2))
            suggester?.suggest(avro, true, 2)?.let { out.addAll(it) }
        }
        candidates = out.toList()
        ic.setComposingText(avro, 1); render()
    }

    private fun recomposeBanglish(ic: InputConnection) {
        if (bnWord.isEmpty()) { ic.setComposingText("", 1); ic.finishComposingText(); candidates = emptyList(); render(); return }
        candidates = banglish.toBanglishCandidates(bnWord.toString()).map(::fmt)
        ic.setComposingText(candidates.first(), 1); render()
    }

    private fun commitPending(ic: InputConnection?) {
        if (latin.isNotEmpty()) {
            val t = AvroEngine.convert(latin.toString()); ic?.commitText(t, 1); learnWord(t)
        } else if (bnWord.isNotEmpty()) {
            ic?.commitText(candidates.firstOrNull() ?: fmt(banglish.toBanglishText(bnWord.toString()).lowercase()), 1)
        }
        resetComposing()
    }

    private fun acceptCandidate(ic: InputConnection, text: String) {
        if (latin.isNotEmpty() || bnWord.isNotEmpty()) {
            ic.commitText(text, 1); if (latin.isNotEmpty()) learnWord(text); resetComposing(); render(); return
        }
        if (text.firstOrNull()?.let { Character.isLetter(it) } != true) { ic.commitText(" $text ", 1); rememberEmoji(text) }  // emoji suggestion
        else { val w = currentWord(ic); ic.deleteSurroundingText(w.length, 0); ic.commitText("$text ", 1); learnWord(text) }
        candidates = emptyList(); render()
    }

    /** Word suggestions (dictionary + the words you use most) for the word being typed, plus one emoji when a keyword matches. */
    private fun updateSuggestions(ic: InputConnection?) {
        if (!suggestOn || sensitiveField || ic == null || panel != Panel.KEYS) { if (candidates.isNotEmpty()) { candidates = emptyList(); render() }; return }
        val w = currentWord(ic)
        val s = suggester
        var list: List<String> = if (w.isEmpty() || s == null) emptyList() else s.suggest(w, lang == Lang.JATIYA || lang == Lang.CLASSIC, 3)
        if (emojiSuggestOn && w.length >= 3 && lang == Lang.EN) emojiRepo?.exact(w)?.let { list = list + it }
        if (list != candidates) { candidates = list; render() }
    }

    private fun space(ic: InputConnection) {
        val hadPending = latin.isNotEmpty() || bnWord.isNotEmpty()
        commitPending(ic)
        if (!hadPending && !sensitiveField) {
            val w = currentWord(ic)
            val exp = if (w.isNotEmpty()) shortcuts.expansionFor(w) else null
            if (exp != null) { ic.deleteSurroundingText(w.length, 0); ic.commitText(exp, 1) } else learnWord(w)
        }
        val now = System.currentTimeMillis()
        val before = ic.getTextBeforeCursor(2, 0)?.toString().orEmpty()
        val plainText = (currentInputEditorInfo?.inputType ?: 0) and InputType.TYPE_MASK_CLASS == InputType.TYPE_CLASS_TEXT
        if (!hadPending && doubleSpace && plainText && !sensitiveField && now - lastSpaceAt < doubleSpaceMs &&
            before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
            ic.deleteSurroundingText(1, 0)
            ic.commitText(if (lang == Lang.EN || lang == Lang.BANGLISH) ". " else "\u0964 ", 1); lastSpaceAt = 0
        } else { ic.commitText(" ", 1); lastSpaceAt = now }
        candidates = emptyList(); render()
    }

    private fun backspace(ic: InputConnection) {
        if (latin.isNotEmpty()) { latin.deleteCharAt(latin.length - 1); recomposeAvro(ic); return }
        if (bnWord.isNotEmpty()) { bnWord.deleteCharAt(bnWord.length - 1); recomposeBanglish(ic); return }
        if (ic.getSelectedText(0).isNullOrEmpty()) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL))
        } else ic.commitText("", 1)
        updateSuggestions(ic)
    }

    private fun enter(ic: InputConnection) {
        val hadPending = latin.isNotEmpty() || bnWord.isNotEmpty()
        commitPending(ic)
        if (!hadPending) learnWord(currentWord(ic))
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = (info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) ic.performEditorAction(action)
        else { ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)); ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER)) }
        candidates = emptyList(); render()
    }

    private fun dpad(ic: InputConnection, code: Int) {
        val meta = if (selecting) KeyEvent.META_SHIFT_ON else 0
        val t = System.currentTimeMillis()
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta))
    }

    private fun editCommand(ic: InputConnection, cmd: String) {
        when (cmd) {
            "select" -> { selecting = !selecting; render() }
            "selectAll" -> ic.performContextMenuAction(android.R.id.selectAll)
            "copy" -> ic.performContextMenuAction(android.R.id.copy)
            "cut" -> ic.performContextMenuAction(android.R.id.cut)
            "paste" -> ic.performContextMenuAction(android.R.id.paste)
            "undo" -> if (Build.VERSION.SDK_INT >= 26) ic.performContextMenuAction(android.R.id.undo)
            "redo" -> if (Build.VERSION.SDK_INT >= 26) ic.performContextMenuAction(android.R.id.redo)
            "left" -> dpad(ic, KeyEvent.KEYCODE_DPAD_LEFT)
            "right" -> dpad(ic, KeyEvent.KEYCODE_DPAD_RIGHT)
            "up" -> dpad(ic, KeyEvent.KEYCODE_DPAD_UP)
            "down" -> dpad(ic, KeyEvent.KEYCODE_DPAD_DOWN)
            "delete" -> { ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_FORWARD_DEL)); ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_FORWARD_DEL)) }
            "backspace" -> backspace(ic)
        }
    }

    // ---------------- voice typing (Android SpeechRecognizer; the recognition provider may need internet) ----------------

    private fun startVoice() {
        stopVoice()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("mic", true)); return
        }
        panel = Panel.VOICE; render()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            voiceView.setState(VoiceView.State.ERROR, "Speech recognition isn't available on this device"); return
        }
        voiceListening = true; voiceView.setState(VoiceView.State.LISTENING, "Listening… speak now")
        val tag = if (lang == Lang.EN) "en-US" else "bn-BD"
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { voiceView.setLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }    // louder voice = bigger animation
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { voiceListening = false; voiceView.setState(VoiceView.State.PROCESSING, "Processing…") }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(code: Int) {
                    voiceListening = false
                    voiceView.setState(VoiceView.State.ERROR, when (code) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Didn't catch that — tap to try again"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "This speech service needs an internet connection"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is off"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service is busy, try again"
                        else -> "Voice typing failed (code $code)"
                    })
                }
                override fun onResults(res: Bundle?) {
                    voiceListening = false
                    val text = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!text.isNullOrBlank()) {
                        currentInputConnection?.commitText(if (lang == Lang.BANGLISH) banglish.toBanglishText(text) else text, 1)
                        panel = Panel.KEYS; render()
                    } else voiceView.setState(VoiceView.State.ERROR, "Didn't catch that — tap to try again")
                }
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag))
        }
    }

    private fun stopVoice() { recognizer?.destroy(); recognizer = null; voiceListening = false }
}
