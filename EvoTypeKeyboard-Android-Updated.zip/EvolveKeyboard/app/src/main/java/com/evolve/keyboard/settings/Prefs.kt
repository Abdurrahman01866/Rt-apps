package com.evolve.keyboard.settings

import android.content.Context
import com.evolve.keyboard.keyboard.KeyboardTheme

/** All user settings live here (SharedPreferences). The keyboard service re-reads them every time it opens. */
object Prefs {
    val ALL_LANGS = listOf("JATIYA", "AVRO", "CLASSIC", "EN", "BANGLISH")
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("evolve_prefs", Context.MODE_PRIVATE)
    private fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    private fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    private fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    private fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()

    fun theme(c: Context) = KeyboardTheme.byId(sp(c).getString("theme", "evolve"))
    fun setTheme(c: Context, id: String) = sp(c).edit().putString("theme", id).apply()

    /** Enabled languages/layouts in switching order. */
    fun langs(c: Context): List<String> =
        (sp(c).getString("langs2", "JATIYA,AVRO,EN,BANGLISH") ?: "").split(",").filter { it in ALL_LANGS }.ifEmpty { listOf("EN") }
    fun setLangs(c: Context, l: List<String>) = sp(c).edit().putString("langs2", l.joinToString(",")).apply()
    fun allLangsOrdered(c: Context): List<String> { val on = langs(c); return on + ALL_LANGS.filter { it !in on } }
    fun lang(c: Context) = sp(c).getString("lang2", null)
    fun setLang(c: Context, l: String) = sp(c).edit().putString("lang2", l).apply()

    fun haptic(c: Context) = bool(c, "haptic", true);              fun setHaptic(c: Context, v: Boolean) = setBool(c, "haptic", v)
    fun sound(c: Context) = bool(c, "sound", false);               fun setSound(c: Context, v: Boolean) = setBool(c, "sound", v)
    fun soundVolume(c: Context) = int(c, "sound_vol", 50);         fun setSoundVolume(c: Context, v: Int) = setInt(c, "sound_vol", v)
    fun doubleSpace(c: Context) = bool(c, "double_space", true);   fun setDoubleSpace(c: Context, v: Boolean) = setBool(c, "double_space", v)
    fun suggestions(c: Context) = bool(c, "suggestions", true);    fun setSuggestions(c: Context, v: Boolean) = setBool(c, "suggestions", v)
    fun learnWords(c: Context) = bool(c, "learn", true);           fun setLearnWords(c: Context, v: Boolean) = setBool(c, "learn", v)
    fun emojiSuggest(c: Context) = bool(c, "emoji_suggest", true); fun setEmojiSuggest(c: Context, v: Boolean) = setBool(c, "emoji_suggest", v)
    fun numberRow(c: Context) = bool(c, "number_row", false);      fun setNumberRow(c: Context, v: Boolean) = setBool(c, "number_row", v)
    fun animThemes(c: Context) = bool(c, "anim", true);            fun setAnimThemes(c: Context, v: Boolean) = setBool(c, "anim", v)
    fun heightPercent(c: Context) = int(c, "height", 100);         fun setHeightPercent(c: Context, v: Int) = setInt(c, "height", v)
    fun longPressMs(c: Context) = int(c, "long_press", 500);       fun setLongPressMs(c: Context, v: Int) = setInt(c, "long_press", v)
    /** 0 = off, 1 = left, 2 = right. */
    fun oneHanded(c: Context) = int(c, "one_handed", 0);           fun setOneHanded(c: Context, v: Int) = setInt(c, "one_handed", v)
    fun onboarded(c: Context) = bool(c, "onboarded", false);       fun setOnboarded(c: Context, v: Boolean) = setBool(c, "onboarded", v)

    fun recentEmoji(c: Context): List<String> = (sp(c).getString("emoji_recent", "") ?: "").split(" ").filter { it.isNotBlank() }
    fun setRecentEmoji(c: Context, l: List<String>) = sp(c).edit().putString("emoji_recent", l.joinToString(" ")).apply()
}
