package com.evolve.keyboard.settings

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.evolve.keyboard.keyboard.KeyboardTheme
import com.evolve.keyboard.ui.Icon
import com.evolve.keyboard.ui.IconView
import kotlin.math.sin

/** Design system for the settings app: colours, radii, type scale and reusable components. */
object Ui {
    var BG = Color.parseColor("#F5F7FF")
    var NAVY = Color.parseColor("#0B1030")
    var SUB = Color.parseColor("#5B6490")
    var LINE = Color.parseColor("#E4E8F7")
    var CARD = Color.WHITE
    var FIELD = Color.parseColor("#EEF1FB")
    var light = true
    /** 0 = light, 1 = dark, 2 = blue. Every screen reads these colours when it is built. */
    fun applyMode(mode: Int) {
        when (mode) {
            1 -> { BG = Color.parseColor("#0D1020"); CARD = Color.parseColor("#171B33"); NAVY = Color.parseColor("#F1F3FF"); SUB = Color.parseColor("#9AA3C7"); LINE = Color.parseColor("#2A2F4F"); FIELD = Color.parseColor("#20254A"); light = false }
            2 -> { BG = Color.parseColor("#0A1F5C"); CARD = Color.parseColor("#12327F"); NAVY = Color.WHITE; SUB = Color.parseColor("#B9C7F2"); LINE = Color.parseColor("#2A4AA0"); FIELD = Color.parseColor("#0E2A6E"); light = false }
            else -> { BG = Color.parseColor("#F5F7FF"); CARD = Color.WHITE; NAVY = Color.parseColor("#0B1030"); SUB = Color.parseColor("#5B6490"); LINE = Color.parseColor("#E4E8F7"); FIELD = Color.parseColor("#EEF1FB"); light = true }
        }
    }
    val BLUE = Color.parseColor("#1F6BFF")
    val VIOLET = Color.parseColor("#7B2FF7")
    val GREEN = Color.parseColor("#14B87A")
    val ORANGE = Color.parseColor("#F59E0B")
    val BRAND = intArrayOf(Color.parseColor("#00A4FD"), Color.parseColor("#1230F0"), Color.parseColor("#8A1BF5"))
    /** Colour pairs for feature badges so every feature has its own identity. */
    val PALETTE = listOf(
        intArrayOf(Color.parseColor("#00B8F0"), Color.parseColor("#1F6BFF")), intArrayOf(Color.parseColor("#FF5FA2"), Color.parseColor("#FF9A3D")),
        intArrayOf(Color.parseColor("#B26CFF"), Color.parseColor("#5B3DF5")), intArrayOf(Color.parseColor("#FFC83D"), Color.parseColor("#FF8A1F")),
        intArrayOf(Color.parseColor("#2DD4BF"), Color.parseColor("#0EA5A4")), intArrayOf(Color.parseColor("#4ADE80"), Color.parseColor("#14B87A")),
        intArrayOf(Color.parseColor("#F472B6"), Color.parseColor("#9333EA")), intArrayOf(Color.parseColor("#60A5FA"), Color.parseColor("#4F46E5"))
    )
    const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density + 0.5f).toInt()
    fun lp(c: Context, w: Int = MATCH, h: Int = WRAP, t: Int = 0, b: Int = 0, l: Int = 0, r: Int = 0, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b)) }

    fun rounded(c: Context, color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(c, radius).toFloat() }
    fun gradient(c: Context, radius: Int, colors: IntArray = BRAND) =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(c, radius).toFloat() }

    fun text(c: Context, s: String, sp: Float = 15f, color: Int = NAVY, bold: Boolean = false) = TextView(c).apply {
        text = com.evolve.keyboard.i18n.Tr.t(s); setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.15f)
    }

    /** Scale-down feedback on touch; does not consume the event so clicks still fire. */
    fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    fun ripple(c: Context, color: Int, radius: Int): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(30, 31, 107, 255)), rounded(c, color, radius), rounded(c, Color.WHITE, radius))

    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; background = rounded(c, CARD, 20)
        setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16)); elevation = dp(c, 2).toFloat()
    }

    fun tapCard(c: Context, onClick: () -> Unit) = card(c).apply {
        background = ripple(c, CARD, 20); isClickable = true; setOnClickListener { onClick() }; pressable(this)
    }

    fun primaryButton(c: Context, label: String, enabled: Boolean = true, onClick: () -> Unit) = TextView(c).apply {
        text = com.evolve.keyboard.i18n.Tr.t(label); setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f); setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER; minHeight = dp(c, 54)
        background = if (enabled) gradient(c, 27, intArrayOf(BLUE, VIOLET)) else rounded(c, Color.parseColor("#B8C0E0"), 27)
        isEnabled = enabled; setOnClickListener { onClick() }; pressable(this); elevation = if (enabled) dp(c, 3).toFloat() else 0f
    }

    fun textButton(c: Context, label: String, onClick: () -> Unit) = TextView(c).apply {
        text = com.evolve.keyboard.i18n.Tr.t(label); setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); setTextColor(SUB); gravity = Gravity.CENTER
        minHeight = dp(c, 48); setOnClickListener { onClick() }
    }

    fun chip(c: Context, label: String, color: Int) = TextView(c).apply {
        text = com.evolve.keyboard.i18n.Tr.t(label); setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f); setTextColor(color); setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 6))
        background = rounded(c, Color.argb(30, Color.red(color), Color.green(color), Color.blue(color)), 16)
    }

    fun badge(c: Context, icon: Icon, sizeDp: Int, colors: IntArray = BRAND): FrameLayout = FrameLayout(c).apply {
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(c, sizeDp * 32 / 100).toFloat() }
        addView(IconView(c, icon, Color.WHITE), FrameLayout.LayoutParams(dp(c, sizeDp * 54 / 100), dp(c, sizeDp * 54 / 100)).apply { gravity = Gravity.CENTER })
        minimumWidth = dp(c, sizeDp); minimumHeight = dp(c, sizeDp)
    }

    fun section(c: Context, title: String) = text(c, title.uppercase(), 12f, SUB, true).apply { letterSpacing = 0.08f; setPadding(dp(c, 4), 0, 0, 0) }
}

/** Mini keyboard in a theme's real colours (with its gradient), so the preview matches the keyboard. */
class ThemePreview(context: Context, private val t: KeyboardTheme, var selected: Boolean = false) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density; val w = width.toFloat(); val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, w, h, t.background, t.bg2, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(0f, 0f, w, h), 14 * d, 14 * d, p); p.shader = null
        val rows = 3; val cols = 7; val gap = 4 * d
        val kw = (w - gap * (cols + 1)) / cols; val kh = (h - gap * (rows + 2)) / (rows + 1)
        val keyCol = if (Color.alpha(t.key) < 255) (t.key and 0x00FFFFFF) or 0x66000000 else t.key
        for (r in 0 until rows) for (i in 0 until cols) {
            p.color = keyCol; val x = gap + i * (kw + gap); val y = gap + r * (kh + gap)
            c.drawRoundRect(RectF(x, y, x + kw, y + kh), 4 * d, 4 * d, p)
        }
        val y = gap + rows * (kh + gap)
        p.color = keyCol; c.drawRoundRect(RectF(gap * 2 + kw * 1.6f, y, w - gap * 2 - kw * 1.6f, y + kh), 4 * d, 4 * d, p)
        p.color = t.accent; c.drawRoundRect(RectF(w - gap - kw * 1.6f, y, w - gap, y + kh), 4 * d, 4 * d, p)
        if (t.fx != com.evolve.keyboard.keyboard.Fx.NONE) {                 // "animated" sparkle badge
            p.color = 0x99000000.toInt(); c.drawRoundRect(RectF(w - 58 * d, 6 * d, w - 6 * d, 24 * d), 9 * d, 9 * d, p)
            p.color = Color.WHITE; p.textSize = 10 * d; p.textAlign = Paint.Align.CENTER; c.drawText("ANIMATED", w - 32 * d, 18.5f * d, p); p.textAlign = Paint.Align.LEFT
        }
    }
}

/** Animated header: gradient card with floating conversion chips. */
class HeroView(context: Context, private val title: String, private val sub: String) : View(context) {
    var status = "● Active"
    var onStatus: (() -> Unit)? = null
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val chips = listOf(Triple("Hello", 0.06f, 0.58f), Triple("नमस्ते", 0.46f, 0.50f), Triple("مرحبا", 0.08f, 0.82f), Triple("你好", 0.36f, 0.82f), Triple("Hola", 0.58f, 0.80f), Triple("😍", 0.84f, 0.58f))
    private val rect = RectF(); private val pill = RectF()
    private val loop = object : Runnable { override fun run() { invalidate(); if (isShown) postDelayed(this, 33) } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(loop) }
    override fun onDetachedFromWindow() { removeCallbacks(loop); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val t = System.currentTimeMillis() / 1000f
        p.shader = LinearGradient(0f, 0f, w, h, Ui.BRAND, null, Shader.TileMode.CLAMP)
        rect.set(0f, 0f, w, h); c.drawRoundRect(rect, 28 * d, 28 * d, p); p.shader = null
        p.color = 0x22FFFFFF; c.drawCircle(w * 0.9f, h * 0.1f + sin(t * 0.6f) * 6 * d, 70 * d, p); c.drawCircle(w * 0.15f, h * 1.05f, 90 * d, p)
        p.color = Color.WHITE; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = 24 * d; c.drawText(title, 20 * d, 46 * d, p)
        p.typeface = Typeface.DEFAULT; p.textSize = 13.5f * d; p.color = 0xD9FFFFFF.toInt(); c.drawText(sub, 20 * d, 68 * d, p)
        p.textSize = 12.5f * d; val sw = p.measureText(status) + 24 * d
        pill.set(w - sw - 14 * d, 14 * d, w - 14 * d, 40 * d); p.color = 0x33FFFFFF; c.drawRoundRect(pill, 13 * d, 13 * d, p)
        p.color = Color.WHITE; c.drawText(status, pill.left + 12 * d, pill.centerY() + 4.5f * d, p)
        chips.forEachIndexed { i, (label, fx, fy) ->
            p.textSize = 15 * d; val cw = p.measureText(label) + 26 * d
            val x = fx * w; val y = fy * h + sin(t * 1.1f + i * 1.7f) * 5 * d
            p.color = 0x30FFFFFF; c.drawRoundRect(x, y - 18 * d, x + cw, y + 14 * d, 16 * d, 16 * d, p)
            p.color = Color.WHITE; c.drawText(label, x + 13 * d, y + 5 * d, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP && pill.contains(e.x, e.y)) onStatus?.invoke()
        return e.actionMasked != MotionEvent.ACTION_MOVE || pill.contains(e.x, e.y)
    }
}
