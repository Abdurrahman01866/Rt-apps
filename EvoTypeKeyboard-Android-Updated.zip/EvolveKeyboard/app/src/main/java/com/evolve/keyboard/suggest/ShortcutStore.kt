package com.evolve.keyboard.suggest

import com.evolve.keyboard.clipboard.KeyValueStore
import java.net.URLDecoder
import java.net.URLEncoder

/** Text shortcuts: type a short trigger (e.g. "addr") and press space to expand it. */
class ShortcutStore(private val store: KeyValueStore) {
    private val map = LinkedHashMap<String, String>()
    init {
        (store.get("shortcuts") ?: "").lines().filter { it.isNotBlank() }.forEach { l ->
            val p = l.split('|'); if (p.size == 2) runCatching { map[URLDecoder.decode(p[0], "UTF-8")] = URLDecoder.decode(p[1], "UTF-8") }
        }
    }
    fun all(): List<Pair<String, String>> = map.entries.map { it.key to it.value }
    fun expansionFor(trigger: String): String? = map[trigger]
    fun put(trigger: String, text: String) { if (trigger.isNotBlank() && text.isNotBlank() && map.size < 100) { map[trigger.trim()] = text; save() } }
    fun remove(trigger: String) { map.remove(trigger); save() }
    private fun save() = store.put("shortcuts", map.entries.joinToString("\n") { "${URLEncoder.encode(it.key, "UTF-8")}|${URLEncoder.encode(it.value, "UTF-8")}" })
}
