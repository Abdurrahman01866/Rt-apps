package com.evolve.keyboard.keyboard

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.evolve.keyboard.ui.IconPainter
import kotlin.math.abs
import kotlin.math.min

/** Canvas-drawn keyboard: a single View (no per-key child views) so it opens fast and redraws cheaply. */
class KeyboardView(context: Context) : View(context) {
    interface Listener {
        fun onKey(key: Key, variant: String?)
        fun onSpaceSwipe(direction: Int)   // +1 = next language (to the right in the list), -1 = previous
    }

    var listener: Listener? = null
    var theme: KeyboardTheme = KeyboardTheme.ALL[0]
        set(v) { field = v; fx = ThemeFx(v, resources.displayMetrics.density); restartAnim(); invalidate() }
    var animate = true
        set(v) { field = v; restartAnim(); invalidate() }
    var oneHanded = 0                       // 0 = off, 1 = left, 2 = right
        set(v) { field = v; layoutCells(); invalidate() }
    var onPress: (() -> Unit)? = null
    private var fx = ThemeFx(theme, resources.displayMetrics.density)
    private val frame = object : Runnable {
        override fun run() { if (isShown && animate && fx.animated) { invalidate(); uiHandler.postDelayed(this, 33) } }
    }
    private fun restartAnim() { uiHandler.removeCallbacks(frame); if (isAttachedToWindow && animate && fx.animated) uiHandler.post(frame) }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); restartAnim() }
    override fun onWindowVisibilityChanged(v: Int) { super.onWindowVisibilityChanged(v); if (v == VISIBLE) restartAnim() else uiHandler.removeCallbacks(frame) }
    var longPressMs = 500L
    var heightScale = 1f
    var haptic = true

    private class Cell(val key: Key, val rect: RectF)
    private var rows: List<List<Key>> = emptyList()
    private var compact = false
    private val cells = ArrayList<Cell>()
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val tri = Path()
    private val uiHandler = Handler(Looper.getMainLooper())

    private var pressed: Cell? = null
    private var downX = 0f
    private var popupVariants: List<String> = emptyList()
    private var popupRect = RectF()
    private var popupSel = -1
    private var repeating = false
    private var longFired = false
    private var spaceOff = 0f
    private var spaceDragging = false
    private var spaceAnim: ValueAnimator? = null

    fun setRows(r: List<List<Key>>, compactRows: Boolean = false) {
        val changedSize = r.size != rows.size || compactRows != compact
        rows = r; compact = compactRows; layoutCells()
        if (changedSize) requestLayout()
        invalidate()
    }

    fun heightFor(rowCount: Int): Int = (rowHeight() * rowCount + 8 * d).toInt()

    private fun rowHeight(): Float {
        val screenH = resources.displayMetrics.heightPixels
        return min(54f * d, screenH * 0.078f) * heightScale * (if (compact) 0.72f else 1f)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (rowHeight() * rows.size + 8 * d).toInt())
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { layoutCells() }

    private fun layoutCells() {
        cells.clear()
        if (width == 0 || rows.isEmpty()) return
        val gap = 5f * d; val rh = rowHeight()
        val usable = if (oneHanded == 0) width.toFloat() else width * 0.8f
        val x0 = if (oneHanded == 2) width - usable else 0f
        rows.forEachIndexed { ri, row ->
            val total = row.sumOf { it.weight.toDouble() }.toFloat()
            val avail = usable - gap * (row.size + 1)
            var x = x0 + gap
            for (k in row) {
                val kw = avail * k.weight / total
                cells.add(Cell(k, RectF(x, 4 * d + ri * rh + gap / 2, x + kw, 4 * d + (ri + 1) * rh - gap / 2)))
                x += kw + gap
            }
        }
    }

    private fun baseline(cy: Float) = cy - (paint.ascent() + paint.descent()) / 2

    override fun onDraw(c: Canvas) {
        fx.draw(c, width, height, android.os.SystemClock.uptimeMillis(), animate)
        val rad = 9f * d
        for (cell in cells) {
            val k = cell.key; val rc = cell.rect
            if (k.style == KeyStyle.SPACER) continue
            val isPressed = cell === pressed
            val accentLike = k.style == KeyStyle.ACTIVE || k.style == KeyStyle.ACCENT
            if (k.style == KeyStyle.TOOL) {
                if (isPressed) { paint.color = theme.function; c.drawRoundRect(rc, rad, rad, paint) }
            } else if (k.style != KeyStyle.LABEL) {
                paint.color = 0x33000000                      // soft bottom edge gives the key depth
                c.drawRoundRect(rc.left, rc.top + 1.6f * d, rc.right, rc.bottom + 1.6f * d, rad, rad, paint)
                paint.color = when {
                    isPressed -> theme.accent
                    accentLike -> theme.accent
                    k.style == KeyStyle.FUNCTION -> theme.function
                    else -> theme.key
                }
                c.drawRoundRect(rc, rad, rad, paint)
            }
            val fg = when {
                isPressed || accentLike -> theme.accentText
                k.style == KeyStyle.LABEL || k.style == KeyStyle.TOOL -> theme.label
                else -> theme.keyText
            }
            if (k.action == KeyAction.SPACE) { drawSpace(c, k, rc); continue }
            if (k.icon != null) {
                IconPainter.draw(c, k.icon, rc.centerX(), rc.centerY(), 24 * d, if (k.style == KeyStyle.TOOL && !isPressed) theme.keyText else fg,
                    filled = k.style == KeyStyle.ACTIVE)
                continue
            }
            if (k.swatch != 0) { paint.color = k.swatch; c.drawCircle(rc.left + 16 * d, rc.centerY(), 7 * d, paint) }
            val single = k.label.codePointCount(0, k.label.length) == 1
            paint.color = fg
            paint.textSize = (if (single) 24f else 15f) * d
            while (paint.measureText(k.label) > rc.width() - 8 * d && paint.textSize > 9 * d) paint.textSize -= d
            c.drawText(k.label, rc.centerX(), baseline(rc.centerY()), paint)
            val hint = k.variants.firstOrNull()
            if (hint != null && k.style == KeyStyle.NORMAL && single) {      // top-right hint = first long-press alternative
                paint.color = theme.label; paint.textSize = 11f * d
                c.drawText(hint, rc.right - 9 * d, rc.top + 13 * d, paint)
            }
        }
        if (popupVariants.isNotEmpty()) drawPopup(c, rad)
    }

    private fun drawSpace(c: Canvas, k: Key, rc: RectF) {
        val w = rc.width()
        c.save(); c.clipRect(rc)
        paint.color = theme.label; paint.textSize = 17f * d
        val cy = baseline(rc.centerY())
        c.drawText(k.label, rc.centerX() + spaceOff, cy, paint)
        if (spaceOff != 0f) {                              // neighbouring languages slide in during the swipe
            c.drawText(k.prev, rc.centerX() + spaceOff - w, cy, paint)
            c.drawText(k.next, rc.centerX() + spaceOff + w, cy, paint)
        }
        c.restore()
        paint.color = theme.label; paint.alpha = 170
        val t = 6f * d
        tri.reset(); tri.moveTo(rc.left + 20 * d + t, rc.centerY() - t); tri.lineTo(rc.left + 20 * d, rc.centerY()); tri.lineTo(rc.left + 20 * d + t, rc.centerY() + t); tri.close(); c.drawPath(tri, paint)
        tri.reset(); tri.moveTo(rc.right - 20 * d - t, rc.centerY() - t); tri.lineTo(rc.right - 20 * d, rc.centerY()); tri.lineTo(rc.right - 20 * d - t, rc.centerY() + t); tri.close(); c.drawPath(tri, paint)
        paint.alpha = 255
    }

    private fun drawPopup(c: Canvas, rad: Float) {
        paint.color = 0x44000000; c.drawRoundRect(popupRect.left, popupRect.top + 2 * d, popupRect.right, popupRect.bottom + 2 * d, rad, rad, paint)
        paint.color = theme.popup; c.drawRoundRect(popupRect, rad, rad, paint)
        val cw = popupRect.width() / popupVariants.size
        popupVariants.forEachIndexed { i, s ->
            if (i == popupSel) { paint.color = theme.accent
                c.drawRoundRect(popupRect.left + i * cw + 3 * d, popupRect.top + 3 * d, popupRect.left + (i + 1) * cw - 3 * d, popupRect.bottom - 3 * d, rad, rad, paint) }
            paint.color = if (i == popupSel) theme.accentText else theme.keyText
            paint.textSize = 24f * d
            c.drawText(s, popupRect.left + i * cw + cw / 2, baseline(popupRect.centerY()), paint)
        }
    }

    private fun hit(x: Float, y: Float): Cell? {
        var best: Cell? = null; var bd = Float.MAX_VALUE
        for (c in cells) {
            if (c.key.style == KeyStyle.SPACER) continue
            val dx = if (x < c.rect.left) c.rect.left - x else if (x > c.rect.right) x - c.rect.right else 0f
            val dy = if (y < c.rect.top) c.rect.top - y else if (y > c.rect.bottom) y - c.rect.bottom else 0f
            val dist = dx * dx + dy * dy
            if (dist < bd) { bd = dist; best = c }
        }
        return best
    }

    private val longPress = Runnable {
        val p = pressed ?: return@Runnable
        val k = p.key
        if (k.variants.isNotEmpty()) {
            longFired = true
            popupVariants = k.variants
            val w = min(50f * d * k.variants.size, width.toFloat())
            val left = (p.rect.centerX() - w / 2).coerceIn(0f, width - w)
            val top = (p.rect.top - 60 * d).coerceAtLeast(0f)
            popupRect = RectF(left, top, left + w, top + 54 * d)
            popupSel = 0; if (haptic) performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); invalidate()
        } else if (k.longAction != null) {
            longFired = true
            if (haptic) performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            listener?.onKey(k.copy(action = k.longAction, longAction = null), null)
        }
    }
    private val repeat = object : Runnable {
        override fun run() {
            val p = pressed ?: return
            repeating = true; listener?.onKey(p.key, null); uiHandler.postDelayed(this, 50)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                spaceAnim?.cancel(); spaceOff = 0f; onPress?.invoke()
                pressed = hit(e.x, e.y) ?: return true
                downX = e.x; repeating = false; longFired = false; spaceDragging = false
                val k = pressed!!.key
                if (haptic && k.action != KeyAction.NONE) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (k.variants.isNotEmpty() || k.longAction != null) uiHandler.postDelayed(longPress, longPressMs)
                if (k.action == KeyAction.DEL) uiHandler.postDelayed(repeat, 400)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val p = pressed ?: return true
                if (popupVariants.isNotEmpty()) {
                    val cw = popupRect.width() / popupVariants.size
                    popupSel = ((e.x - popupRect.left) / cw).toInt().coerceIn(0, popupVariants.size - 1); invalidate()
                } else if (p.key.action == KeyAction.SPACE && abs(e.x - downX) > 10 * d) {
                    spaceDragging = true
                    val w = p.rect.width()
                    spaceOff = (e.x - downX).coerceIn(-w, w)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                uiHandler.removeCallbacks(longPress); uiHandler.removeCallbacks(repeat)
                val p = pressed
                if (p != null) {
                    when {
                        popupVariants.isNotEmpty() -> listener?.onKey(p.key, popupVariants[popupSel.coerceAtLeast(0)])
                        spaceDragging -> finishSpaceSwipe(p)
                        repeating || longFired -> {}
                        else -> listener?.onKey(p.key, null)
                    }
                }
                clearPress()
            }
            MotionEvent.ACTION_CANCEL -> { uiHandler.removeCallbacks(longPress); uiHandler.removeCallbacks(repeat); spaceOff = 0f; clearPress() }
        }
        return true
    }

    private fun finishSpaceSwipe(p: Cell) {
        val w = p.rect.width(); val dx = spaceOff
        var from = dx
        if (abs(dx) > w * 0.28f) {
            // Swiping right brings the previous (left) language in; swiping left brings the next one.
            listener?.onSpaceSwipe(if (dx > 0) -1 else 1)
            from = dx - w * (if (dx > 0) 1 else -1)
        }
        spaceOff = from
        spaceAnim = ValueAnimator.ofFloat(from, 0f).apply {
            duration = 170
            addUpdateListener { spaceOff = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun clearPress() { pressed = null; popupVariants = emptyList(); popupSel = -1; spaceDragging = false; invalidate() }

    override fun onDetachedFromWindow() { uiHandler.removeCallbacksAndMessages(null); spaceAnim?.cancel(); super.onDetachedFromWindow() }
}
