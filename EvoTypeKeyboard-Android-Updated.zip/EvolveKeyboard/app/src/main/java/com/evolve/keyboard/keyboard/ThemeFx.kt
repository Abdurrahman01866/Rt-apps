package com.evolve.keyboard.keyboard

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Draws a theme's background and (optional) moving effect. Allocation-free per frame; particles are pre-seeded. */
class ThemeFx(private val theme: KeyboardTheme, private val d: Float) {
    private val n = 36
    private val rnd = java.util.Random(11)
    private val px = FloatArray(n) { rnd.nextFloat() }
    private val py = FloatArray(n) { rnd.nextFloat() }
    private val ps = FloatArray(n) { 0.4f + rnd.nextFloat() }
    private val pz = FloatArray(n) { rnd.nextFloat() }
    private val pp = FloatArray(n) { rnd.nextFloat() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val mat = Matrix()
    private var w = 0; private var h = 0
    private var bgShader: LinearGradient? = null
    private var sheen: LinearGradient? = null
    private var bands: Array<LinearGradient> = emptyArray()
    private val fg get() = if (theme.dark) 0xFFFFFFFF.toInt() else theme.accent
    val animated get() = theme.fx != Fx.NONE

    private fun prepare(width: Int, height: Int) {
        w = width; h = height
        bgShader = if (theme.bg2 != theme.background) {
            val len = if (theme.fx == Fx.FLOW) h * 2.2f else h.toFloat()
            LinearGradient(0f, 0f, if (theme.fx == Fx.FLOW) w * 1.5f else 0f, len, theme.background, theme.bg2, Shader.TileMode.MIRROR)
        } else null
        sheen = LinearGradient(0f, 0f, 90 * d, 0f, intArrayOf(0x00FFFFFF, 0x33FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        val a = theme.accent
        bands = arrayOf(
            LinearGradient(0f, 0f, 0f, h * 0.7f, (a and 0x00FFFFFF) or 0x66000000, a and 0x00FFFFFF, Shader.TileMode.CLAMP),
            LinearGradient(0f, 0f, 0f, h * 0.7f, 0x667C9CFF, 0x007C9CFF, Shader.TileMode.CLAMP),
            LinearGradient(0f, 0f, 0f, h * 0.7f, 0x55B26CFF, 0x00B26CFF, Shader.TileMode.CLAMP)
        )
    }

    fun draw(c: Canvas, width: Int, height: Int, tMs: Long, animate: Boolean) {
        if (width != w || height != h) prepare(width, height)
        val t = if (animate) tMs / 1000f else 0f
        paint.shader = null
        val bs = bgShader
        if (bs != null) {
            if (theme.fx == Fx.FLOW && animate) { mat.setTranslate(-(w * 0.75f) * (0.5f + 0.5f * sin(t * 0.35f)), -(h * 0.6f) * (0.5f + 0.5f * cos(t * 0.27f))); bs.setLocalMatrix(mat) }
            paint.shader = bs; c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint); paint.shader = null
        } else { paint.color = theme.background; c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint) }
        if (!animate) return
        when (theme.fx) {
            Fx.STARS -> for (i in 0 until n) {
                val a = 70 + (185 * (0.5f + 0.5f * sin(t * ps[i] * 2.5f + pp[i] * 6.28f))).toInt()
                paint.color = (a shl 24) or 0xFFFFFF; c.drawCircle(px[i] * w, py[i] * h, (0.8f + pz[i] * 1.8f) * d, paint)
            }
            Fx.SNOW -> for (i in 0 until n) {
                val y = ((py[i] + t * ps[i] * 0.06f) % 1f) * h
                paint.color = (fg and 0x00FFFFFF) or 0xB0000000.toInt()
                c.drawCircle(px[i] * w + sin(t * ps[i] + pp[i] * 6.28f) * 12 * d, y, (1.2f + pz[i] * 2.4f) * d, paint)
            }
            Fx.RAIN -> { paint.strokeWidth = 1.4f * d; paint.style = Paint.Style.STROKE
                paint.color = (fg and 0x00FFFFFF) or 0x66000000
                for (i in 0 until n) { val y = ((py[i] + t * ps[i] * 0.8f) % 1f) * h; val x = px[i] * w
                    c.drawLine(x, y, x - 3 * d, y + (10 + 10 * pz[i]) * d, paint) }
                paint.style = Paint.Style.FILL }
            Fx.BUBBLES -> for (i in 0 until n / 2) {
                val y = (1f - ((py[i] + t * ps[i] * 0.05f) % 1f)) * h; val r = (4 + pz[i] * 12) * d
                val x = px[i] * w + sin(t * ps[i] + pp[i] * 6.28f) * 8 * d
                paint.style = Paint.Style.FILL; paint.color = (fg and 0x00FFFFFF) or 0x22000000; c.drawCircle(x, y, r, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.2f * d; paint.color = (fg and 0x00FFFFFF) or 0x66000000; c.drawCircle(x, y, r, paint)
                paint.style = Paint.Style.FILL
            }
            Fx.AURORA -> for (b in 0 until 3) {
                path.reset(); val base = h * (0.18f + 0.16f * b); val step = w / 14f
                path.moveTo(0f, 0f)
                var x = 0f; while (x <= w + step) { path.lineTo(x, base + sin(x / w * 2 * PI.toFloat() * (1.2f + b * 0.4f) + t * (0.5f + b * 0.2f)) * h * 0.12f); x += step }
                path.lineTo(w + step, 0f); path.close()
                paint.shader = bands[b]; c.drawPath(path, paint); paint.shader = null
            }
            Fx.WAVES -> for (b in 0 until 3) {
                path.reset(); val base = h * (0.62f + 0.12f * b); val step = w / 16f
                path.moveTo(0f, h.toFloat())
                var x = 0f; while (x <= w + step) { path.lineTo(x, base + sin(x / w * 2 * PI.toFloat() * (1f + b * 0.3f) + t * (0.8f + b * 0.35f)) * 6 * d); x += step }
                path.lineTo(w + step, h.toFloat()); path.close()
                paint.color = (theme.accent and 0x00FFFFFF) or ((34 + b * 22) shl 24); c.drawPath(path, paint)
            }
            Fx.FIREFLY -> for (i in 0 until n / 2) {
                val x = px[i] * w + sin(t * ps[i] * 0.6f + pp[i] * 6.28f) * 22 * d
                val y = py[i] * h + cos(t * ps[i] * 0.45f + pp[i] * 6.28f) * 14 * d
                val a = (0.5f + 0.5f * sin(t * ps[i] * 2f + pp[i] * 9f))
                paint.color = (theme.accent and 0x00FFFFFF) or ((30 * a).toInt() shl 24); c.drawCircle(x, y, 9 * d, paint)
                paint.color = (theme.accent and 0x00FFFFFF) or ((60 + 195 * a).toInt() shl 24); c.drawCircle(x, y, (1.6f + pz[i] * 1.4f) * d, paint)
            }
            Fx.SHIMMER -> { val x = ((t * 0.22f) % 1.5f - 0.25f) * w
                c.save(); c.translate(x, 0f); c.rotate(18f, 0f, h / 2f); paint.shader = sheen
                c.drawRect(-20 * d, -h.toFloat(), 90 * d, h * 2f, paint); paint.shader = null; c.restore() }
            Fx.NEON -> { val a = 0.55f + 0.45f * sin(t * 2.2f); paint.style = Paint.Style.STROKE
                for (k in 0 until 3) { paint.strokeWidth = (2 + k * 3) * d; paint.color = (theme.accent and 0x00FFFFFF) or (((90 - k * 28) * a).toInt() shl 24)
                    c.drawRoundRect(2 * d, 2 * d, w - 2 * d, h - 2 * d, 10 * d, 10 * d, paint) }
                paint.style = Paint.Style.FILL }
            else -> {}
        }
    }
}
