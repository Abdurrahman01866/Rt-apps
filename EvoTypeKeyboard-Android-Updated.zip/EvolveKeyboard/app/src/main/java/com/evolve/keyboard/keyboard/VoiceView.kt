package com.evolve.keyboard.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.evolve.keyboard.ui.Icon
import com.evolve.keyboard.ui.IconPainter
import kotlin.math.max
import kotlin.math.sin

/** Voice typing screen: the mic pulses and the bars dance with how loudly you speak (SpeechRecognizer RMS level). */
class VoiceView(context: Context) : View(context) {
    enum class State { IDLE, LISTENING, PROCESSING, ERROR }
    interface Listener { fun onClose(); fun onToggle() }

    var listener: Listener? = null
    var theme: KeyboardTheme = KeyboardTheme.ALL[0]
        set(v) { field = v; invalidate() }
    private var state = State.IDLE
    private var message = "Tap the mic to speak"
    private var level = 0f
    private var target = 0f
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val oval = RectF()
    private val backRect = RectF(); private val micRect = RectF(); private val pillRect = RectF()
    private val loop = object : Runnable {
        override fun run() {
            level += (target - level) * 0.28f
            target *= 0.93f                                   // fall back to calm when no new samples arrive
            invalidate()
            if (isShown) postOnAnimation(this)
        }
    }

    fun setLevel(v: Float) { if (v > target) target = v.coerceIn(0f, 1f) }
    fun setState(s: State, msg: String) { state = s; message = msg; if (s != State.LISTENING) target = 0f; invalidate() }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); postOnAnimation(loop) }
    override fun onVisibilityChanged(changed: View, vis: Int) { super.onVisibilityChanged(changed, vis); if (vis == VISIBLE) { removeCallbacks(loop); postOnAnimation(loop) } }
    override fun onDetachedFromWindow() { removeCallbacks(loop); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL; p.color = theme.background; c.drawRect(0f, 0f, w, h, p)
        val t = SystemClock.uptimeMillis() / 1000f
        val cx = w / 2; val cy = h * 0.40f; val base = 32 * d
        val lvl = if (state == State.LISTENING) level else 0f
        val col = when (state) { State.ERROR -> 0xFFE5484D.toInt(); State.IDLE -> theme.function or 0xFF000000.toInt(); else -> theme.accent }

        if (state == State.LISTENING) for (k in 0 until 3) {            // expanding rings, stronger when louder
            val ph = (t * 0.7f + k / 3f) % 1f
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * d
            p.color = (theme.accent and 0x00FFFFFF) or (((1f - ph) * (50 + 170 * lvl)).toInt() shl 24)
            c.drawCircle(cx, cy, base + ph * (14 * d + lvl * 46 * d), p)
        }
        p.style = Paint.Style.FILL
        p.color = (col and 0x00FFFFFF) or 0x33000000; c.drawCircle(cx, cy, base + 10 * d + lvl * 14 * d, p)   // soft glow
        p.color = col; c.drawCircle(cx, cy, base + lvl * 9 * d, p)
        val shake = if (state == State.ERROR) sin(t * 40f) * 2 * d * max(0f, 1f - (t % 3f)) else 0f
        IconPainter.draw(c, Icon.MIC, cx + shake, cy, 30 * d, if (state == State.IDLE) theme.label else 0xFFFFFFFF.toInt())
        if (state == State.IDLE) { p.color = theme.label; p.strokeWidth = 2.6f * d; p.style = Paint.Style.STROKE
            c.drawLine(cx - 16 * d, cy + 16 * d, cx + 16 * d, cy - 16 * d, p); p.style = Paint.Style.FILL }       // slash = mic is off
        if (state == State.PROCESSING) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d; p.color = 0xFFFFFFFF.toInt()
            oval.set(cx - base - 8 * d, cy - base - 8 * d, cx + base + 8 * d, cy + base + 8 * d); c.drawArc(oval, (t * 360f) % 360f, 80f, false, p); p.style = Paint.Style.FILL
        }
        if (state == State.LISTENING) {                                   // equalizer bars
            for (i in -3..3) {
                val amp = (3 + (4 + lvl * 26) * (0.5f + 0.5f * sin(t * 7f + i * 1.3f))) * d
                p.color = (theme.accent and 0x00FFFFFF) or 0xE0000000.toInt()
                c.drawRoundRect(cx + i * 11 * d - 3 * d, cy + base + 22 * d - amp, cx + i * 11 * d + 3 * d, cy + base + 22 * d + amp, 3 * d, 3 * d, p)
            }
        }
        p.color = theme.keyText; p.textSize = 16 * d; c.drawText(message, cx, h * 0.76f, p)

        val label = if (state == State.LISTENING) "Stop" else if (state == State.PROCESSING) "Please wait…" else "Speak"
        pillRect.set(cx - 70 * d, h - 50 * d, cx + 70 * d, h - 10 * d)
        p.color = if (state == State.PROCESSING) theme.function or 0xFF000000.toInt() else theme.accent; c.drawRoundRect(pillRect, 20 * d, 20 * d, p)
        p.color = theme.accentText; p.textSize = 15 * d; c.drawText(label, cx, pillRect.centerY() - (p.ascent() + p.descent()) / 2, p)

        backRect.set(6 * d, 6 * d, 54 * d, 54 * d)
        IconPainter.draw(c, Icon.KEYBOARD, backRect.centerX(), backRect.centerY(), 24 * d, theme.keyText)
        micRect.set(cx - base - 10 * d, cy - base - 10 * d, cx + base + 10 * d, cy + base + 10 * d)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            when {
                backRect.contains(e.x, e.y) -> listener?.onClose()
                (micRect.contains(e.x, e.y) || pillRect.contains(e.x, e.y)) && state != State.PROCESSING -> { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); listener?.onToggle() }
            }
        }
        return true
    }
}
