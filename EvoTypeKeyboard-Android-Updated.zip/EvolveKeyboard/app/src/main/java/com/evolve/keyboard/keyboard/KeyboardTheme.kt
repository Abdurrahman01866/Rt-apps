package com.evolve.keyboard.keyboard

import android.graphics.Color

enum class Fx { NONE, FLOW, STARS, SNOW, RAIN, BUBBLES, AURORA, WAVES, FIREFLY, SHIMMER, NEON }

data class KeyboardTheme(
    val id: String, val name: String,
    val background: Int, val bg2: Int, val key: Int, val keyText: Int, val function: Int,
    val accent: Int, val accentText: Int, val popup: Int, val label: Int, val fx: Fx = Fx.NONE
) {
    val dark: Boolean get() = luminance(background) < 140

    /** [col] blended over the background, fully opaque (for views that cannot be translucent). */
    fun solid(col: Int): Int {
        val a = Color.alpha(col) / 255f
        fun m(f: Int, b: Int) = (f * a + b * (1 - a)).toInt()
        return Color.rgb(m(Color.red(col), Color.red(background)), m(Color.green(col), Color.green(background)), m(Color.blue(col), Color.blue(background)))
    }

    companion object {
        private fun c(s: String) = Color.parseColor(s)
        private fun luminance(col: Int) = (0.299 * Color.red(col) + 0.587 * Color.green(col) + 0.114 * Color.blue(col)).toInt()
        private fun onAccent(accent: Int) = if (luminance(accent) > 170) c("#10152B") else Color.WHITE

        private fun solid(id: String, name: String, bg: String, key: String, text: String, fn: String, accent: String, popup: String, label: String) =
            KeyboardTheme(id, name, c(bg), c(bg), c(key), c(text), c(fn), c(accent), onAccent(c(accent)), c(popup), c(label))

        /** Animated themes: translucent keys over a gradient (+ moving effect). [dark] picks light or dark text. */
        private fun fx(id: String, name: String, fx: Fx, dark: Boolean, bg: String, bg2: String, accent: String) =
            KeyboardTheme(id, name, c(bg), c(bg2),
                if (dark) c("#38FFFFFF") else c("#D9FFFFFF"), if (dark) Color.WHITE else c("#14213D"),
                if (dark) c("#22FFFFFF") else c("#99FFFFFF"), c(accent), onAccent(c(accent)),
                if (dark) c("#FF2A3350") else Color.WHITE, if (dark) c("#C8D3F0") else c("#4A5575"), fx)

        val ALL: List<KeyboardTheme> = listOf(
            solid("evolve", "Evolve Night", "#0B1030", "#1E2759", "#FFFFFF", "#141B40", "#1F6BFF", "#2B3670", "#9AA6D8"),
            solid("snow", "Snow", "#E8ECF8", "#FFFFFF", "#0B1030", "#CBD3EC", "#1F6BFF", "#FFFFFF", "#55608F"),
            solid("violet", "Violet", "#1A0B3B", "#2C1A5C", "#FFFFFF", "#21124A", "#7B2FF7", "#3B2477", "#B8A6E8"),
            solid("forest", "Forest", "#0E2A22", "#1B4034", "#FFFFFF", "#14352A", "#14B87A", "#25594A", "#9CD6C2"),
            solid("minimal", "Minimal", "#FFFFFF", "#F1F2F4", "#111111", "#E2E4E8", "#111111", "#F1F2F4", "#777777"),
            fx("aurora", "Aurora", Fx.AURORA, true, "#04121F", "#0B3B4A", "#2EE6A6"),
            fx("starry", "Starry Night", Fx.STARS, true, "#050B2E", "#1B1F5E", "#7C9CFF"),
            fx("snowfall", "Snowfall", Fx.SNOW, false, "#DCEBFA", "#BFD9F2", "#2F7BFF"),
            fx("rain", "Rain", Fx.RAIN, true, "#1B2433", "#2E3B52", "#4DA3FF"),
            fx("bubbles", "Bubbles", Fx.BUBBLES, false, "#CFF4FF", "#9FD8F5", "#00A8E8"),
            fx("ocean", "Ocean Waves", Fx.WAVES, true, "#03264A", "#0A5C8F", "#29C3FF"),
            fx("fireflies", "Fireflies", Fx.FIREFLY, true, "#07160F", "#0F2E1E", "#C8FF3D"),
            fx("neon", "Neon Pulse", Fx.NEON, true, "#0A0014", "#1E0036", "#FF2BD6"),
            fx("sunset", "Sunset Flow", Fx.FLOW, true, "#5B1A6E", "#F2674A", "#FFB347"),
            fx("candy", "Cotton Candy", Fx.FLOW, false, "#FFD6EC", "#C9E4FF", "#FF5FA2"),
            fx("midnightgold", "Midnight Gold", Fx.SHIMMER, true, "#121212", "#2A2415", "#E6B800"),
            fx("rosegold", "Rose Gold", Fx.SHIMMER, false, "#FBE4E0", "#F4C7C3", "#D9788C"),
            fx("matrix", "Matrix", Fx.RAIN, true, "#00110A", "#002A15", "#00FF66"),
            fx("lavender", "Lavender", Fx.BUBBLES, false, "#EADCFF", "#D2BDF7", "#8B5CF6"),
            fx("mint", "Mint", Fx.FLOW, false, "#D7F8EA", "#BFEBDD", "#12B886"),
            fx("lava", "Lava", Fx.FIREFLY, true, "#1A0500", "#4A0E00", "#FF5A1F"),
            fx("galaxy", "Galaxy", Fx.STARS, true, "#0B0220", "#3A0F66", "#B26CFF"),
            fx("arctic", "Arctic", Fx.SNOW, false, "#EAF6FF", "#D4ECFB", "#00A3FF"),
            fx("desert", "Desert", Fx.WAVES, false, "#F7E8C8", "#E9CF9B", "#D98324"),
            fx("forestmist", "Forest Mist", Fx.AURORA, true, "#06190F", "#14442C", "#3DDC84"),
            fx("candypop", "Candy Pop", Fx.BUBBLES, false, "#FFE0EE", "#FFC2DD", "#FF3D8B"),
            fx("royal", "Royal Blue", Fx.SHIMMER, true, "#07123A", "#14246E", "#FFC83D"),
            fx("ice", "Ice", Fx.SHIMMER, false, "#E0F7FF", "#C0EBFA", "#1AB5E8"),
            fx("dracula", "Dracula", Fx.NEON, true, "#14070C", "#2B0A14", "#E11D48"),
            fx("peach", "Peach", Fx.FLOW, false, "#FFE5D2", "#FFCBB0", "#FF7A3D"),
            fx("monsoon", "Monsoon", Fx.RAIN, true, "#14232E", "#243B4D", "#5CC8F5"),
            fx("shiuli", "Shiuli", Fx.SNOW, false, "#F3FBF2", "#FFE9EE", "#F97316"),
            fx("padma", "Padma", Fx.WAVES, true, "#02201C", "#0B5A4E", "#2DD4BF"),
            fx("sundarban", "Sundarban", Fx.FIREFLY, true, "#031A0D", "#0B3A1E", "#86EFAC"),
            fx("pride", "Bangla Pride", Fx.FLOW, true, "#0B6B3A", "#B3122D", "#F5C518")
        )
        fun byId(id: String?) = ALL.firstOrNull { it.id == id } ?: ALL[0]
    }
}
