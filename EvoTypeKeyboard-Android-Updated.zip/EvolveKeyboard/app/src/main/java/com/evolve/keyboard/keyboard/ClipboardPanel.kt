package com.evolve.keyboard.keyboard

import android.content.Context
import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.evolve.keyboard.clipboard.ClipboardRepository
import com.evolve.keyboard.i18n.Tr
import com.evolve.keyboard.keyboard.PanelParts.dp
import com.evolve.keyboard.ui.Icon
import com.evolve.keyboard.ui.IconView

/** Scrollable clipboard: card per item, pin in the corner, red delete beside the expiry note. */
class ClipboardPanel(context: Context) : LinearLayout(context) {
    interface Listener { fun onBack(); fun onPaste(text: String) }
    var listener: Listener? = null
    private var theme = KeyboardTheme.ALL[0]
    private var repo: ClipboardRepository? = null
    private var pinnedTab = false
    private val list = LinearLayout(context).apply { orientation = VERTICAL; setPadding(dp(context, 10), dp(context, 2), dp(context, 10), dp(context, 6)) }
    private val head = LinearLayout(context)
    private val note = TextView(context)
    private val red = Color.parseColor("#E5484D")

    init {
        orientation = VERTICAL
        addView(head, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(ScrollView(context).apply { addView(list); isVerticalScrollBarEnabled = false }, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        note.apply { gravity = Gravity.CENTER; setPadding(0, dp(context, 4), 0, dp(context, 6)); textSize = 11.5f }
        addView(note, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    fun bind(theme: KeyboardTheme, repo: ClipboardRepository) { this.theme = theme; this.repo = repo; setBackgroundColor(theme.background); refresh() }

    private fun tab(label: String, on: Boolean, onClick: () -> Unit) = TextView(context).apply {
        text = Tr.t(label); gravity = Gravity.CENTER; textSize = 14f; setPadding(dp(context, 16), 0, dp(context, 16), 0)
        setTextColor(if (on) theme.accentText else theme.keyText)
        background = if (on) PanelParts.rounded(theme.accent, dp(context, 18).toFloat()) else null
        setOnClickListener { onClick() }
    }

    fun refresh() {
        val r = repo ?: return
        head.removeAllViews()
        head.addView(PanelParts.header(context, theme, "", { listener?.onBack() }).apply {
            addView(tab("Recent", !pinnedTab) { pinnedTab = false; refresh() }, LayoutParams(LayoutParams.WRAP_CONTENT, dp(context, 36)))
            addView(tab("Pinned", pinnedTab) { pinnedTab = true; refresh() }, LayoutParams(LayoutParams.WRAP_CONTENT, dp(context, 36)).apply { leftMargin = dp(context, 6) })
            addView(android.view.View(context), LayoutParams(0, 1, 1f))
            addView(TextView(context).apply { text = Tr.t("Clear all"); setTextColor(red); textSize = 13f; setPadding(dp(context, 8), dp(context, 8), dp(context, 4), dp(context, 8))
                setOnClickListener { if (pinnedTab) r.pinned().forEach { r.unpin(it.id) } else r.recent().forEach { r.deleteRecent(it.id) }; refresh() } })
        })
        note.setTextColor(theme.label)
        note.text = if (pinnedTab) "" else Tr.t("Removed automatically after 1 hour")
        list.removeAllViews()
        val items = if (pinnedTab) r.pinned() else r.recent()
        if (items.isEmpty()) list.addView(PanelParts.text(context, if (pinnedTab) "Pin items from Recent to keep them here" else "Nothing copied in the last hour", 14f, theme.label).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(context, 36), 0, 0) })
        val now = System.currentTimeMillis()
        val card = theme.solid(theme.key)
        items.forEachIndexed { idx, e ->
            val c = LinearLayout(context).apply { orientation = VERTICAL; setPadding(dp(context, 12), dp(context, 10), dp(context, 8), dp(context, 8))
                background = PanelParts.rounded(card, dp(context, 14).toFloat()); setOnClickListener { listener?.onPaste(e.text) } }
            val top = LinearLayout(context).apply { gravity = Gravity.TOP }
            top.addView(PanelParts.text(context, e.text, 14.5f, theme.keyText).apply { maxLines = 3; ellipsize = TextUtils.TruncateAt.END }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            top.addView(IconView(context, Icon.PIN, if (pinnedTab) theme.accent else theme.label).apply { contentDescription = "Pin"; setPadding(dp(context, 6), dp(context, 6), dp(context, 6), dp(context, 6))
                setOnClickListener { if (pinnedTab) r.unpin(e.id) else r.pin(e.text); refresh() } }, LayoutParams(dp(context, 30), dp(context, 30)))
            c.addView(top)
            val bottom = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL }
            val mins = ((e.time + ClipboardRepository.EXPIRY_MS - now) / 60000L + 1).coerceAtLeast(1)
            bottom.addView(PanelParts.text(context, if (pinnedTab) "" else "Expires in $mins min", 11.5f, theme.label), LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            if (pinnedTab) {
                fun mv(icon: Icon, d: Int) = IconView(context, icon, theme.label).apply { setOnClickListener { r.movePinned(e.id, d); refresh() } }
                if (idx > 0) bottom.addView(mv(Icon.ARROW_UP, -1), LayoutParams(dp(context, 22), dp(context, 22)))
                if (idx < items.lastIndex) bottom.addView(mv(Icon.ARROW_DOWN, 1), LayoutParams(dp(context, 22), dp(context, 22)).apply { leftMargin = dp(context, 6) })
            }
            bottom.addView(IconView(context, Icon.TRASH, red).apply { contentDescription = Tr.t("Delete"); setOnClickListener { if (pinnedTab) r.unpin(e.id) else r.deleteRecent(e.id); refresh() } },
                LayoutParams(dp(context, 22), dp(context, 22)).apply { leftMargin = dp(context, 10) })
            bottom.addView(PanelParts.text(context, Tr.t("Delete"), 12f, red).apply { setPadding(dp(context, 4), 0, 0, 0)
                setOnClickListener { if (pinnedTab) r.unpin(e.id) else r.deleteRecent(e.id); refresh() } })
            c.addView(bottom, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 6) })
            list.addView(c, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(context, 8) })
        }
    }
}
