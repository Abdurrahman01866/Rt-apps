package com.evolve.keyboard.settings

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import com.evolve.keyboard.i18n.Tr
import kotlin.math.sin

/**
 * Animated mock of the Android screen the user must use, with an arrow pointing at exactly what to tap.
 * mode 0 = keyboard list (switch Evolve ON), mode 1 = "choose keyboard" dialog (pick Evolve).
 */
class GuideView(context: Context, private val mode: Int) : View(context) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val arrow = Path()
    private val loop = object : Runnable { override fun run() { invalidate(); if (isShown) postDelayed(this, 33) } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(loop) }
    override fun onDetachedFromWindow() { removeCallbacks(loop); super.onDetachedFromWindow() }

    private fun lerp(a: Int, b: Int, k: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(), (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(), (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val t = System.currentTimeMillis() / 1000f
        p.style = Paint.Style.FILL; p.color = Ui.FIELD; rect.set(0f, 0f, w, h); c.drawRoundRect(rect, 22 * d, 22 * d, p)
        val cardL = 18 * d; val cardR = w - 18 * d; val cardT = 14 * d
        p.color = Ui.CARD; rect.set(cardL, cardT, cardR, h - 14 * d); c.drawRoundRect(rect, 16 * d, 16 * d, p)
        p.color = Ui.SUB; p.textSize = 12 * d; p.typeface = Typeface.DEFAULT_BOLD
        c.drawText(Tr.t(if (mode == 0) "Keyboard list" else "Choose keyboard"), cardL + 16 * d, cardT + 26 * d, p)
        p.typeface = Typeface.DEFAULT
        val ph = (t % 3.4f) / 3.4f
        val k = when { ph < 0.4f -> 0f; ph < 0.55f -> (ph - 0.4f) / 0.15f; else -> 1f }
        val rows = listOf("Default keyboard", "Evolve Keyboard", "Other keyboard")
        var targetX = 0f; var targetY = 0f
        rows.forEachIndexed { i, name ->
            val cy = cardT + 62 * d + i * 42 * d
            val evolve = i == 1
            if (evolve) { p.color = Color.argb(28, 31, 107, 255); rect.set(cardL + 6 * d, cy - 19 * d, cardR - 6 * d, cy + 19 * d); c.drawRoundRect(rect, 12 * d, 12 * d, p) }
            if (evolve) {                                                       // brand icon
                p.shader = LinearGradient(cardL + 14 * d, cy - 12 * d, cardL + 38 * d, cy + 12 * d, Ui.BRAND, null, Shader.TileMode.CLAMP)
                rect.set(cardL + 14 * d, cy - 12 * d, cardL + 38 * d, cy + 12 * d); c.drawRoundRect(rect, 7 * d, 7 * d, p); p.shader = null
            } else { p.color = Ui.LINE; rect.set(cardL + 14 * d, cy - 12 * d, cardL + 38 * d, cy + 12 * d); c.drawRoundRect(rect, 7 * d, 7 * d, p) }
            p.color = Ui.NAVY; p.textSize = 14 * d; p.typeface = if (evolve) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            c.drawText(name, cardL + 48 * d, cy + 5 * d, p); p.typeface = Typeface.DEFAULT
            val cx = cardR - 38 * d
            if (mode == 0) {                                                    // switch
                val on = if (evolve) k else if (i == 0) 1f else 0f
                p.color = lerp(Ui.LINE, if (evolve) Ui.GREEN else Color.parseColor("#8FA0D8"), on)
                rect.set(cx - 20 * d, cy - 11 * d, cx + 20 * d, cy + 11 * d); c.drawRoundRect(rect, 11 * d, 11 * d, p)
                p.color = Color.WHITE; c.drawCircle(cx - 9 * d + on * 18 * d, cy, 8 * d, p)
                if (evolve) { targetX = cx; targetY = cy }
            } else {                                                            // radio button
                val on = if (evolve) k else 0f
                p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = lerp(Ui.SUB, Ui.BLUE, on); c.drawCircle(cx, cy, 10 * d, p)
                p.style = Paint.Style.FILL; if (on > 0f) { p.color = Ui.BLUE; c.drawCircle(cx, cy, 5.5f * d * on, p) }
                if (evolve) { targetX = cx; targetY = cy }
            }
        }
        // pulsing ring + bouncing arrow that points at the control
        val pulse = 0.5f + 0.5f * sin(t * 4f)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * d; p.color = Color.argb((90 + 120 * pulse).toInt(), 31, 107, 255)
        c.drawCircle(targetX, targetY, (24 + 4 * pulse) * d, p); p.style = Paint.Style.FILL
        val bob = sin(t * 5f) * 4 * d
        val tipY = targetY + 28 * d + bob
        p.color = Ui.BLUE; arrow.reset()
        arrow.moveTo(targetX, tipY); arrow.lineTo(targetX - 9 * d, tipY + 11 * d); arrow.lineTo(targetX - 3.5f * d, tipY + 11 * d)
        arrow.lineTo(targetX - 3.5f * d, tipY + 24 * d); arrow.lineTo(targetX + 3.5f * d, tipY + 24 * d); arrow.lineTo(targetX + 3.5f * d, tipY + 11 * d)
        arrow.lineTo(targetX + 9 * d, tipY + 11 * d); arrow.close(); c.drawPath(arrow, p)
        p.textSize = 12.5f * d; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.RIGHT
        c.drawText(Tr.t(if (mode == 0) "Turn ON" else "Tap here"), targetX - 16 * d, tipY + 22 * d, p); p.textAlign = Paint.Align.LEFT; p.typeface = Typeface.DEFAULT
    }
}
