package com.evolve.keyboard.keyboard

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.evolve.keyboard.i18n.Tr
import com.evolve.keyboard.keyboard.PanelParts.dp
import com.evolve.keyboard.ui.Icon
import com.evolve.keyboard.ui.IconView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

/**
 * Translate what you typed between any two languages supported by Google ML Kit (~59). Translation runs ON the phone; each language
 * pack is downloaded once (that is the only reason the app has the INTERNET permission). Your text is never sent to a server by Evolve.
 */
class TranslatePanel(context: Context) : LinearLayout(context) {
    interface Listener { fun onBack(); fun onReplace(text: String); fun onInsert(text: String); fun onLanguages(from: String, to: String) }
    var listener: Listener? = null
    private var theme = KeyboardTheme.ALL[0]
    private var from = "en"; private var to = "bn"
    private var source = ""; private var result = ""
    private val fromBtn = TextView(context); private val toBtn = TextView(context)
    private val srcView = TextView(context); private val resView = TextView(context); private val status = TextView(context)
    private val actions = LinearLayout(context)
    private val body = LinearLayout(context).apply { orientation = VERTICAL }
    private val picker = ScrollView(context); private val pickList = LinearLayout(context).apply { orientation = VERTICAL }
    private val frame = FrameLayout(context)
    private var picking: Boolean? = null     // true = choosing the source language, false = target

    init { orientation = VERTICAL }

    private fun name(code: String) = Locale.forLanguageTag(code).let { "${it.getDisplayLanguage(it)} (${it.getDisplayLanguage(Locale.ENGLISH)})" }
    private fun short(code: String) = Locale.forLanguageTag(code).getDisplayLanguage(Locale.ENGLISH)

    fun bind(theme: KeyboardTheme, source: String, from: String, to: String) {
        this.theme = theme; this.source = source; this.from = from; this.to = to; result = ""; picking = null
        body.visibility = View.VISIBLE; picker.visibility = View.GONE
        removeAllViews(); body.removeAllViews(); pickList.removeAllViews(); frame.removeAllViews(); actions.removeAllViews()
        setBackgroundColor(theme.background)
        val bar = PanelParts.header(context, theme, "") { listener?.onBack() }
        fun chip(v: TextView, code: String, isFrom: Boolean) = v.apply {
            text = short(code) + " ▾"; textSize = 13.5f; setTextColor(theme.keyText); gravity = Gravity.CENTER
            setPadding(dp(context, 12), 0, dp(context, 12), 0); background = PanelParts.rounded(theme.solid(theme.key), dp(context, 18).toFloat())
            setOnClickListener { openPicker(isFrom) }
        }
        bar.addView(chip(fromBtn, from, true), LayoutParams(0, dp(context, 36), 1f))
        bar.addView(IconView(context, Icon.TRANSLATE, theme.accent).apply { contentDescription = "Swap"
            setOnClickListener { val t = this@TranslatePanel.from; this@TranslatePanel.from = this@TranslatePanel.to; this@TranslatePanel.to = t; commitLangs(); bind(theme, source, this@TranslatePanel.from, this@TranslatePanel.to) } },
            LayoutParams(dp(context, 34), dp(context, 34)).apply { setMargins(dp(context, 6), 0, dp(context, 6), 0) })
        bar.addView(chip(toBtn, to, false), LayoutParams(0, dp(context, 36), 1f))
        addView(bar, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        srcView.apply { text = if (source.isBlank()) Tr.t("Type something first") else source; textSize = 14f; maxLines = 3; setTextColor(theme.label)
            setPadding(dp(context, 12), dp(context, 8), dp(context, 12), dp(context, 8)); background = PanelParts.rounded(theme.solid(theme.key), dp(context, 12).toFloat()) }
        resView.apply { text = ""; textSize = 17f; maxLines = 4; setTextColor(theme.keyText); setPadding(dp(context, 12), dp(context, 8), dp(context, 12), dp(context, 8))
            background = PanelParts.rounded(theme.solid(theme.function), dp(context, 12).toFloat()); minHeight = dp(context, 52) }
        status.apply { text = ""; textSize = 12f; setTextColor(theme.label); setPadding(dp(context, 14), dp(context, 4), dp(context, 14), 0) }
        body.addView(srcView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { setMargins(dp(context, 10), dp(context, 2), dp(context, 10), dp(context, 6)) })
        body.addView(resView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { setMargins(dp(context, 10), 0, dp(context, 10), 0) })
        body.addView(status)
        fun btn(label: String, primary: Boolean, onClick: () -> Unit) = TextView(context).apply {
            text = Tr.t(label); gravity = Gravity.CENTER; textSize = 14f; setTextColor(if (primary) theme.accentText else theme.keyText)
            background = PanelParts.rounded(if (primary) theme.accent else theme.solid(theme.key), dp(context, 20).toFloat()); setOnClickListener { onClick() }
        }
        actions.removeAllViews()
        actions.addView(btn("Translate", true) { translate() }, LayoutParams(0, dp(context, 40), 1.3f))
        actions.addView(btn("Replace", false) { if (result.isNotEmpty()) listener?.onReplace(result) }, LayoutParams(0, dp(context, 40), 1f).apply { leftMargin = dp(context, 6) })
        actions.addView(btn("Insert", false) { if (result.isNotEmpty()) listener?.onInsert(result) }, LayoutParams(0, dp(context, 40), 1f).apply { leftMargin = dp(context, 6) })
        body.addView(actions, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { setMargins(dp(context, 10), dp(context, 8), dp(context, 10), 0) })
        picker.apply { removeAllViews(); addView(pickList); visibility = View.GONE }
        frame.addView(body, FrameLayout.LayoutParams(-1, -1)); frame.addView(picker, FrameLayout.LayoutParams(-1, -1))
        addView(frame, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun commitLangs() { listener?.onLanguages(from, to) }

    private fun openPicker(isFrom: Boolean) {
        picking = isFrom; pickList.removeAllViews()
        TranslateLanguage.getAllLanguages().sortedBy { short(it) }.forEach { code ->
            pickList.addView(PanelParts.text(context, name(code), 15f, if (code == (if (isFrom) from else to)) theme.accent else theme.keyText).apply {
                setPadding(dp(context, 16), dp(context, 11), dp(context, 16), dp(context, 11))
                setOnClickListener { if (isFrom) from = code else to = code; picking = null; commitLangs(); bind(theme, source, from, to) } })
        }
        body.visibility = View.GONE; picker.visibility = View.VISIBLE; picker.scrollTo(0, 0)
    }

    private fun translate() {
        if (source.isBlank()) { status.text = Tr.t("Type something first"); return }
        if (from == to) { resView.text = source; result = source; return }
        status.text = Tr.t("Downloading language pack…"); resView.text = ""
        val client = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(to).build())
        client.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                status.text = Tr.t("Translating…")
                client.translate(source)
                    .addOnSuccessListener { r -> result = r; resView.text = r; status.text = ""; client.close() }
                    .addOnFailureListener { e -> status.text = e.message ?: "Translation failed"; client.close() }
            }
            .addOnFailureListener { status.text = "Couldn't download the language pack. Connect to the internet once, then try again."; client.close() }
    }
}
