package com.evolve.keyboard.settings

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import com.evolve.keyboard.R
import com.evolve.keyboard.banglish.AvroEngine
import com.evolve.keyboard.banglish.BanglishEngine
import com.evolve.keyboard.clipboard.ClipboardRepository
import com.evolve.keyboard.clipboard.PrefsKeyValueStore
import com.evolve.keyboard.keyboard.Fx
import com.evolve.keyboard.keyboard.KeyboardTheme
import com.evolve.keyboard.settings.Ui.MATCH
import com.evolve.keyboard.settings.Ui.WRAP
import com.evolve.keyboard.suggest.ShortcutStore
import com.evolve.keyboard.suggest.UserWords
import com.evolve.keyboard.ui.Icon
import com.evolve.keyboard.ui.IconView

object Setup {
    fun isEnabled(c: Context) = (c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        .enabledInputMethodList.any { it.packageName == c.packageName }
    fun isSelected(c: Context) = Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        ?.startsWith(c.packageName + "/") == true
    fun micGranted(c: Context) = c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
}

/** One activity, many screens: splash -> onboarding (first run) -> main tabs (Home, Themes, Tools, Settings) -> detail screens. */
class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private var current: (() -> View)? = null
    private val stack = ArrayList<() -> View>()
    private var onboardStep = 0
    private var onboarding = false
    private var micOnly = false
    private var tab = 0
    private val engine = BanglishEngine()
    private val ui = Handler(Looper.getMainLooper())
    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this); setContentView(root)
        micOnly = intent.getBooleanExtra("mic", false)
        if (micOnly) { onboarding = true; show(Ui.BG, true) { micStep() } } else showSplash()
    }

    override fun onResume() { super.onResume(); if (onboarding) current?.let { show(Ui.BG, true, false, it) } }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus && onboarding && current != null) show(Ui.BG, true, false, current!!) }

    override fun onBackPressed() {
        when {
            stack.isNotEmpty() -> show(Ui.BG, true, true, stack.removeAt(stack.lastIndex))
            onboarding && onboardStep > 0 && !micOnly -> { onboardStep--; show(Ui.BG, true) { onboardingStep() } }
            else -> super.onBackPressed()
        }
    }

    private fun show(bar: Int, lightBars: Boolean, animate: Boolean = true, builder: () -> View) {
        current = builder
        window.statusBarColor = bar; window.navigationBarColor = bar
        window.decorView.systemUiVisibility = if (lightBars) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
        val v = builder()
        root.removeAllViews(); root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        if (animate) { v.alpha = 0f; v.translationY = d(14).toFloat(); v.animate().alpha(1f).translationY(0f).setDuration(220).start() }
    }
    private fun push(builder: () -> View) { current?.let { stack.add(it) }; show(Ui.BG, true, true, builder) }
    private fun refresh() { current?.let { show(Ui.BG, true, false, it) } }

    // ------------------------------------------------------------------ splash

    private fun showSplash() {
        show(Ui.BRAND[1], false) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, Ui.BRAND)
            }
            val logo = ImageView(this).apply { setImageResource(R.drawable.evolve_icon); alpha = 0f; scaleX = 0.7f; scaleY = 0.7f }
            col.addView(logo, LinearLayout.LayoutParams(d(124), d(124)))
            val name = Ui.text(this, "Evolve Keyboard", 28f, Color.WHITE, true).apply { alpha = 0f }
            col.addView(name, Ui.lp(this, WRAP, WRAP, t = 24))
            val tag = Ui.text(this, "বাংলা  •  অভ্র  •  Banglish  •  English", 15f, Color.argb(210, 255, 255, 255)).apply { alpha = 0f }
            col.addView(tag, Ui.lp(this, WRAP, WRAP, t = 6))
            logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()
            name.animate().alpha(1f).setStartDelay(250).setDuration(500).start()
            tag.animate().alpha(1f).setStartDelay(450).setDuration(500).start()
            ui.postDelayed({ if (!isFinishing) route() }, 1500)
            col
        }
    }

    private fun route() { if (Prefs.onboarded(this)) showMain() else { onboarding = true; onboardStep = 0; show(Ui.BG, true) { onboardingStep() } } }
    private fun showMain(t: Int = 0) { onboarding = false; stack.clear(); tab = t; show(Ui.BG, true) { mainScreen() } }

    // ------------------------------------------------------------------ onboarding

    private fun onboardingStep(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(24), d(20), d(24), d(24)); setBackgroundColor(Ui.BG) }
        val dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        for (i in 0 until 5) dots.addView(View(this).apply {
            background = Ui.rounded(this@MainActivity, if (i <= onboardStep) Ui.BLUE else Color.parseColor("#CBD3EC"), 4)
        }, Ui.lp(this, d(if (i == onboardStep) 26 else 8), d(8), l = 4, r = 4))
        page.addView(dots, Ui.lp(this, MATCH, WRAP, b = 12))

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val foot = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun title(s: String) = body.addView(Ui.text(this, s, 26f, Ui.NAVY, true).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 24))
        fun para(s: String) = body.addView(Ui.text(this, s, 16f, Ui.SUB).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 10))
        fun hero(icon: Icon, idx: Int) = body.addView(Ui.badge(this, icon, 104, Ui.PALETTE[idx]), LinearLayout.LayoutParams(d(104), d(104)))
        fun status(ok: Boolean, yes: String, no: String) = body.addView(Ui.chip(this, if (ok) "✓  $yes" else no, if (ok) Ui.GREEN else Ui.ORANGE), Ui.lp(this, WRAP, WRAP, t = 18))
        fun go(step: Int) { onboardStep = step; show(Ui.BG, true) { onboardingStep() } }

        when (onboardStep) {
            0 -> {
                body.addView(HeroView(this, "Evolve Keyboard", "Type your way, beautifully"), Ui.lp(this, MATCH, d(200)))
                title("বাংলা, অভ্র, Banglish ও English")
                para("One fast, private keyboard for everything you type.")
                val feats = Ui.card(this)
                listOf(Icon.GLOBE to "Swipe the space bar to switch languages", Icon.SPARKLE to "Smart suggestions that learn the words you use",
                    Icon.SHIELD to "No ads and no internet permission").forEachIndexed { i, (ic, s) ->
                    val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                    row.addView(Ui.badge(this, ic, 38, Ui.PALETTE[i * 2]), LinearLayout.LayoutParams(d(38), d(38)))
                    row.addView(Ui.text(this, s, 15f), Ui.lp(this, MATCH, WRAP, l = 12))
                    feats.addView(row, Ui.lp(this, t = if (i == 0) 0 else 14))
                }
                body.addView(feats, Ui.lp(this, t = 20))
                foot.addView(Ui.primaryButton(this, "Get started") { go(1) })
            }
            1 -> {
                val on = Setup.isEnabled(this)
                hero(Icon.KEYBOARD, 0); title("Turn on Evolve Keyboard")
                para("Switch Evolve on once in Android's keyboard list. Android shows the same generic warning for every keyboard — Evolve has no internet permission, so it cannot send what you type anywhere.")
                status(on, "Enabled", "Not enabled yet")
                foot.addView(Ui.primaryButton(this, if (on) "Next" else "Open keyboard settings") { if (on) go(2) else startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
            }
            2 -> {
                val sel = Setup.isSelected(this)
                hero(Icon.GLOBE, 2); title("Make it your keyboard")
                para("Pick Evolve Keyboard in the chooser so it opens whenever you type.")
                status(sel, "Selected", "Not selected yet")
                foot.addView(Ui.primaryButton(this, if (sel) "Next" else "Choose keyboard") {
                    if (sel) go(3) else (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                })
            }
            3 -> return micStep()
            else -> {
                hero(Icon.CHECK, 5); title("You're all set")
                para("Open any text box. Swipe the space bar to change language, and tap the icons above the keys for clipboard, emoji, themes and voice.")
                foot.addView(Ui.primaryButton(this, "Open Evolve") { Prefs.setOnboarded(this, true); showMain() })
            }
        }
        page.addView(ScrollView(this).apply { isFillViewport = true; addView(body) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        page.addView(foot, Ui.lp(this, t = 16))
        return page
    }

    private fun micStep(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(24), d(20), d(24), d(24)); setBackgroundColor(Ui.BG) }
        val ok = Setup.micGranted(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        body.addView(Ui.badge(this, Icon.MIC, 104, Ui.PALETTE[1]), LinearLayout.LayoutParams(d(104), d(104)))
        body.addView(Ui.text(this, "Voice typing (optional)", 26f, Ui.NAVY, true).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 24))
        body.addView(Ui.text(this, "Allow the microphone only if you want to dictate. It is used only after you tap the mic key. Speech is handled by your phone's speech service, which may use the internet. Evolve asks for no other permission.", 16f, Ui.SUB).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 10))
        body.addView(Ui.chip(this, if (ok) "✓  Microphone allowed" else "Not allowed", if (ok) Ui.GREEN else Ui.ORANGE), Ui.lp(this, WRAP, WRAP, t = 18))
        page.addView(ScrollView(this).apply { isFillViewport = true; addView(body) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val next = { if (micOnly) finish() else { onboardStep = 4; show(Ui.BG, true) { onboardingStep() } } }
        page.addView(Ui.primaryButton(this, if (ok) (if (micOnly) "Done" else "Next") else "Allow microphone") {
            if (ok) next() else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }, Ui.lp(this, t = 16))
        if (!ok) page.addView(Ui.textButton(this, if (micOnly) "Not now" else "Skip for now") { next() }, Ui.lp(this, t = 4))
        return page
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res); current?.let { show(Ui.BG, true, false, it) }
    }

    // ------------------------------------------------------------------ main tabs

    private fun mainScreen(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(16), d(20), d(24)) }
        when (tab) { 0 -> homeTab(col); 1 -> themesTab(col); 2 -> toolsTab(col); else -> settingsTab(col) }
        page.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val nav = LinearLayout(this).apply { setBackgroundColor(Color.WHITE); elevation = d(8).toFloat(); setPadding(0, d(6), 0, d(6)) }
        listOf(Icon.HOME to "Home", Icon.THEME to "Themes", Icon.GRID to "Tools", Icon.SETTINGS to "Settings").forEachIndexed { i, (ic, label) ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true; contentDescription = label
                setOnClickListener { if (tab != i) { tab = i; show(Ui.BG, true) { mainScreen() } } }; Ui.pressable(this) }
            val on = i == tab
            item.addView(FrameLayout(this).apply {
                background = if (on) Ui.rounded(this@MainActivity, Color.argb(36, 31, 107, 255), 16) else null
                addView(IconView(this@MainActivity, ic, if (on) Ui.BLUE else Ui.SUB), FrameLayout.LayoutParams(d(24), d(24)).apply { gravity = Gravity.CENTER })
            }, LinearLayout.LayoutParams(d(60), d(32)))
            item.addView(Ui.text(this, label, 11.5f, if (on) Ui.BLUE else Ui.SUB, on), Ui.lp(this, WRAP, WRAP, t = 2))
            nav.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        page.addView(nav)
        return page
    }

    private fun langName(n: String) = when (n) { "JATIYA" -> "জাতীয়"; "AVRO" -> "অভ্র"; "CLASSIC" -> "বাংলা"; "EN" -> "English"; else -> "Banglish" }

    private fun homeTab(col: LinearLayout) {
        val ready = Setup.isEnabled(this) && Setup.isSelected(this)
        col.addView(HeroView(this, "Evolve Keyboard", "Type your way, beautifully").apply {
            status = if (ready) "● Active" else "● Set up"
            onStatus = { if (!ready) { onboarding = true; onboardStep = if (Setup.isEnabled(this@MainActivity)) 2 else 1; show(Ui.BG, true) { onboardingStep() } } }
        }, Ui.lp(this, MATCH, d(200)))

        val sum = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun info(label: String, value: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(Ui.text(this@MainActivity, label, 12f, Ui.SUB)); addView(Ui.text(this@MainActivity, value, 15f, Ui.NAVY, true).apply { setSingleLine(false) })
        }
        sum.addView(info("Theme", Prefs.theme(this).name), Ui.lp(this, 0, WRAP, weight = 1f))
        sum.addView(info("Layouts", Prefs.langs(this).joinToString(" · ") { langName(it) }), Ui.lp(this, 0, WRAP, weight = 1.6f))
        col.addView(sum, Ui.lp(this, t = 14))

        col.addView(Ui.section(this, "Jump in"), Ui.lp(this, t = 20, b = 8))
        data class Tile(val icon: Icon, val title: String, val sub: String, val target: () -> View)
        val tiles = listOf(
            Tile(Icon.GLOBE, "Layouts", "জাতীয় · অভ্র · more") { languagesScreen() },
            Tile(Icon.BOLT, "Shortcuts", "Type less, say more") { shortcutsScreen() },
            Tile(Icon.CLIPBOARD, "Clipboard", "Recent & pinned") { clipboardScreen() },
            Tile(Icon.CHART, "Insights", "Your top words") { insightsScreen() }
        )
        tiles.chunked(2).forEachIndexed { r, pair ->
            val row = LinearLayout(this)
            pair.forEachIndexed { i, t ->
                val card = Ui.tapCard(this) { push(t.target) }
                card.addView(Ui.badge(this, t.icon, 44, Ui.PALETTE[(r * 2 + i) * 2 % Ui.PALETTE.size]), LinearLayout.LayoutParams(d(44), d(44)))
                card.addView(Ui.text(this, t.title, 17f, Ui.NAVY, true), Ui.lp(this, t = 12))
                card.addView(Ui.text(this, t.sub, 13f, Ui.SUB), Ui.lp(this, t = 2))
                row.addView(card, Ui.lp(this, 0, WRAP, l = if (i == 1) 6 else 0, r = if (i == 0) 6 else 0, weight = 1f))
            }
            col.addView(row, Ui.lp(this, b = 12))
        }
        val tip = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = Ui.gradient(this@MainActivity, 20, intArrayOf(Color.parseColor("#EEF3FF"), Color.parseColor("#F3ECFF"))) }
        tip.addView(Ui.badge(this, Icon.SPARKLE, 40, Ui.PALETTE[2]), LinearLayout.LayoutParams(d(40), d(40)))
        tip.addView(Ui.text(this, "Tip: hold any Bangla key for variants, or swipe the space bar left and right to change language.", 14f, Ui.NAVY), Ui.lp(this, l = 12))
        col.addView(tip, Ui.lp(this, t = 4))
        val tryCard = Ui.card(this)
        tryCard.addView(Ui.text(this, "Try it here", 17f, Ui.NAVY, true))
        tryCard.addView(EditText(this).apply { hint = "Tap and start typing…"; minLines = 3; gravity = Gravity.TOP; setTextColor(Ui.NAVY) }, Ui.lp(this, t = 8))
        col.addView(tryCard, Ui.lp(this, t = 14))
    }

    private fun themesTab(col: LinearLayout) {
        col.addView(Ui.text(this, "Themes", 26f, Ui.NAVY, true))
        col.addView(Ui.text(this, "${KeyboardTheme.ALL.size} themes · ${KeyboardTheme.ALL.count { it.fx != Fx.NONE }} animated", 14f, Ui.SUB), Ui.lp(this, t = 2, b = 14))
        val cur = Prefs.theme(this).id
        fun grid(list: List<KeyboardTheme>) = list.chunked(2).forEach { pair ->
            val row = LinearLayout(this)
            pair.forEachIndexed { i, t ->
                val card = Ui.tapCard(this) { Prefs.setTheme(this, t.id); refresh() }.apply { setPadding(d(10), d(10), d(10), d(10)) }
                card.addView(ThemePreview(this, t), LinearLayout.LayoutParams(MATCH, d(92)))
                val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                line.addView(Ui.text(this, t.name, 13.5f, Ui.NAVY, true), Ui.lp(this, 0, WRAP, weight = 1f))
                if (t.id == cur) line.addView(IconView(this, Icon.CHECK, Ui.GREEN), LinearLayout.LayoutParams(d(20), d(20)))
                card.addView(line, Ui.lp(this, t = 8))
                if (t.id == cur) card.background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = d(20).toFloat(); setStroke(d(2), Ui.BLUE) }
                row.addView(card, Ui.lp(this, 0, WRAP, l = if (i == 1) 5 else 0, r = if (i == 0) 5 else 0, weight = 1f))
            }
            if (pair.size == 1) row.addView(View(this), Ui.lp(this, 0, 1, l = 5, weight = 1f))
            col.addView(row, Ui.lp(this, b = 10))
        }
        col.addView(Ui.section(this, "Classic"), Ui.lp(this, b = 8)); grid(KeyboardTheme.ALL.filter { it.fx == Fx.NONE })
        col.addView(Ui.section(this, "Animated"), Ui.lp(this, t = 10, b = 8)); grid(KeyboardTheme.ALL.filter { it.fx != Fx.NONE })
        col.addView(Ui.text(this, "Applies the next time the keyboard opens. You can also switch from the palette icon above the keys. Turn animations off in Settings to save battery.", 13f, Ui.SUB), Ui.lp(this, t = 6))
    }

    private fun toolsTab(col: LinearLayout) {
        col.addView(Ui.text(this, "Tools", 26f, Ui.NAVY, true)); col.addView(Ui.text(this, "Little helpers for everyday typing", 14f, Ui.SUB), Ui.lp(this, t = 2, b = 14))
        navRow(col, Icon.BOLT, 3, "Text shortcuts", "Type “addr” + space → your full address") { push { shortcutsScreen() } }
        navRow(col, Icon.CLIPBOARD, 4, "Clipboard", "Recent (1 hour) and pinned items") { push { clipboardScreen() } }
        navRow(col, Icon.EDIT, 5, "Banglish & Avro converter", "Try both directions right here") { push { converterScreen() } }
        navRow(col, Icon.CHART, 6, "Typing insights", "Words you use most, stored only on this phone") { push { insightsScreen() } }
        navRow(col, Icon.GLOBE, 0, "Layouts & languages", "জাতীয়, অভ্র, বাংলা, English, Banglish") { push { languagesScreen() } }
    }

    private fun settingsTab(col: LinearLayout) {
        col.addView(Ui.text(this, "Settings", 26f, Ui.NAVY, true))
        col.addView(Ui.section(this, "Typing"), Ui.lp(this, t = 16, b = 8))
        switchRow(col, Icon.SPARKLE, 2, "Word suggestions", "Suggest words above the keys", Prefs.suggestions(this)) { Prefs.setSuggestions(this, it) }
        switchRow(col, Icon.CHART, 6, "Learn my words", "Remember words you type often (on this phone only)", Prefs.learnWords(this)) { Prefs.setLearnWords(this, it) }
        switchRow(col, Icon.THEME, 1, "Emoji suggestions", "Suggest an emoji when a word matches", Prefs.emojiSuggest(this)) { Prefs.setEmojiSuggest(this, it) }
        switchRow(col, Icon.EDIT, 5, "Double-space period", "Two spaces insert “. ” (or “।”)", Prefs.doubleSpace(this)) { Prefs.setDoubleSpace(this, it) }
        switchRow(col, Icon.KEYBOARD, 0, "Number row (English)", "Show digits above the letters", Prefs.numberRow(this)) { Prefs.setNumberRow(this, it) }
        col.addView(Ui.section(this, "Feel"), Ui.lp(this, t = 14, b = 8))
        switchRow(col, Icon.PHONE, 3, "Vibration", "A small buzz on each key", Prefs.haptic(this)) { Prefs.setHaptic(this, it) }
        switchRow(col, Icon.SPEAKER, 7, "Key sound", "Click sound on each key", Prefs.sound(this)) { Prefs.setSound(this, it) }
        sliderRow(col, Icon.SPEAKER, 7, "Sound volume", 100, Prefs.soundVolume(this), { "$it%" }) { Prefs.setSoundVolume(this, it) }
        switchRow(col, Icon.THEME, 1, "Animated themes", "Turn off to save battery", Prefs.animThemes(this)) { Prefs.setAnimThemes(this, it) }
        col.addView(Ui.section(this, "Size & layout"), Ui.lp(this, t = 14, b = 8))
        sliderRow(col, Icon.SLIDERS, 0, "Keyboard height", 50, Prefs.heightPercent(this) - 80, { "${80 + it}%" }) { Prefs.setHeightPercent(this, 80 + it) }
        sliderRow(col, Icon.SLIDERS, 4, "Long-press delay", 12, (Prefs.longPressMs(this) - 300) / 100, { "${300 + it * 100} ms" }) { Prefs.setLongPressMs(this, 300 + it * 100) }
        segmented(col, Icon.PHONE, 5, "One-handed mode", listOf("Off", "Left", "Right"), Prefs.oneHanded(this)) { Prefs.setOneHanded(this, it) }
        col.addView(Ui.section(this, "More"), Ui.lp(this, t = 14, b = 8))
        navRow(col, Icon.GLOBE, 0, "Layouts & languages", "Order and enable layouts") { push { languagesScreen() } }
        navRow(col, Icon.SHIELD, 4, "About & privacy", "What Evolve does with your data") { push { aboutScreen() } }
    }

    // ------------------------------------------------------------------ reusable rows

    private fun rowCard(icon: Icon, idx: Int, title: String, sub: String): Pair<LinearLayout, LinearLayout> {
        val card = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(d(14), d(12), d(14), d(12)) }
        card.addView(Ui.badge(this, icon, 40, Ui.PALETTE[idx % Ui.PALETTE.size]), LinearLayout.LayoutParams(d(40), d(40)))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(Ui.text(this, title, 16f, Ui.NAVY, true)); if (sub.isNotEmpty()) t.addView(Ui.text(this, sub, 13f, Ui.SUB), Ui.lp(this, t = 1))
        card.addView(t, Ui.lp(this, 0, WRAP, l = 12, weight = 1f))
        return card to t
    }

    private fun navRow(col: LinearLayout, icon: Icon, idx: Int, title: String, sub: String, onClick: () -> Unit) {
        val (card, _) = rowCard(icon, idx, title, sub)
        card.background = Ui.ripple(this, Color.WHITE, 20); card.isClickable = true; card.setOnClickListener { onClick() }; Ui.pressable(card)
        card.addView(IconView(this, Icon.CHEVRON, Ui.SUB), LinearLayout.LayoutParams(d(18), d(18)))
        col.addView(card, Ui.lp(this, b = 10))
    }

    private fun switchRow(col: LinearLayout, icon: Icon, idx: Int, title: String, sub: String, v: Boolean, set: (Boolean) -> Unit) {
        val (card, _) = rowCard(icon, idx, title, sub)
        card.addView(Switch(this).apply { isChecked = v; contentDescription = title; setOnCheckedChangeListener { _, c -> set(c) } })
        col.addView(card, Ui.lp(this, b = 10))
    }

    private fun sliderRow(col: LinearLayout, icon: Icon, idx: Int, title: String, max: Int, progress: Int, label: (Int) -> String, save: (Int) -> Unit) {
        val card = Ui.card(this).apply { setPadding(d(14), d(12), d(14), d(8)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.badge(this, icon, 40, Ui.PALETTE[idx % Ui.PALETTE.size]), LinearLayout.LayoutParams(d(40), d(40)))
        head.addView(Ui.text(this, title, 16f, Ui.NAVY, true), Ui.lp(this, 0, WRAP, l = 12, weight = 1f))
        val value = Ui.text(this, label(progress), 14f, Ui.BLUE, true); head.addView(value)
        card.addView(head)
        card.addView(SeekBar(this).apply {
            this.max = max; this.progress = progress; contentDescription = title
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { value.text = label(p); if (fromUser) save(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, Ui.lp(this, t = 6))
        col.addView(card, Ui.lp(this, b = 10))
    }

    private fun segmented(col: LinearLayout, icon: Icon, idx: Int, title: String, options: List<String>, selected: Int, set: (Int) -> Unit) {
        val card = Ui.card(this).apply { setPadding(d(14), d(12), d(14), d(14)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.badge(this, icon, 40, Ui.PALETTE[idx % Ui.PALETTE.size]), LinearLayout.LayoutParams(d(40), d(40)))
        head.addView(Ui.text(this, title, 16f, Ui.NAVY, true), Ui.lp(this, l = 12)); card.addView(head)
        val row = LinearLayout(this).apply { background = Ui.rounded(this@MainActivity, Color.parseColor("#EEF1FB"), 14); setPadding(d(3), d(3), d(3), d(3)) }
        var sel = selected
        val items = ArrayList<android.widget.TextView>()
        fun paint() = items.forEachIndexed { i, tv -> tv.background = if (i == sel) Ui.rounded(this, Color.WHITE, 12) else null; tv.setTextColor(if (i == sel) Ui.BLUE else Ui.SUB) }
        options.forEachIndexed { i, o ->
            val tv = Ui.text(this, o, 14f, Ui.SUB, true).apply { gravity = Gravity.CENTER; minHeight = d(38); setOnClickListener { sel = i; set(i); paint() } }
            items.add(tv); row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paint(); card.addView(row, Ui.lp(this, t = 10)); col.addView(card, Ui.lp(this, b = 10))
    }

    // ------------------------------------------------------------------ detail screens

    private fun scaffold(title: String, fill: (LinearLayout) -> Unit): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(d(12), d(8), d(20), d(8)) }
        bar.addView(IconView(this, Icon.BACK, Ui.NAVY).apply { setOnClickListener { onBackPressed() }; contentDescription = "Back" }, LinearLayout.LayoutParams(d(30), d(30)).apply { setMargins(d(10), 0, d(8), 0) })
        bar.addView(Ui.text(this, title, 22f, Ui.NAVY, true))
        page.addView(bar)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(4), d(20), d(28)) }
        fill(col)
        page.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return page
    }

    private fun languagesScreen(): View = scaffold("Layouts & languages") { col ->
        val enabled = Prefs.langs(this)
        val info = mapOf(
            "JATIYA" to ("জাতীয়" to "National layout: Bangla keys in the familiar QWERTY positions, hold a key for variants"),
            "AVRO" to ("অভ্র" to "Phonetic: type Roman letters, get Bangla (ami → আমি). Capital letters matter, like Avro. Adds a number row"),
            "CLASSIC" to ("বাংলা (পেজ)" to "Evolve classic: three alphabetical pages, hold the arrow for every character"),
            "EN" to ("English" to "QWERTY with numbers and symbols on long-press"),
            "BANGLISH" to ("Banglish" to "Type Bangla on the Jatiya keys, get Roman letters: আমি → Ami")
        )
        col.addView(Ui.text(this, "Swipe the space bar right or left to move through these, in this order.", 14f, Ui.SUB), Ui.lp(this, b = 12))
        Prefs.allLangsOrdered(this).forEachIndexed { n, key ->
            val on = key in enabled
            val (card, _) = rowCard(Icon.GLOBE, n, info[key]!!.first, info[key]!!.second)
            if (on && enabled.size > 1) {
                val i = enabled.indexOf(key)
                fun mv(label: String, delta: Int, ok: Boolean) = Ui.textButton(this, label) {
                    if (ok) { val l = enabled.toMutableList(); l.removeAt(i); l.add(i + delta, key); Prefs.setLangs(this, l); refresh() }
                }.apply { alpha = if (ok) 1f else 0.3f; minWidth = d(36) }
                card.addView(mv("▲", -1, i > 0)); card.addView(mv("▼", 1, i < enabled.lastIndex))
            }
            card.addView(Switch(this).apply {
                isChecked = on; contentDescription = info[key]!!.first
                setOnCheckedChangeListener { _, v ->
                    val l = enabled.toMutableList()
                    if (v && key !in l) l.add(key) else if (!v) l.remove(key)
                    if (l.isEmpty()) isChecked = true else { Prefs.setLangs(this@MainActivity, l); refresh() }
                }
            })
            col.addView(card, Ui.lp(this, b = 10))
        }
        val note = Ui.card(this)
        note.addView(Ui.text(this, "Language data", 16f, Ui.NAVY, true))
        note.addView(Ui.text(this, "Everything is built in and works offline — nothing to download. The word list is small for now and grows with updates; the words you use most are learned on your phone.", 14f, Ui.SUB), Ui.lp(this, t = 4))
        col.addView(note, Ui.lp(this, t = 6))
    }

    private fun shortcutsScreen(): View = scaffold("Text shortcuts") { col ->
        val store = ShortcutStore(PrefsKeyValueStore(this, "evolve_shortcuts"))
        col.addView(Ui.text(this, "Type the short word, press space, and it expands. Good for addresses, emails and phrases you repeat.", 14f, Ui.SUB), Ui.lp(this, b = 12))
        val list = store.all()
        if (list.isEmpty()) {
            val c = Ui.card(this); c.gravity = Gravity.CENTER_HORIZONTAL
            c.addView(Ui.badge(this, Icon.BOLT, 56, Ui.PALETTE[3]), LinearLayout.LayoutParams(d(56), d(56)))
            c.addView(Ui.text(this, "No shortcuts yet", 16f, Ui.NAVY, true), Ui.lp(this, t = 10))
            c.addView(Ui.text(this, "Example: “tnx” → “Thank you so much!”", 14f, Ui.SUB), Ui.lp(this, t = 2))
            col.addView(c, Ui.lp(this, b = 12))
        }
        list.forEachIndexed { i, (k, v) ->
            val (card, _) = rowCard(Icon.BOLT, 3 + i, k, v)
            card.addView(IconView(this, Icon.TRASH, Ui.SUB).apply { contentDescription = "Delete"; setOnClickListener { store.remove(k); refresh() } }, LinearLayout.LayoutParams(d(24), d(24)))
            col.addView(card, Ui.lp(this, b = 10))
        }
        col.addView(Ui.primaryButton(this, "Add shortcut") {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(8), d(20), 0) }
            val a = EditText(this).apply { hint = "Short word, e.g. addr"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS }
            val b = EditText(this).apply { hint = "Expands to…"; minLines = 2 }
            box.addView(a); box.addView(b)
            AlertDialog.Builder(this).setTitle("New shortcut").setView(box)
                .setPositiveButton("Save") { _, _ -> store.put(a.text.toString().trim(), b.text.toString()); refresh() }.setNegativeButton("Cancel", null).show()
        }, Ui.lp(this, t = 8))
    }

    private fun clipboardScreen(): View = scaffold("Clipboard") { col ->
        val repo = ClipboardRepository(PrefsKeyValueStore(this))
        val c = Ui.card(this)
        c.addView(Ui.text(this, "How it works", 17f, Ui.NAVY, true))
        c.addView(Ui.text(this, "Open the clipboard icon above the keys. Recent items disappear after one hour. Pin the ones you need — pinned items stay until you remove them.", 14f, Ui.SUB), Ui.lp(this, t = 4))
        c.addView(Ui.text(this, "${repo.recent().size} recent  ·  ${repo.pinned().size} pinned", 15f, Ui.BLUE, true), Ui.lp(this, t = 12))
        col.addView(c, Ui.lp(this, b = 10))
        val p = Ui.card(this)
        p.addView(Ui.text(this, "Privacy", 17f, Ui.NAVY, true))
        p.addView(Ui.text(this, "Only text copied while Evolve is on screen is saved, only on this device, and never from password fields. Android blocks background clipboard reading, so copies made while another keyboard is active are not captured.", 14f, Ui.SUB), Ui.lp(this, t = 4))
        col.addView(p, Ui.lp(this, b = 16))
        col.addView(Ui.primaryButton(this, "Clear all clipboard data") {
            AlertDialog.Builder(this).setTitle("Clear clipboard data?").setMessage("This removes recent and pinned items.")
                .setPositiveButton("Clear") { _, _ -> repo.clearAll(); refresh() }.setNegativeButton("Cancel", null).show()
        })
    }

    private fun converterScreen(): View = scaffold("Converter") { col ->
        fun converter(title: String, hint: String, convert: (String) -> String) {
            val card = Ui.card(this)
            card.addView(Ui.text(this, title, 17f, Ui.NAVY, true))
            val out = Ui.text(this, "", 20f, Ui.BLUE, true)
            card.addView(EditText(this).apply {
                this.hint = hint; setTextColor(Ui.NAVY)
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) { out.text = convert(s?.toString().orEmpty()) }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
            }, Ui.lp(this, t = 6))
            card.addView(out, Ui.lp(this, t = 8)); col.addView(card, Ui.lp(this, b = 12))
        }
        converter("Bangla → Banglish", "Type Bangla, e.g. আমার নাম") { engine.toBanglishText(it) }
        converter("অভ্র (Avro) → বাংলা", "Try: ami tOmake bhalObasi") { AvroEngine.convert(it) }
        converter("Smart Banglish → বাংলা", "Try: tumi kemon acho") { engine.toBanglaText(it) }
        col.addView(Ui.text(this, "Avro is case-sensitive: o is the silent vowel, O makes ো, T/D/N are retroflex. Roman spelling isn't standardised, so tap suggestions above the keys for other spellings.", 14f, Ui.SUB))
    }

    private fun insightsScreen(): View = scaffold("Typing insights") { col ->
        val uw = UserWords(PrefsKeyValueStore(this, "evolve_words"))
        val top = uw.top(15)
        val head = Ui.card(this)
        head.addView(Ui.text(this, "${uw.size()} words remembered", 20f, Ui.NAVY, true))
        head.addView(Ui.text(this, "Kept only on this phone, capped at ${UserWords.MAX} words. One-off words are forgotten after 30 days; passwords, emails and web addresses are never learned.", 14f, Ui.SUB), Ui.lp(this, t = 4))
        col.addView(head, Ui.lp(this, b = 12))
        if (top.isEmpty()) col.addView(Ui.text(this, "Start typing and your favourite words will show up here.", 15f, Ui.SUB), Ui.lp(this, b = 12))
        val max = (top.firstOrNull()?.second ?: 1).coerceAtLeast(1)
        top.forEachIndexed { i, (w, n) ->
            val card = Ui.card(this).apply { setPadding(d(14), d(10), d(14), d(10)) }
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            line.addView(Ui.text(this, w, 16f, Ui.NAVY, true), Ui.lp(this, 0, WRAP, weight = 1f)); line.addView(Ui.text(this, "×$n", 14f, Ui.BLUE, true))
            card.addView(line)
            card.addView(android.view.View(this).apply { background = Ui.gradient(this@MainActivity, 3, intArrayOf(Ui.PALETTE[i % 8][0], Ui.PALETTE[i % 8][1])) }, Ui.lp(this, (resources.displayMetrics.widthPixels * 0.7f * n / max).toInt().coerceAtLeast(d(8)), d(5), t = 6))
            col.addView(card, Ui.lp(this, b = 8))
        }
        col.addView(Ui.primaryButton(this, "Clear learned words") {
            AlertDialog.Builder(this).setTitle("Forget all learned words?").setPositiveButton("Forget") { _, _ -> uw.clear(); refresh() }.setNegativeButton("Cancel", null).show()
        }, Ui.lp(this, t = 8))
    }

    private fun aboutScreen(): View = scaffold("About & privacy") { col ->
        col.addView(ImageView(this).apply { setImageResource(R.drawable.evolve_wordmark); adjustViewBounds = true }, Ui.lp(this, b = 4))
        col.addView(Ui.text(this, "Version 0.2.0", 13f, Ui.SUB).apply { gravity = Gravity.CENTER }, Ui.lp(this, b = 16))
        fun block(icon: Icon, idx: Int, title: String, body: String) {
            val (card, t) = rowCard(icon, idx, title, "")
            t.addView(Ui.text(this, body, 14f, Ui.SUB), Ui.lp(this, t = 2)); col.addView(card, Ui.lp(this, b = 10))
        }
        block(Icon.SHIELD, 4, "Your typing stays on your phone", "No internet permission, no analytics, no keystroke logging. Conversion, suggestions and clipboard history run locally.")
        block(Icon.CHART, 6, "Learned words", "Only if “Learn my words” is on. Capped, expiring, never from password, email or URL fields. Clear anytime in Tools → Typing insights.")
        block(Icon.MIC, 1, "Permissions", "Microphone — optional, only for voice typing. Nothing else is requested.")
        block(Icon.SPEAKER, 7, "Voice typing", "Uses Android's speech recognition; depending on your phone, audio may be processed online by that service.")
        block(Icon.INFO, 2, "Assets", "Icons are drawn in code; the logo and wordmark were supplied by the project owner. Flag names come from Unicode CLDR via Babel.")
    }
}
