package com.evolve.keyboard.settings

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import com.evolve.keyboard.R
import com.evolve.keyboard.banglish.AvroEngine
import com.evolve.keyboard.banglish.BanglishEngine
import com.evolve.keyboard.clipboard.ClipboardRepository
import com.evolve.keyboard.clipboard.PrefsKeyValueStore
import com.evolve.keyboard.i18n.Tr
import com.evolve.keyboard.keyboard.Fx
import com.evolve.keyboard.keyboard.KeyboardTheme
import com.evolve.keyboard.settings.Ui.MATCH
import com.evolve.keyboard.settings.Ui.WRAP
import com.evolve.keyboard.suggest.FontStyles
import com.evolve.keyboard.suggest.ShortcutStore
import com.evolve.keyboard.suggest.UserWords
import com.evolve.keyboard.ui.Icon
import com.evolve.keyboard.ui.IconView

object Setup {
    fun isEnabled(c: Context) = (c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        .enabledInputMethodList.any { it.packageName == c.packageName }
    fun isSelected(c: Context) = Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        ?.startsWith(c.packageName + "/") == true
    fun micGranted(c: Context) = c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
}

/** One activity, many screens: splash -> first-run setup -> main tabs (Home, Themes, Settings) -> detail screens. */
class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private var current: (() -> View)? = null
    private val stack = ArrayList<() -> View>()
    private var onboardStep = 0
    private var onboarding = false
    private var micOnly = false
    private var tab = 0
    private var privacyShown = false
    private val engine = BanglishEngine()
    private val ui = Handler(Looper.getMainLooper())
    private fun d(v: Int) = Ui.dp(this, v)
    private fun tr(s: String) = Tr.t(s)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.applyMode(Prefs.appTheme(this)); Tr.setLang(Prefs.appLang(this) ?: "en")
        root = FrameLayout(this); setContentView(root)
        micOnly = intent.getBooleanExtra("mic", false)
        if (micOnly) { onboarding = true; show(Ui.BG, Ui.light) { micStep() } } else showSplash()
    }

    override fun onResume() { super.onResume(); if (onboarding && onboardStep in 2..3) current?.let { show(Ui.BG, Ui.light, false, it) } }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus && onboarding && onboardStep in 2..3 && current != null) show(Ui.BG, Ui.light, false, current!!) }

    override fun onBackPressed() {
        when {
            stack.isNotEmpty() -> show(Ui.BG, Ui.light, true, stack.removeAt(stack.lastIndex))
            onboarding && onboardStep > 0 && !micOnly -> go(onboardStep - 1)
            else -> super.onBackPressed()
        }
    }

    private fun show(bar: Int, lightBars: Boolean, animate: Boolean = true, builder: () -> View) {
        current = builder
        window.statusBarColor = bar; window.navigationBarColor = bar
        window.decorView.systemUiVisibility = if (lightBars) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
        root.layoutDirection = if (Tr.rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        val v = builder()
        root.removeAllViews(); root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        if (animate) { v.alpha = 0f; v.translationY = d(14).toFloat(); v.animate().alpha(1f).translationY(0f).setDuration(220).start() }
    }
    private fun push(builder: () -> View) { current?.let { stack.add(it) }; show(Ui.BG, Ui.light, true, builder) }
    private fun refresh() { current?.let { show(Ui.BG, Ui.light, false, it) } }
    private fun go(step: Int) { onboardStep = step; show(Ui.BG, Ui.light) { onboardingStep() } }

    // ------------------------------------------------------------------ splash (English only: the app is international)

    private fun showSplash() {
        show(Ui.BRAND[1], false) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, Ui.BRAND)
            }
            val logo = ImageView(this).apply { setImageResource(R.drawable.evolve_icon); alpha = 0f; scaleX = 0.7f; scaleY = 0.7f }
            col.addView(logo, LinearLayout.LayoutParams(d(124), d(124)))
            val name = Ui.text(this, "Evolve Keyboard", 28f, Color.WHITE, true).apply { alpha = 0f }
            col.addView(name, Ui.lp(this, WRAP, WRAP, t = 24))
            val tag = Ui.text(this, "Type in any language", 15f, Color.argb(210, 255, 255, 255)).apply { alpha = 0f }
            col.addView(tag, Ui.lp(this, WRAP, WRAP, t = 6))
            logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()
            name.animate().alpha(1f).setStartDelay(250).setDuration(500).start()
            tag.animate().alpha(1f).setStartDelay(450).setDuration(500).start()
            ui.postDelayed({ if (!isFinishing) route() }, 1400)
            col
        }
    }

    private fun route() { if (Prefs.onboarded(this)) showMain() else { onboarding = true; go(0) } }
    private fun showMain(t: Int = 0) { onboarding = false; stack.clear(); tab = t; show(Ui.BG, Ui.light) { mainScreen() } }

    // ------------------------------------------------------------------ first-run setup

    private fun chooseLanguage(code: String) {
        Prefs.setAppLang(this, code); Tr.setLang(code); refresh()
    }

    private fun onboardingStep(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(22), d(18), d(22), d(22)); setBackgroundColor(Ui.BG) }
        val dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        for (i in 0 until 6) dots.addView(View(this).apply {
            background = Ui.rounded(this@MainActivity, if (i <= onboardStep) Ui.BLUE else Ui.LINE, 4)
        }, Ui.lp(this, d(if (i == onboardStep) 26 else 8), d(8), l = 4, r = 4))
        page.addView(dots, Ui.lp(this, MATCH, WRAP, b = 10))

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val foot = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun title(s: String) = body.addView(Ui.text(this, s, 25f, Ui.NAVY, true).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 18))
        fun para(s: String) = body.addView(Ui.text(this, s, 15f, Ui.SUB).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 8))
        fun status(ok: Boolean, yes: String, no: String) = body.addView(Ui.chip(this, if (ok) "✓  ${tr(yes)}" else no, if (ok) Ui.GREEN else Ui.ORANGE), Ui.lp(this, WRAP, WRAP, t = 12))
        fun steps(vararg lines: String) {
            val card = Ui.card(this)
            lines.forEachIndexed { i, s ->
                val row = LinearLayout(this).apply { gravity = Gravity.TOP }
                row.addView(Ui.text(this, "${i + 1}", 13f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = Ui.gradient(this@MainActivity, 11, intArrayOf(Ui.BLUE, Ui.VIOLET)) }, LinearLayout.LayoutParams(d(22), d(22)))
                row.addView(Ui.text(this, s, 14f, Ui.NAVY), Ui.lp(this, MATCH, WRAP, l = 10))
                card.addView(row, Ui.lp(this, t = if (i == 0) 0 else 10))
            }
            body.addView(card, Ui.lp(this, t = 12))
        }

        when (onboardStep) {
            0 -> {                                                                // pick the app language
                body.addView(Ui.badge(this, Icon.GLOBE, 72, Ui.PALETTE[0]), LinearLayout.LayoutParams(d(72), d(72)))
                title("Choose your language")
                val list = Ui.card(this).apply { setPadding(d(6), d(6), d(6), d(6)) }
                Tr.LANGS.forEach { l ->
                    val on = Tr.code == l.code && Prefs.appLang(this) != null
                    val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(d(12), d(11), d(12), d(11)); isClickable = true
                        background = if (on) Ui.rounded(this@MainActivity, Color.argb(36, 31, 107, 255), 14) else null; setOnClickListener { chooseLanguage(l.code) } }
                    row.addView(Ui.text(this, l.flag, 22f), LinearLayout.LayoutParams(d(36), WRAP))
                    row.addView(Ui.text(this, l.native, 16f, Ui.NAVY, on), Ui.lp(this, 0, WRAP, weight = 1f))
                    if (on) row.addView(IconView(this, Icon.CHECK, Ui.BLUE), LinearLayout.LayoutParams(d(20), d(20)))
                    list.addView(row)
                }
                body.addView(list, Ui.lp(this, t = 14))
                foot.addView(Ui.primaryButton(this, "Next") { if (Prefs.appLang(this) == null) Prefs.setAppLang(this, "en"); go(1) })
            }
            1 -> {
                body.addView(HeroView(this, "Evolve Keyboard", "Type your way, beautifully"), Ui.lp(this, MATCH, d(190)))
                val feats = Ui.card(this)
                listOf(Icon.GLOBE to "Switch languages with a swipe on the space bar", Icon.SPARKLE to "Smart suggestions that learn the words you use",
                    Icon.LOCK to "Private by design: nothing is collected").forEachIndexed { i, (ic, s) ->
                    val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                    row.addView(Ui.badge(this, ic, 38, Ui.PALETTE[i * 2]), LinearLayout.LayoutParams(d(38), d(38)))
                    row.addView(Ui.text(this, s, 14.5f), Ui.lp(this, MATCH, WRAP, l = 12))
                    feats.addView(row, Ui.lp(this, t = if (i == 0) 0 else 12))
                }
                body.addView(feats, Ui.lp(this, t = 16))
                body.addView(Ui.textButton(this, "Your privacy") { showPrivacyDialog() }, Ui.lp(this, t = 4))
                if (!privacyShown) { privacyShown = true; ui.postDelayed({ if (!isFinishing && onboardStep == 1) showPrivacyDialog() }, 350) }
                foot.addView(Ui.primaryButton(this, "Get started") { go(2) })
            }
            2 -> {
                val on = Setup.isEnabled(this)
                title("Turn on Evolve Keyboard")
                body.addView(GuideView(this, 0), Ui.lp(this, MATCH, d(210), t = 14))
                status(on, "Enabled", tr("Not enabled yet"))
                steps("Tap the button below to open Android's keyboard list.", "Find “Evolve Keyboard” and switch it ON (follow the arrow).",
                    "Android shows a standard warning for every keyboard. Tap OK — Evolve collects nothing and cannot send what you type anywhere.",
                    "Come back here. This screen updates by itself.")
                foot.addView(Ui.primaryButton(this, if (on) "Next" else "Open keyboard settings") { if (on) go(3) else startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
            }
            3 -> {
                val sel = Setup.isSelected(this)
                title("Make it your keyboard")
                body.addView(GuideView(this, 1), Ui.lp(this, MATCH, d(210), t = 14))
                status(sel, "Selected", tr("Not selected yet"))
                steps("Tap “Choose keyboard” below.", "In the list that appears, pick “Evolve Keyboard” (follow the arrow).", "Done! This screen updates by itself.")
                foot.addView(Ui.primaryButton(this, if (sel) "Next" else "Choose keyboard") {
                    if (sel) go(4) else (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                })
            }
            4 -> return micStep()
            else -> {
                body.addView(Ui.badge(this, Icon.CHECK, 96, Ui.PALETTE[5]), LinearLayout.LayoutParams(d(96), d(96)))
                title("You're all set")
                para("Open any text box. Swipe the space bar to change language, and tap the icons above the keys for clipboard, emoji, translate, fonts and more.")
                foot.addView(Ui.primaryButton(this, "Open Evolve") { Prefs.setOnboarded(this, true); showMain() })
            }
        }
        page.addView(ScrollView(this).apply { isFillViewport = true; addView(body) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        page.addView(foot, Ui.lp(this, t = 14))
        return page
    }

    private fun micStep(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(22), d(18), d(22), d(22)); setBackgroundColor(Ui.BG) }
        val ok = Setup.micGranted(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        body.addView(Ui.badge(this, Icon.MIC, 96, Ui.PALETTE[1]), LinearLayout.LayoutParams(d(96), d(96)))
        body.addView(Ui.text(this, "Voice typing (optional)", 25f, Ui.NAVY, true).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 18))
        body.addView(Ui.text(this, "Allow the microphone only if you want to dictate. It is used only after you tap the mic key. Speech is handled by your phone's speech service, which may use the internet. This is the only permission Evolve asks for.", 15f, Ui.SUB).apply { gravity = Gravity.CENTER }, Ui.lp(this, t = 8))
        body.addView(Ui.chip(this, if (ok) "✓  Microphone allowed" else "Not allowed", if (ok) Ui.GREEN else Ui.ORANGE), Ui.lp(this, WRAP, WRAP, t = 14))
        page.addView(ScrollView(this).apply { isFillViewport = true; addView(body) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val next = { if (micOnly) finish() else go(5) }
        page.addView(Ui.primaryButton(this, if (ok) "Next" else "Allow microphone") {
            if (ok) next() else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }, Ui.lp(this, t = 14))
        if (!ok) page.addView(Ui.textButton(this, "Skip for now") { next() }, Ui.lp(this, t = 4))
        return page
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res); current?.let { show(Ui.BG, Ui.light, false, it) }
    }

    private fun showPrivacyDialog() {
        val dlg = Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(d(22), d(24), d(22), d(18)); background = Ui.rounded(this@MainActivity, Ui.CARD, 28) }
        card.addView(Ui.badge(this, Icon.LOCK, 64, Ui.PALETTE[4]), LinearLayout.LayoutParams(d(64), d(64)))
        card.addView(Ui.text(this, "Your privacy", 22f, Ui.NAVY, true), Ui.lp(this, WRAP, WRAP, t = 14))
        listOf("Nothing is collected", "Works offline", "Typing stays on your phone").forEach { s ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(IconView(this, Icon.CHECK, Ui.GREEN), LinearLayout.LayoutParams(d(20), d(20)))
            row.addView(Ui.text(this, s, 15.5f, Ui.NAVY, true), Ui.lp(this, MATCH, WRAP, l = 10))
            card.addView(row, Ui.lp(this, MATCH, WRAP, t = 12))
        }
        card.addView(Ui.text(this, "Evolve does not collect, store or send what you type. Typing, suggestions, converters and clipboard all run on your phone. Translation downloads a language pack once; your text is translated on the phone and never uploaded by Evolve.", 13.5f, Ui.SUB), Ui.lp(this, t = 14))
        card.addView(Ui.primaryButton(this, "Got it") { dlg.dismiss() }, Ui.lp(this, t = 16))
        dlg.setContentView(card); dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), WRAP); dlg.show()
    }

    // ------------------------------------------------------------------ main tabs

    private fun mainScreen(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(18), d(14), d(18), d(22)) }
        when (tab) { 0 -> homeTab(col); 1 -> themesTab(col); else -> settingsTab(col) }
        page.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val nav = LinearLayout(this).apply { setBackgroundColor(Ui.CARD); elevation = d(8).toFloat(); setPadding(0, d(6), 0, d(6)) }
        listOf(Icon.HOME to "Home", Icon.THEME to "Themes", Icon.SETTINGS to "Settings").forEachIndexed { i, (ic, label) ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true; contentDescription = tr(label)
                setOnClickListener { if (tab != i) { tab = i; show(Ui.BG, Ui.light) { mainScreen() } } }; Ui.pressable(this) }
            val on = i == tab
            item.addView(FrameLayout(this).apply {
                background = if (on) Ui.rounded(this@MainActivity, Color.argb(40, 31, 107, 255), 16) else null
                addView(IconView(this@MainActivity, ic, if (on) Ui.BLUE else Ui.SUB), FrameLayout.LayoutParams(d(24), d(24)).apply { gravity = Gravity.CENTER })
            }, LinearLayout.LayoutParams(d(64), d(32)))
            item.addView(Ui.text(this, label, 11.5f, if (on) Ui.BLUE else Ui.SUB, on), Ui.lp(this, WRAP, WRAP, t = 2))
            nav.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        page.addView(nav)
        return page
    }

    private fun langName(n: String) = when (n) { "JATIYA" -> "Jatiya"; "AVRO" -> "Avro"; "CLASSIC" -> "Classic"; "EN" -> "English"; else -> "Banglish" }

    private fun homeTab(col: LinearLayout) {
        val ready = Setup.isEnabled(this) && Setup.isSelected(this)
        col.addView(HeroView(this, "Evolve Keyboard", "Type your way, beautifully").apply {
            status = "● " + tr(if (ready) "Active" else "Set up")
            onStatus = { if (!ready) { onboarding = true; go(if (Setup.isEnabled(this@MainActivity)) 3 else 2) } }
        }, Ui.lp(this, MATCH, d(190)))

        // two feature cards (filled gradient, different from the plain tiles below)
        val big = LinearLayout(this)
        listOf(Triple(Icon.GLOBE, "Layouts & languages", 0), Triple(Icon.THEME, "Themes", 1)).forEachIndexed { i, (ic, label, idx) ->
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(16), d(16), d(16)); isClickable = true
                background = Ui.gradient(this@MainActivity, 22, Ui.PALETTE[idx]); elevation = d(3).toFloat(); Ui.pressable(this)
                setOnClickListener { if (i == 0) push { languagesScreen() } else { tab = 1; show(Ui.BG, Ui.light) { mainScreen() } } } }
            c.addView(IconView(this, ic, Color.WHITE), LinearLayout.LayoutParams(d(30), d(30)))
            c.addView(Ui.text(this, label, 16f, Color.WHITE, true), Ui.lp(this, t = 26))
            c.addView(Ui.text(this, if (i == 0) Prefs.langs(this).joinToString(" · ") { langName(it) } else Prefs.theme(this).name, 12.5f, Color.argb(220, 255, 255, 255)), Ui.lp(this, t = 2))
            big.addView(c, Ui.lp(this, 0, WRAP, l = if (i == 1) 6 else 0, r = if (i == 0) 6 else 0, weight = 1f))
        }
        col.addView(big, Ui.lp(this, t = 14))

        col.addView(Ui.section(this, "Typing tools"), Ui.lp(this, t = 20, b = 8))
        data class Tile(val icon: Icon, val title: String, val target: () -> View)
        val tiles = listOf(
            Tile(Icon.BOLT, "Text shortcuts") { shortcutsScreen() }, Tile(Icon.CLIPBOARD, "Clipboard") { clipboardScreen() },
            Tile(Icon.FONT, "Fonts & styles") { fontsScreen() }, Tile(Icon.TRANSLATE, "Translate") { translateScreen() },
            Tile(Icon.EDIT, "Converter") { converterScreen() }, Tile(Icon.CHART, "Typing insights") { insightsScreen() }
        )
        tiles.chunked(3).forEachIndexed { r, row3 ->
            val row = LinearLayout(this)
            row3.forEachIndexed { i, t ->
                val card = Ui.tapCard(this) { push(t.target) }.apply { gravity = Gravity.CENTER_HORIZONTAL; setPadding(d(6), d(14), d(6), d(12)) }
                card.addView(Ui.badge(this, t.icon, 46, Ui.PALETTE[(r * 3 + i + 2) % Ui.PALETTE.size]), LinearLayout.LayoutParams(d(46), d(46)))
                card.addView(Ui.text(this, t.title, 12.5f, Ui.NAVY, true).apply { gravity = Gravity.CENTER; minLines = 2; maxLines = 2 }, Ui.lp(this, t = 8))
                row.addView(card, Ui.lp(this, 0, WRAP, l = if (i > 0) 5 else 0, r = if (i < 2) 5 else 0, weight = 1f))
            }
            col.addView(row, Ui.lp(this, b = 10))
        }
        col.addView(Ui.section(this, "Privacy & security"), Ui.lp(this, t = 14, b = 8))
        navRow(col, Icon.LOCK, 4, "Privacy & security", "Offline, nothing collected, you stay in control") { push { securityScreen() } }
        navRow(col, Icon.INFO, 7, "About", "Version, permissions, credits") { push { aboutScreen() } }
    }

    private fun themesTab(col: LinearLayout) {
        col.addView(Ui.text(this, "Themes", 26f, Ui.NAVY, true))
        col.addView(Ui.text(this, "${KeyboardTheme.ALL.size} · ${KeyboardTheme.ALL.count { it.fx != Fx.NONE }} animated", 14f, Ui.SUB), Ui.lp(this, t = 2, b = 14))
        val cur = Prefs.theme(this).id
        fun grid(list: List<KeyboardTheme>) = list.chunked(2).forEach { pair ->
            val row = LinearLayout(this)
            pair.forEachIndexed { i, t ->
                val card = Ui.tapCard(this) { Prefs.setTheme(this, t.id); refresh() }.apply { setPadding(d(10), d(10), d(10), d(10)) }
                card.addView(ThemePreview(this, t), LinearLayout.LayoutParams(MATCH, d(92)))
                val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                line.addView(Ui.text(this, t.name, 13.5f, Ui.NAVY, true), Ui.lp(this, 0, WRAP, weight = 1f))
                if (t.id == cur) line.addView(IconView(this, Icon.CHECK, Ui.GREEN), LinearLayout.LayoutParams(d(20), d(20)))
                card.addView(line, Ui.lp(this, t = 8))
                if (t.id == cur) card.background = GradientDrawable().apply { setColor(Ui.CARD); cornerRadius = d(20).toFloat(); setStroke(d(2), Ui.BLUE) }
                row.addView(card, Ui.lp(this, 0, WRAP, l = if (i == 1) 5 else 0, r = if (i == 0) 5 else 0, weight = 1f))
            }
            if (pair.size == 1) row.addView(View(this), Ui.lp(this, 0, 1, l = 5, weight = 1f))
            col.addView(row, Ui.lp(this, b = 10))
        }
        col.addView(Ui.section(this, "Classic"), Ui.lp(this, b = 8)); grid(KeyboardTheme.ALL.filter { it.fx == Fx.NONE })
        col.addView(Ui.section(this, "Animated"), Ui.lp(this, t = 10, b = 8)); grid(KeyboardTheme.ALL.filter { it.fx != Fx.NONE })
    }

    private fun settingsTab(col: LinearLayout) {
        col.addView(Ui.text(this, "Settings", 26f, Ui.NAVY, true))
        col.addView(Ui.section(this, "Appearance"), Ui.lp(this, t = 16, b = 8))
        navRow(col, Icon.GLOBE, 0, "App language", Tr.LANGS.first { it.code == Tr.code }.native) { pickAppLanguage() }
        segmented(col, Icon.THEME, 1, "App theme", listOf("Light", "Dark", "Blue"), Prefs.appTheme(this)) { Prefs.setAppTheme(this, it); Ui.applyMode(it); refresh() }
        switchRow(col, Icon.THEME, 5, "Animated themes", "Turn off to save battery", Prefs.animThemes(this)) { Prefs.setAnimThemes(this, it) }
        col.addView(Ui.section(this, "Typing"), Ui.lp(this, t = 14, b = 8))
        navRow(col, Icon.KEYBOARD, 2, "Layouts & languages", "Jatiya, Avro, Classic, English, Banglish") { push { languagesScreen() } }
        switchRow(col, Icon.SPARKLE, 2, "Word suggestions", "Suggest words above the keys", Prefs.suggestions(this)) { Prefs.setSuggestions(this, it) }
        switchRow(col, Icon.CHART, 6, "Learn my words", "Remembered on this phone only", Prefs.learnWords(this)) { Prefs.setLearnWords(this, it) }
        switchRow(col, Icon.EMOJI, 1, "Emoji suggestions", "Suggest an emoji when a word matches", Prefs.emojiSuggest(this)) { Prefs.setEmojiSuggest(this, it) }
        switchRow(col, Icon.EDIT, 5, "Double-space period", "Two spaces insert “. ”", Prefs.doubleSpace(this)) { Prefs.setDoubleSpace(this, it) }
        switchRow(col, Icon.KEYBOARD, 0, "Number row", "Digits above the English letters", Prefs.numberRow(this)) { Prefs.setNumberRow(this, it) }
        col.addView(Ui.section(this, "Sound & vibration"), Ui.lp(this, t = 14, b = 8))
        switchRow(col, Icon.PHONE, 3, "Vibration", "A small buzz on each key", Prefs.haptic(this)) { Prefs.setHaptic(this, it) }
        switchRow(col, Icon.SPEAKER, 7, "Key sound", "Click sound on each key", Prefs.sound(this)) { Prefs.setSound(this, it) }
        sliderRow(col, Icon.SPEAKER, 7, "Sound volume", 100, Prefs.soundVolume(this), { "$it%" }) { Prefs.setSoundVolume(this, it) }
        col.addView(Ui.section(this, "Size & layout"), Ui.lp(this, t = 14, b = 8))
        sliderRow(col, Icon.SLIDERS, 0, "Keyboard height", 50, Prefs.heightPercent(this) - 80, { "${80 + it}%" }) { Prefs.setHeightPercent(this, 80 + it) }
        sliderRow(col, Icon.SLIDERS, 4, "Long-press delay", 12, (Prefs.longPressMs(this) - 300) / 100, { "${300 + it * 100} ms" }) { Prefs.setLongPressMs(this, 300 + it * 100) }
        segmented(col, Icon.PHONE, 5, "One-handed mode", listOf("Off", "Left", "Right"), Prefs.oneHanded(this)) { Prefs.setOneHanded(this, it) }
        col.addView(Ui.section(this, "Privacy & security"), Ui.lp(this, t = 14, b = 8))
        navRow(col, Icon.LOCK, 4, "Privacy & security", "What Evolve does with your data") { push { securityScreen() } }
        navRow(col, Icon.INFO, 7, "About", "Version, permissions, credits") { push { aboutScreen() } }
    }

    private fun pickAppLanguage() {
        AlertDialog.Builder(this).setTitle(tr("App language"))
            .setItems(Tr.LANGS.map { "${it.flag}  ${it.native}" }.toTypedArray()) { _, i -> chooseLanguage(Tr.LANGS[i].code) }.show()
    }

    // ------------------------------------------------------------------ reusable rows

    private fun rowCard(icon: Icon, idx: Int, title: String, sub: String): Pair<LinearLayout, LinearLayout> {
        val card = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(d(14), d(12), d(14), d(12)) }
        card.addView(Ui.badge(this, icon, 40, Ui.PALETTE[idx % Ui.PALETTE.size]), LinearLayout.LayoutParams(d(40), d(40)))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(Ui.text(this, title, 16f, Ui.NAVY, true)); if (sub.isNotEmpty()) t.addView(Ui.text(this, sub, 13f, Ui.SUB), Ui.lp(this, t = 1))
        card.addView(t, Ui.lp(this, 0, WRAP, l = 12, weight = 1f))
        return card to t
    }

    private fun navRow(col: LinearLayout, icon: Icon, idx: Int, title: String, sub: String, onClick: () -> Unit) {
        val (card, _) = rowCard(icon, idx, title, sub)
        card.background = Ui.ripple(this, Ui.CARD, 20); card.isClickable = true; card.setOnClickListener { onClick() }; Ui.pressable(card)
        card.addView(IconView(this, Icon.CHEVRON, Ui.SUB), LinearLayout.LayoutParams(d(18), d(18)))
        col.addView(card, Ui.lp(this, b = 10))
    }

    private fun switchRow(col: LinearLayout, icon: Icon, idx: Int, title: String, sub: String, v: Boolean, set: (Boolean) -> Unit) {
        val (card, _) = rowCard(icon, idx, title, sub)
        card.addView(Switch(this).apply { isChecked = v; contentDescription = tr(title); setOnCheckedChangeListener { _, c -> set(c) } })
        col.addView(card, Ui.lp(this, b = 10))
    }

    private fun sliderRow(col: LinearLayout, icon: Icon, idx: Int, title: String, max: Int, progress: Int, label: (Int) -> String, save: (Int) -> Unit) {
        val card = Ui.card(this).apply { setPadding(d(14), d(12), d(14), d(8)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.badge(this, icon, 40, Ui.PALETTE[idx % Ui.PALETTE.size]), LinearLayout.LayoutParams(d(40), d(40)))
        head.addView(Ui.text(this, title, 16f, Ui.NAVY, true), Ui.lp(this, 0, WRAP, l = 12, weight = 1f))
        val value = Ui.text(this, label(progress), 14f, Ui.BLUE, true); head.addView(value)
        card.addView(head)
        card.addView(SeekBar(this).apply {
            this.max = max; this.progress = progress; contentDescription = tr(title)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { value.text = label(p); if (fromUser) save(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, Ui.lp(this, t = 6))
        col.addView(card, Ui.lp(this, b = 10))
    }

    private fun segmented(col: LinearLayout, icon: Icon, idx: Int, title: String, options: List<String>, selected: Int, set: (Int) -> Unit) {
        val card = Ui.card(this).apply { setPadding(d(14), d(12), d(14), d(14)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.badge(this, icon, 40, Ui.PALETTE[idx % Ui.PALETTE.size]), LinearLayout.LayoutParams(d(40), d(40)))
        head.addView(Ui.text(this, title, 16f, Ui.NAVY, true), Ui.lp(this, l = 12)); card.addView(head)
        val row = LinearLayout(this).apply { background = Ui.rounded(this@MainActivity, Ui.FIELD, 14); setPadding(d(3), d(3), d(3), d(3)) }
        var sel = selected
        val items = ArrayList<TextView>()
        fun paint() = items.forEachIndexed { i, tv -> tv.background = if (i == sel) Ui.rounded(this, Ui.CARD, 12) else null; tv.setTextColor(if (i == sel) Ui.BLUE else Ui.SUB) }
        options.forEachIndexed { i, o ->
            val tv = Ui.text(this, o, 14f, Ui.SUB, true).apply { gravity = Gravity.CENTER; minHeight = d(38); setOnClickListener { sel = i; set(i); paint() } }
            items.add(tv); row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paint(); card.addView(row, Ui.lp(this, t = 10)); col.addView(card, Ui.lp(this, b = 10))
    }

    // ------------------------------------------------------------------ detail screens

    private fun scaffold(title: String, fill: (LinearLayout) -> Unit): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(d(12), d(8), d(20), d(8)) }
        bar.addView(IconView(this, Icon.BACK, Ui.NAVY).apply { setOnClickListener { onBackPressed() }; contentDescription = "Back" }, LinearLayout.LayoutParams(d(30), d(30)).apply { setMargins(d(10), 0, d(8), 0) })
        bar.addView(Ui.text(this, title, 22f, Ui.NAVY, true))
        page.addView(bar)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(18), d(4), d(18), d(28)) }
        fill(col)
        page.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return page
    }

    private fun languagesScreen(): View = scaffold("Layouts & languages") { col ->
        val enabled = Prefs.langs(this)
        val info = mapOf(
            "JATIYA" to ("জাতীয় (Jatiya)" to "National Bangla layout in QWERTY positions. Hold a key for every variant."),
            "AVRO" to ("অভ্র (Avro)" to "Phonetic: type Roman letters, get Bangla (ami → আমি). Capital letters matter, like Avro."),
            "CLASSIC" to ("বাংলা (Classic)" to "Three alphabetical pages; hold the arrow for every character."),
            "EN" to ("English" to "QWERTY, numbers and symbols on long-press, fonts & styles."),
            "BANGLISH" to ("Banglish" to "Type Bangla on the Jatiya keys, get Roman letters: আমি → Ami.")
        )
        col.addView(Ui.text(this, "Swipe the space bar right or left to move through these, in this order.", 14f, Ui.SUB), Ui.lp(this, b = 12))
        Prefs.allLangsOrdered(this).forEachIndexed { n, key ->
            val on = key in enabled
            val (card, _) = rowCard(Icon.GLOBE, n, info[key]!!.first, info[key]!!.second)
            if (on && enabled.size > 1) {
                val i = enabled.indexOf(key)
                fun mv(label: String, delta: Int, ok: Boolean) = Ui.textButton(this, label) {
                    if (ok) { val l = enabled.toMutableList(); l.removeAt(i); l.add(i + delta, key); Prefs.setLangs(this, l); refresh() }
                }.apply { alpha = if (ok) 1f else 0.3f; minWidth = d(36) }
                card.addView(mv("▲", -1, i > 0)); card.addView(mv("▼", 1, i < enabled.lastIndex))
            }
            card.addView(Switch(this).apply {
                isChecked = on; contentDescription = info[key]!!.first
                setOnCheckedChangeListener { _, v ->
                    val l = enabled.toMutableList()
                    if (v && key !in l) l.add(key) else if (!v) l.remove(key)
                    if (l.isEmpty()) isChecked = true else { Prefs.setLangs(this@MainActivity, l); refresh() }
                }
            })
            col.addView(card, Ui.lp(this, b = 10))
        }
        col.addView(Ui.text(this, "More languages (Hindi, Arabic, Urdu, Persian, Spanish, French and others) are planned. Each will come with a native layout and a Roman-letter layout.", 13.5f, Ui.SUB), Ui.lp(this, t = 8))
    }

    private fun fontsScreen(): View = scaffold("Fonts & styles") { col ->
        val cur = Prefs.fontId(this)
        col.addView(Ui.text(this, "Pick a style, then type in English. On the keyboard, tap the Aa icon to change it any time.", 14f, Ui.SUB), Ui.lp(this, b = 12))
        FontStyles.ALL.forEach { f ->
            val card = Ui.tapCard(this) { Prefs.setFontId(this, f.id); refresh() }
            if (f.id == cur) card.background = GradientDrawable().apply { setColor(Ui.CARD); cornerRadius = d(20).toFloat(); setStroke(d(2), Ui.BLUE) }
            card.addView(Ui.text(this, f.name, 12f, Ui.SUB, true))
            card.addView(Ui.text(this, f.apply("Hello World 123"), 20f, Ui.NAVY), Ui.lp(this, t = 4))
            col.addView(card, Ui.lp(this, b = 10))
        }
        col.addView(Ui.text(this, "These are special Unicode characters, not real fonts: they work for English letters and digits only, may show as boxes in some apps, and screen readers may read them oddly.", 13f, Ui.SUB), Ui.lp(this, t = 4))
    }

    private fun translateScreen(): View = scaffold("Translate") { col ->
        val c = Ui.card(this)
        c.addView(Ui.text(this, "How to use", 17f, Ui.NAVY, true))
        listOf("Type your message in any app.", "Tap the translate icon above the keys.", "Pick the two languages (From and To), then tap Translate.", "Tap Replace to swap your text for the translation, or Insert to add it. Then send it as usual.")
            .forEachIndexed { i, s -> c.addView(Ui.text(this, "${i + 1}.  $s", 14f, Ui.SUB), Ui.lp(this, t = 6)) }
        col.addView(c, Ui.lp(this, b = 10))
        val n = com.google.mlkit.nl.translate.TranslateLanguage.getAllLanguages().size
        val p = Ui.card(this)
        p.addView(Ui.text(this, "$n languages, translated on your phone", 17f, Ui.NAVY, true))
        p.addView(Ui.text(this, "Each language pack downloads once (this is the only reason Evolve uses the internet). After that, translation works offline. Evolve never uploads your text. Translation uses Google's ML Kit; see Google's documentation for its own data practices. It may not work on phones without Google Play services.", 14f, Ui.SUB), Ui.lp(this, t = 6))
        col.addView(p)
    }

    private fun securityScreen(): View = scaffold("Privacy & security") { col ->
        fun block(icon: Icon, idx: Int, title: String, body: String) {
            val (card, t) = rowCard(icon, idx, title, ""); t.addView(Ui.text(this, body, 13.5f, Ui.SUB), Ui.lp(this, t = 2)); col.addView(card, Ui.lp(this, b = 10))
        }
        block(Icon.LOCK, 4, "Nothing is collected", "No analytics, no ads, no keystroke logging. Evolve does not send what you type to any server.")
        block(Icon.SHIELD, 0, "Works offline", "Typing, suggestions, emoji, Avro, Banglish, clipboard and fonts run entirely on your phone. Translation needs a one-time language pack download. Voice typing uses your phone's speech service.")
        block(Icon.PHONE, 2, "Stored only on your phone", "Learned words, shortcuts and clipboard stay on this device. Recent clipboard items disappear after 1 hour.")
        block(Icon.KEYBOARD, 5, "Password fields", "No suggestions, no learning and no clipboard capture in password, email and web-address fields.")
        block(Icon.INFO, 3, "Permissions", "Microphone: optional, only for voice typing. Internet: only to download translation language packs. Nothing else.")
        col.addView(Ui.section(this, "Your data"), Ui.lp(this, t = 8, b = 8))
        col.addView(Ui.primaryButton(this, "Clear learned words") { UserWords(PrefsKeyValueStore(this, "evolve_words")).clear(); refresh() }, Ui.lp(this, b = 10))
        col.addView(Ui.primaryButton(this, "Clear all clipboard data") { ClipboardRepository(PrefsKeyValueStore(this)).clearAll(); refresh() })
    }

    private fun shortcutsScreen(): View = scaffold("Text shortcuts") { col ->
        val store = ShortcutStore(PrefsKeyValueStore(this, "evolve_shortcuts"))
        col.addView(Ui.text(this, "Type the short word, press space, and it expands. Good for addresses, emails and phrases you repeat.", 14f, Ui.SUB), Ui.lp(this, b = 12))
        val list = store.all()
        if (list.isEmpty()) {
            val c = Ui.card(this); c.gravity = Gravity.CENTER_HORIZONTAL
            c.addView(Ui.badge(this, Icon.BOLT, 56, Ui.PALETTE[3]), LinearLayout.LayoutParams(d(56), d(56)))
            c.addView(Ui.text(this, "Example: “tnx” → “Thank you so much!”", 14f, Ui.SUB), Ui.lp(this, t = 10))
            col.addView(c, Ui.lp(this, b = 12))
        }
        list.forEachIndexed { i, (k, v) ->
            val (card, _) = rowCard(Icon.BOLT, 3 + i, k, v)
            card.addView(IconView(this, Icon.TRASH, Color.parseColor("#E5484D")).apply { contentDescription = tr("Delete"); setOnClickListener { store.remove(k); refresh() } }, LinearLayout.LayoutParams(d(24), d(24)))
            col.addView(card, Ui.lp(this, b = 10))
        }
        col.addView(Ui.primaryButton(this, "Add shortcut") {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(8), d(20), 0) }
            val a = EditText(this).apply { hint = "addr"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS }
            val b = EditText(this).apply { hint = "…"; minLines = 2 }
            box.addView(a); box.addView(b)
            AlertDialog.Builder(this).setTitle(tr("Add shortcut")).setView(box)
                .setPositiveButton(tr("Save")) { _, _ -> store.put(a.text.toString().trim(), b.text.toString()); refresh() }.setNegativeButton(tr("Cancel"), null).show()
        }, Ui.lp(this, t = 8))
    }

    private fun clipboardScreen(): View = scaffold("Clipboard") { col ->
        val repo = ClipboardRepository(PrefsKeyValueStore(this))
        val c = Ui.card(this)
        c.addView(Ui.text(this, "How it works", 17f, Ui.NAVY, true))
        c.addView(Ui.text(this, "Open the clipboard icon above the keys. Recent items are removed automatically after 1 hour. Pin the ones you need and they stay until you delete them.", 14f, Ui.SUB), Ui.lp(this, t = 4))
        c.addView(Ui.text(this, "${repo.recent().size} ${tr("Recent")}  ·  ${repo.pinned().size} ${tr("Pinned")}", 15f, Ui.BLUE, true), Ui.lp(this, t = 12))
        col.addView(c, Ui.lp(this, b = 10))
        val p = Ui.card(this)
        p.addView(Ui.text(this, "Your privacy", 17f, Ui.NAVY, true))
        p.addView(Ui.text(this, "Only text copied while Evolve is on screen is saved, only on this phone, never from password fields. Android blocks background clipboard reading, so copies made while another keyboard is active are not captured.", 14f, Ui.SUB), Ui.lp(this, t = 4))
        col.addView(p, Ui.lp(this, b = 16))
        col.addView(Ui.primaryButton(this, "Clear all") {
            AlertDialog.Builder(this).setTitle(tr("Clear all")).setPositiveButton(tr("Delete")) { _, _ -> repo.clearAll(); refresh() }.setNegativeButton(tr("Cancel"), null).show()
        })
    }

    private fun converterScreen(): View = scaffold("Converter") { col ->
        fun converter(title: String, hint: String, convert: (String) -> String) {
            val card = Ui.card(this)
            card.addView(Ui.text(this, title, 17f, Ui.NAVY, true))
            val out = Ui.text(this, "", 20f, Ui.BLUE, true)
            card.addView(EditText(this).apply {
                this.hint = hint; setTextColor(Ui.NAVY); setHintTextColor(Ui.SUB)
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) { out.text = convert(s?.toString().orEmpty()) }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
            }, Ui.lp(this, t = 6))
            card.addView(out, Ui.lp(this, t = 8)); col.addView(card, Ui.lp(this, b = 12))
        }
        converter("Bangla → Banglish", "আমার নাম") { engine.toBanglishText(it) }
        converter("Avro → বাংলা", "ami tOmake bhalObasi") { AvroEngine.convert(it) }
        converter("Banglish → বাংলা", "tumi kemon acho") { engine.toBanglaText(it) }
        col.addView(Ui.text(this, "Avro is case-sensitive: o is the silent vowel, O makes ো, T/D/N are retroflex.", 14f, Ui.SUB))
    }

    private fun insightsScreen(): View = scaffold("Typing insights") { col ->
        val uw = UserWords(PrefsKeyValueStore(this, "evolve_words"))
        val top = uw.top(15)
        val head = Ui.card(this)
        head.addView(Ui.text(this, "${uw.size()} words", 20f, Ui.NAVY, true))
        head.addView(Ui.text(this, "Kept only on this phone, capped at ${UserWords.MAX}. One-off words are forgotten after 30 days; passwords, emails and web addresses are never learned.", 14f, Ui.SUB), Ui.lp(this, t = 4))
        col.addView(head, Ui.lp(this, b = 12))
        val max = (top.firstOrNull()?.second ?: 1).coerceAtLeast(1)
        top.forEachIndexed { i, (w, n) ->
            val card = Ui.card(this).apply { setPadding(d(14), d(10), d(14), d(10)) }
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            line.addView(Ui.text(this, w, 16f, Ui.NAVY, true), Ui.lp(this, 0, WRAP, weight = 1f)); line.addView(Ui.text(this, "×$n", 14f, Ui.BLUE, true))
            card.addView(line)
            card.addView(View(this).apply { background = Ui.gradient(this@MainActivity, 3, Ui.PALETTE[i % 8]) },
                Ui.lp(this, (resources.displayMetrics.widthPixels * 0.7f * n / max).toInt().coerceAtLeast(d(8)), d(5), t = 6))
            col.addView(card, Ui.lp(this, b = 8))
        }
        col.addView(Ui.primaryButton(this, "Clear learned words") { uw.clear(); refresh() }, Ui.lp(this, t = 8))
    }

    private fun aboutScreen(): View = scaffold("About") { col ->
        col.addView(ImageView(this).apply { setImageResource(R.drawable.evolve_wordmark); adjustViewBounds = true }, Ui.lp(this, b = 4))
        col.addView(Ui.text(this, "Version 0.3.0", 13f, Ui.SUB).apply { gravity = Gravity.CENTER }, Ui.lp(this, b = 16))
        fun block(icon: Icon, idx: Int, title: String, body: String) {
            val (card, t) = rowCard(icon, idx, title, ""); t.addView(Ui.text(this, body, 14f, Ui.SUB), Ui.lp(this, t = 2)); col.addView(card, Ui.lp(this, b = 10))
        }
        block(Icon.MIC, 1, "Voice typing", "Uses Android's speech recognition; depending on your phone, audio may be processed online by that service.")
        block(Icon.TRANSLATE, 6, "Translate", "Powered by Google ML Kit on-device translation. Language packs download once.")
        block(Icon.INFO, 2, "Assets", "Icons are drawn in code; the logo and wordmark were supplied by the project owner. Country names come from Unicode CLDR via Babel.")
    }
}
