package com.evolve.keyboard.keyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.evolve.keyboard.i18n.Tr
import com.evolve.keyboard.ui.Icon
import com.evolve.keyboard.ui.IconView

/** Small helpers shared by the Android-view panels (clipboard, themes, translate). */
internal object PanelParts {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(color: Int, radiusPx: Float, strokePx: Int = 0, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = radiusPx; if (strokePx > 0) setStroke(strokePx, stroke)
    }

    fun text(c: Context, s: String, sp: Float, color: Int, bold: Boolean = false) = TextView(c).apply {
        text = s; setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    /** Header bar: keyboard icon (back) + title; extra views can be appended to the returned row. */
    fun header(c: Context, theme: KeyboardTheme, title: String, onBack: () -> Unit): LinearLayout {
        val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(c, 6), dp(c, 4), dp(c, 10), dp(c, 4)) }
        val back = IconView(c, Icon.KEYBOARD, theme.keyText).apply { contentDescription = "Back to keyboard"; setOnClickListener { onBack() } }
        row.addView(back, LinearLayout.LayoutParams(dp(c, 40), dp(c, 40)).apply { setMargins(dp(c, 4), 0, dp(c, 6), 0) })
        if (title.isNotEmpty()) row.addView(text(c, Tr.t(title), 16f, theme.keyText, true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }
}
