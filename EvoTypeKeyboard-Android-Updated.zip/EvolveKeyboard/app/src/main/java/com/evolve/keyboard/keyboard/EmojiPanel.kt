package com.evolve.keyboard.keyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.evolve.keyboard.layouts.Layouts
import com.evolve.keyboard.suggest.EmojiRepository
import com.evolve.keyboard.ui.Icon
import com.evolve.keyboard.ui.IconView

/** Scrollable, categorised emoji picker: Recent, Suggestions, ten categories (incl. all flags) and search. */
class EmojiPanel(context: Context) : LinearLayout(context) {
    interface Listener { fun onEmoji(e: String); fun onBack(); fun onSearch(); fun onDelete() }

    var listener: Listener? = null
    private val d = resources.displayMetrics.density
    private var theme = KeyboardTheme.ALL[0]
    private var repo: EmojiRepository? = null
    private var recent: List<String> = emptyList()
    private var suggest: List<String> = emptyList()
    private var cat = "smileys"
    private var items: List<String> = emptyList()
    private val tabViews = HashMap<String, TextView>()
    private val tabs = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL }
    private val empty = TextView(context).apply { gravity = Gravity.CENTER; setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f) }
    private val search = TextView(context)
    private val grid = GridView(context)
    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
            val t = (v as? TextView) ?: TextView(context).apply {
                gravity = Gravity.CENTER; setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
                layoutParams = AbsListViewLp(ViewGroup.LayoutParams.MATCH_PARENT, (46 * d).toInt())
            }
            t.text = items[p]; return t
        }
    }

    private fun AbsListViewLp(w: Int, h: Int) = android.widget.AbsListView.LayoutParams(w, h)

    init {
        orientation = VERTICAL
        val top = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL; setPadding((8 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt()) }
        search.apply { text = "🔍  Search"; setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f); gravity = Gravity.CENTER_VERTICAL
            setPadding((12 * d).toInt(), 0, (12 * d).toInt(), 0); setOnClickListener { listener?.onSearch() } }
        top.addView(search, LayoutParams((104 * d).toInt(), (36 * d).toInt()))
        top.addView(HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false; addView(tabs) }, LayoutParams(0, (40 * d).toInt(), 1f).apply { leftMargin = (6 * d).toInt() })
        addView(top, LayoutParams(LayoutParams.MATCH_PARENT, (46 * d).toInt()))

        grid.apply { numColumns = GridView.AUTO_FIT; columnWidth = (44 * d).toInt(); stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = (2 * d).toInt(); selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT); this.adapter = this@EmojiPanel.adapter
            setOnItemClickListener { _, _, p, _ -> listener?.onEmoji(items[p]) } }
        val frame = FrameLayout(context)
        frame.addView(grid, FrameLayout.LayoutParams(-1, -1)); frame.addView(empty, FrameLayout.LayoutParams(-1, -1))
        grid.emptyView = empty
        addView(frame, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        val bottom = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL; setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt()) }
        bottom.addView(pill("ABC") { listener?.onBack() }, LayoutParams((72 * d).toInt(), (38 * d).toInt()))
        bottom.addView(View(context), LayoutParams(0, 1, 1f))
        bottom.addView(IconView(context, Icon.BACKSPACE, Color.WHITE).apply { tag = "bs"; setPadding(0, 0, 0, 0); setOnClickListener { listener?.onDelete() }; contentDescription = "Backspace" },
            LayoutParams((52 * d).toInt(), (38 * d).toInt()))
        addView(bottom, LayoutParams(LayoutParams.MATCH_PARENT, (46 * d).toInt()))

        Layouts.EMOJI_TAB_ICONS.forEach { (id, icon) ->
            val tv = TextView(context).apply { text = icon; gravity = Gravity.CENTER; setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                contentDescription = id; setOnClickListener { select(id) } }
            tabViews[id] = tv; tabs.addView(tv, LayoutParams((42 * d).toInt(), (36 * d).toInt()).apply { rightMargin = (2 * d).toInt() })
        }
    }

    private fun pill(label: String, onClick: () -> Unit) = TextView(context).apply {
        text = label; gravity = Gravity.CENTER; setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f); setTypeface(typeface, Typeface.BOLD); setOnClickListener { onClick() }; tag = "pill"
    }

    fun bind(theme: KeyboardTheme, repo: EmojiRepository?, recent: List<String>, suggest: List<String>) {
        this.theme = theme; this.repo = repo; this.recent = recent; this.suggest = suggest
        setBackgroundColor(if (theme.bg2 != theme.background) theme.background else theme.background)
        search.setTextColor(theme.label); search.background = GradientDrawable().apply { setColor(theme.function or 0xFF000000.toInt()); cornerRadius = 18 * d }
        (findPill())?.let { it.setTextColor(theme.keyText); it.background = GradientDrawable().apply { setColor(theme.function or 0xFF000000.toInt()); cornerRadius = 12 * d } }
        empty.setTextColor(theme.label)
        ((getChildAt(2) as? LinearLayout)?.getChildAt(2) as? IconView)?.color = theme.keyText
        select(if (recent.isNotEmpty() && cat == "recent") "recent" else if (suggest.isNotEmpty()) "suggest" else if (recent.isNotEmpty()) "recent" else "smileys")
    }

    private fun findPill(): TextView? {
        val bottom = getChildAt(2) as? LinearLayout ?: return null
        return bottom.getChildAt(0) as? TextView
    }

    private fun select(id: String) {
        cat = id
        items = when (id) {
            "recent" -> recent
            "suggest" -> suggest
            else -> repo?.inCategory(id).orEmpty()
        }
        empty.text = when {
            repo == null && id != "recent" -> "Loading emoji…"
            id == "recent" -> "Emoji you use will appear here"
            id == "suggest" -> "Type a word and suggestions appear here"
            else -> ""
        }
        tabViews.forEach { (k, v) ->
            v.background = if (k == id) GradientDrawable().apply { setColor((theme.accent and 0x00FFFFFF) or 0x55000000); cornerRadius = 12 * d } else null
        }
        adapter.notifyDataSetChanged(); grid.setSelection(0)
    }
}
