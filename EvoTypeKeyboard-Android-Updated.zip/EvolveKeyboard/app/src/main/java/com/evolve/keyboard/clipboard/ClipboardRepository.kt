package com.evolve.keyboard.clipboard

import java.net.URLDecoder
import java.net.URLEncoder

interface KeyValueStore { fun get(key: String): String?; fun put(key: String, value: String) }

data class ClipEntry(val id: Long, val text: String, val time: Long)

/**
 * Recent entries expire exactly one hour after they were copied (pruned on every read/write).
 * Pinned entries never expire; both lists are persisted through [store].
 */
class ClipboardRepository(private val store: KeyValueStore, private val clock: () -> Long = System::currentTimeMillis) {
    private val recent: MutableList<ClipEntry> = load("recent")
    private val pinned: MutableList<ClipEntry> = load("pinned")
    private var idSeq = (recent + pinned).maxOfOrNull { it.id } ?: 0L

    private fun nextId() = ++idSeq

    fun addRecent(text: String) {
        if (text.isBlank()) return
        prune()
        recent.removeAll { it.text == text }            // de-duplicate, newest wins
        recent.add(0, ClipEntry(nextId(), text, clock()))
        while (recent.size > MAX_RECENT) recent.removeAt(recent.lastIndex)
        save("recent", recent)
    }

    fun recent(): List<ClipEntry> { prune(); return recent.toList() }
    fun pinned(): List<ClipEntry> = pinned.toList()

    fun deleteRecent(id: Long) { recent.removeAll { it.id == id }; save("recent", recent) }

    fun pin(text: String) {
        if (text.isBlank() || pinned.any { it.text == text }) return
        pinned.add(0, ClipEntry(nextId(), text, clock())); save("pinned", pinned)
    }
    fun unpin(id: Long) { pinned.removeAll { it.id == id }; save("pinned", pinned) }
    fun editPinned(id: Long, newText: String) {
        val i = pinned.indexOfFirst { it.id == id }
        if (i >= 0 && newText.isNotBlank()) { pinned[i] = pinned[i].copy(text = newText); save("pinned", pinned) }
    }
    fun movePinned(id: Long, delta: Int) {
        val i = pinned.indexOfFirst { it.id == id }; val j = i + delta
        if (i < 0 || j !in pinned.indices) return
        val e = pinned.removeAt(i); pinned.add(j, e); save("pinned", pinned)
    }
    fun clearAll() { recent.clear(); pinned.clear(); save("recent", recent); save("pinned", pinned) }

    private fun prune() {
        val now = clock()
        if (recent.removeAll { now - it.time >= EXPIRY_MS }) save("recent", recent)
    }

    private fun save(key: String, list: List<ClipEntry>) = store.put(key, list.joinToString("\n") {
        "${it.id}|${it.time}|${URLEncoder.encode(it.text, "UTF-8")}"
    })

    private fun load(key: String): MutableList<ClipEntry> =
        (store.get(key) ?: "").lines().filter { it.isNotBlank() }.mapNotNull {
            val p = it.split('|')
            if (p.size != 3) null
            else runCatching { ClipEntry(p[0].toLong(), URLDecoder.decode(p[2], "UTF-8"), p[1].toLong()) }.getOrNull()
        }.toMutableList()

    companion object { const val EXPIRY_MS = 60L * 60L * 1000L; const val MAX_RECENT = 30 }
}
