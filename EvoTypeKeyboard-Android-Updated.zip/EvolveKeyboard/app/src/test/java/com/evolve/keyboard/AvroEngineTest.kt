package com.evolve.keyboard

import com.evolve.keyboard.banglish.AvroEngine
import org.junit.Assert.assertEquals
import org.junit.Test

class AvroEngineTest {
    @Test fun basicWords() {
        assertEquals("আমি", AvroEngine.convert("ami"))
        assertEquals("তুমি", AvroEngine.convert("tumi"))
        assertEquals("বাংলাদেশ", AvroEngine.convert("bangladesh"))
        assertEquals("ঢাকা", AvroEngine.convert("Dhaka"))
    }
    @Test fun capitalLettersMatterLikeAvro() {
        assertEquals("তোমাকে", AvroEngine.convert("tOmake"))
        assertEquals("ভালোবাসি", AvroEngine.convert("bhalObasi"))
        assertEquals("ভালবাসি", AvroEngine.convert("bhalobasi"))      // inherent "o" types nothing
    }
    @Test fun inherentOAndConjuncts() {
        assertEquals("কলম", AvroEngine.convert("kolom"))
        assertEquals("রক্ষা", AvroEngine.convert("rokkha"))
        assertEquals("ক্রি\u09DFা", AvroEngine.convert("kriYa"))
    }
    @Test fun punctuationAndDigits() {
        assertEquals("আমি।", AvroEngine.convert("ami."))
        assertEquals("২০২৬", AvroEngine.convert("2026"))
    }
}
