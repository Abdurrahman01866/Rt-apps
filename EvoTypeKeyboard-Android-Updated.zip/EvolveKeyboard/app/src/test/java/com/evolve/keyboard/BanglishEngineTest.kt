package com.evolve.keyboard

import com.evolve.keyboard.banglish.BanglishEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BanglishEngineTest {
    private val e = BanglishEngine()

    @Test fun banglishToBangla_words() {
        assertEquals("আমি", e.toBanglaText("Ami"))
        assertEquals("তুমি", e.toBanglaText("Tumi"))
        assertEquals("তোমাকে", e.toBanglaText("Tomake"))
        assertEquals("ভালোবাসি", e.toBanglaText("Bhalobashi"))
        assertEquals("বাংলাদেশ", e.toBanglaText("Bangladesh"))
    }
    @Test fun banglishToBangla_sentenceAndPunctuation() {
        assertEquals("আমার নাম", e.toBanglaText("Amar nam"))
        assertEquals("আমি, তুমি!", e.toBanglaText("ami, tumi!"))
        assertEquals("আমি!", e.toBanglaText("আমি!"))          // Bangla passes through untouched
    }
    @Test fun phoneticRulesWorkOutsideDictionary() {
        assertEquals("রাহিম", e.toBanglaText("rahim"))
    }
    @Test fun banglaToBanglish_words() {
        assertEquals("Ami", e.toBanglishText("আমি"))
        assertEquals("Tumi", e.toBanglishText("তুমি"))
        assertEquals("Tomake", e.toBanglishText("তোমাকে"))
        assertEquals("Bhalobashi", e.toBanglishText("ভালোবাসি"))
        assertEquals("Bangladesh", e.toBanglishText("বাংলাদেশ"))
        assertEquals("Amar nam", e.toBanglishText("আমার নাম"))
    }
    @Test fun banglaToBanglish_ruleOnly() {
        assertEquals("kolom", e.toBanglishCandidates("কলম").first())
    }
    @Test fun alternativeSpellingsAreOffered() {
        assertTrue(e.toBanglishCandidates("ভালোবাসি").contains("bhalobasi"))
    }
}
