package com.evolve.keyboard

import com.evolve.keyboard.clipboard.ClipboardRepository
import com.evolve.keyboard.clipboard.KeyValueStore
import org.junit.Assert.assertEquals
import org.junit.Test

class ClipboardRepositoryTest {
    private class Mem : KeyValueStore {
        val m = HashMap<String, String>()
        override fun get(key: String) = m[key]
        override fun put(key: String, value: String) { m[key] = value }
    }
    private var now = 1_000_000L

    @Test fun recentExpiresAtExactlyOneHour() {
        val r = ClipboardRepository(Mem()) { now }
        r.addRecent("hello"); now += 3_599_999; assertEquals(1, r.recent().size)
        now += 1; assertEquals(0, r.recent().size)
    }
    @Test fun duplicatesAreCollapsed() {
        val r = ClipboardRepository(Mem()) { now }
        r.addRecent("a"); now += 10; r.addRecent("b"); now += 10; r.addRecent("a")
        assertEquals(listOf("a", "b"), r.recent().map { it.text })
    }
    @Test fun pinnedSurvivesExpiryAndRestart() {
        val s = Mem(); val r = ClipboardRepository(s) { now }
        r.pin("বাংলা | pipe"); now += 10 * 3_600_000L
        assertEquals(listOf("বাংলা | pipe"), ClipboardRepository(s) { now }.pinned().map { it.text })
    }
    @Test fun reorderEditUnpin() {
        val r = ClipboardRepository(Mem()) { now }
        r.pin("one"); r.pin("two")                       // list: two, one
        r.movePinned(r.pinned()[0].id, 1); assertEquals(listOf("one", "two"), r.pinned().map { it.text })
        r.editPinned(r.pinned()[0].id, "uno"); assertEquals("uno", r.pinned()[0].text)
        r.unpin(r.pinned()[0].id); assertEquals(listOf("two"), r.pinned().map { it.text })
    }
}
