package com.evolve.keyboard

import com.evolve.keyboard.clipboard.KeyValueStore
import com.evolve.keyboard.suggest.EmojiRepository
import com.evolve.keyboard.suggest.UserWords
import com.evolve.keyboard.suggest.WordList
import com.evolve.keyboard.suggest.WordSuggester
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SuggestTest {
    private class Mem : KeyValueStore {
        val m = HashMap<String, String>()
        override fun get(key: String) = m[key]
        override fun put(key: String, value: String) { m[key] = value }
    }
    private var now = 100L * 24 * 3600 * 1000

    @Test fun habitsBeatDictionary() {
        val u = UserWords(Mem()) { now }
        repeat(10) { u.learn("HSC") }
        val s = WordSuggester(WordList(listOf("hello", "help", "hsctest")), WordList(emptyList()), u)
        assertEquals("HSC", s.suggest("hs", false).first())
        assertTrue(s.suggest("hel", false).containsAll(listOf("hello", "help")))
    }
    @Test fun learnedWordsStaySmall() {
        val store = Mem(); val u = UserWords(store) { now }
        for (i in 0 until 2000) u.learn("word" + i.toString().map { ('a' + it.digitToInt()) }.joinToString(""))
        assertTrue(u.size() <= UserWords.MAX)
        u.learn("once"); u.save(); now += 31L * 24 * 3600 * 1000
        assertEquals(0, UserWords(store) { now }.match("onc", 5).size)       // one-off words expire
    }
    @Test fun rejectsDigitsAndShortWords() {
        val u = UserWords(Mem()) { now }
        u.learn("a"); u.learn("abc123"); assertEquals(0, u.size())
    }
    @Test fun emojiSearchToleratesTypos() {
        val r = EmojiRepository.parse(listOf("😂\tsmileys\tface tears joy laugh lol", "❤\tsymbols\theavy black heart love", "🎂\tcelebration\tbirthday cake"))
        assertEquals("😂", r.search("laugh").first())
        assertEquals("🎂", r.search("brithday").first())          // typo
        assertEquals("❤", r.search("lov").first())
    }
}

class FontAndI18nTest {
    @org.junit.Test fun fontStylesMapLetters() {
        val bold = com.evolve.keyboard.suggest.FontStyles.byId("bold")
        org.junit.Assert.assertEquals(String(Character.toChars(0x1D400)), bold.apply("A"))
        org.junit.Assert.assertEquals("1 !", com.evolve.keyboard.suggest.FontStyles.byId("normal").apply("1 !"))
        org.junit.Assert.assertEquals("\u211D", com.evolve.keyboard.suggest.FontStyles.byId("double").apply("R"))
    }
    @org.junit.Test fun translationTablesAreAligned() {
        org.junit.Assert.assertTrue(com.evolve.keyboard.i18n.Tr.tablesAligned())
        com.evolve.keyboard.i18n.Tr.setLang("es"); org.junit.Assert.assertEquals("Inicio", com.evolve.keyboard.i18n.Tr.t("Home"))
        com.evolve.keyboard.i18n.Tr.setLang("en"); org.junit.Assert.assertEquals("Home", com.evolve.keyboard.i18n.Tr.t("Home"))
    }
}
